package com.macroflag.plusplatform.cache.cache;

import com.macroflag.plusplatform.cache.constants.CacheScope;
import com.macroflag.plusplatform.cache.parser.IKeyGenerator;
import com.macroflag.plusplatform.cache.parser.IUserKeyGenerator;

public class MyKeyGenerator extends IKeyGenerator {
    @Override
    public IUserKeyGenerator getUserKeyGenerator() {
        return null;
    }

    @Override
    public String buildKey(String key, CacheScope scope, Class<?>[] parameterTypes, Object[] arguments) {
        return "myKey_"+arguments[0];
    }
}
