package com.macroflag.plusplatform.cache.constants;

public enum CacheScope {
	user, application
}
