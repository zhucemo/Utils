package com.macroflag.plusplatform.cache.service;

import java.util.List;

import com.macroflag.plusplatform.cache.entity.CacheBean;
import com.macroflag.plusplatform.cache.vo.CacheTree;


/**
 * cache管理
 * 
 * @author : Fredia
 * @since : 2018年3月16日
 * @version : v1.0.0
 */
public interface ICacheManager {
    public void removeAll();

    public void remove(String key);

    public void remove(List<CacheBean> caches);

    public void removeByPre(String pre);

    public List<CacheTree> getAll();

    public List<CacheTree> getByPre(String pre);

    public void update(String key, int hour);

    public void update(List<CacheBean> caches, int hour);

    public String get(String key);
}
