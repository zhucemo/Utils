package com.macroflag.plusplatform.cache.constants;

public class CacheConstants {
    public final static String PRE = "i_";
    public final static String REDIS_SYS_NAME = "redis.sysName";
}
