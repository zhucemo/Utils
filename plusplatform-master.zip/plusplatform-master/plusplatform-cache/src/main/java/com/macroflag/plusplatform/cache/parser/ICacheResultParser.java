package com.macroflag.plusplatform.cache.parser;

import java.lang.reflect.Type;

/**
 * cache结果解析
 * 
 * @author : Fredia
 * @since : 2018年3月16日
 * @version : v1.0.0
 */
public interface ICacheResultParser {
	/**
	 * 解析结果
	 *
	 * @param value
	 * @param returnType
	 * @param origins
	 * @return
	 */
	public Object parse(String value, Type returnType, Class<?>... origins);
}
