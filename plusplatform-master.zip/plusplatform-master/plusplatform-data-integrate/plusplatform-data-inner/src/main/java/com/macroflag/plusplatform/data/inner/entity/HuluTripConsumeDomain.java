package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 葫芦出行消费记录的domain
 * @author : huangf
 * @since : 2018年04月18日
 * @version : v0.0.1
 */
public class HuluTripConsumeDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*下单时间*/
	private String orderDate;
	
	/*机票消费*/
	private Float flightSpend;
	
	/*火车消费*/
	private Float trainSpend;
	
	/*酒店消费*/
	private Float hotelSpend;
	
	/*月度消费频次(/人次)*/
	private Integer count;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getOrderDate(){
		return orderDate;
	}
	
	public void setOrderDate(String orderDate){
		this.orderDate = orderDate;
	}
	
	public Float getFlightSpend(){
		return flightSpend;
	}
	
	public void setFlightSpend(Float flightSpend){
		this.flightSpend = flightSpend;
	}
	
	public Float getTrainSpend(){
		return trainSpend;
	}
	
	public void setTrainSpend(Float trainSpend){
		this.trainSpend = trainSpend;
	}
	
	public Float getHotelSpend(){
		return hotelSpend;
	}
	
	public void setHotelSpend(Float hotelSpend){
		this.hotelSpend = hotelSpend;
	}
	
	public Integer getCount(){
		return count;
	}
	
	public void setCount(Integer count){
		this.count = count;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
