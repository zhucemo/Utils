package com.macroflag.plusplatform.data.inner.controller.api;


import com.macroflag.plusplatform.common.annotations.SystemLog;
import com.macroflag.plusplatform.common.exception.BaseException;
import com.macroflag.plusplatform.common.exception.ExceptionUtils;
import com.macroflag.plusplatform.data.inner.biz.MfNetgateSuanhuaFraudscoreBiz;
import com.macroflag.plusplatform.data.inner.biz.MfNetgateSuanhuaShoujishimingBiz;
import com.macroflag.plusplatform.data.inner.config.service.IApiConfigService;
import com.macroflag.plusplatform.data.inner.controller.base.BaseNetgateController;
import com.macroflag.plusplatform.data.inner.entity.ApiConfigDomain;
import com.macroflag.plusplatform.data.inner.entity.MfNetgateSuanhuaFraudscore;
import com.macroflag.plusplatform.data.inner.entity.MfNetgateSuanhuaShoujishiming;
import com.macroflag.plusplatform.data.inner.entity.ShBadInfoDomain;
import com.macroflag.plusplatform.data.inner.entity.ShPhoneInNetTimeDomain;
import com.macroflag.plusplatform.data.inner.entity.ShSheSuDomain;
import com.macroflag.plusplatform.data.inner.initem.service.IGztCreditEduInitemService;
import com.macroflag.plusplatform.data.inner.query.ShBadInfoQuery;
import com.macroflag.plusplatform.data.inner.query.ShPhoneInNetTimeQuery;
import com.macroflag.plusplatform.data.inner.query.ShSheSuQuery;
import com.macroflag.plusplatform.data.inner.thirdpart.component.IShThirdPartyService;
import com.macroflag.plusplatform.data.inner.thirdpart.component.impl.ShFraudScoreService;
import com.macroflag.plusplatform.data.inner.thirdpart.model.UserDataModel;
import com.macroflag.plusplatform.data.inner.thirdpart.service.IShBadInfoService;
import com.macroflag.plusplatform.data.inner.thirdpart.service.IShPhoneInNetTimeService;
import com.macroflag.plusplatform.data.inner.thirdpart.service.IShSheSuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.wordnik.swagger.annotations.ApiParam;

@Scope(value = "prototype")
@RestController
@RequestMapping("/suanhua")
public class ShThirdPartyController extends BaseNetgateController {

	@Autowired
	private IShThirdPartyService shThirdPartyService;
	
	@Autowired
	private IApiConfigService apiConfigService;
	
	@SuppressWarnings("unused")
	@Autowired
	private IGztCreditEduInitemService gztCreditEduInitemService;
	
	@Autowired
	private IShBadInfoService shBadInfoService;
	
	@Autowired
	private IShSheSuService shSheSuService;
	
	@Autowired
	private IShPhoneInNetTimeService shPhoneInNetTimeService;
	
	@Autowired
	private MfNetgateSuanhuaFraudscoreBiz mfNetgateSuanhuaFraudscoreBiz;
	
	@Autowired
	private ShFraudScoreService shFraudScoreService;
	
	@Autowired
	private MfNetgateSuanhuaShoujishimingBiz mfNetgateSuanhuaShoujishimingBiz;
	/**
	 * 算话不良记录E查询
	 * 
	 * @param name
	 * @param documentno
	 * @param businessKey
	 * @return
	 */
	@RequestMapping(value = "getSHBadInfo", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "算话不良记录E查询接口", requestMethod = RequestMethod.GET)
	public Object getSHBadInfo(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		logger.info("#########进入算话不良记录查询接口,申请编号为{}#########",businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		// 构建数据模型
		buildData(userDataModel);
		String uniqueNo = userDataModel.getUniqueNo();
		JSONObject result = null;
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("ShBadInfo");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########",json);
			return json;

		} else if (1 == status) {
			ShBadInfoQuery shBadInfoQuery = new ShBadInfoQuery();
			shBadInfoQuery.setUniqueNo(uniqueNo);
			ShBadInfoDomain shBadInfoDomain = shBadInfoService.getOne(shBadInfoQuery);
			
			if(shBadInfoDomain==null){
				shThirdPartyService.getSHBadInfo(userDataModel);
				jo = shThirdPartyService.determin(userDataModel);
			}else {
				jo = shThirdPartyService.determin(userDataModel);
			}
			
			logger.info("#####原始数据模型：{}####", jo);
			// 字典项转换
			try {
				result = convertEn2Cn(jo, "suanhua");
			} catch (Exception e) {
				logger.error("####英文转中文异常####");
				ExceptionUtils.throwBaseException("####英文转中文异常####");
			}
			logger.info("#########返回数据模型为：{}#########",result);
			return result;

		}
		logger.error("###该接口配置错误###");
		logger.info("#########返回数据模型为：{}#########",result);
		ExceptionUtils.throwBaseException("###该接口配置错误###");
		return result;

	}

	/**
	 * 涉诉风险汇总查询
	 * 
	 * @param name
	 * @param documentno
	 * @param businessKey
	 * @return
	 */
	@RequestMapping(value = "getShShesu", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "算话涉诉风险汇总查询接口", requestMethod = RequestMethod.GET)
	public Object getShShesu(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		logger.info("#########进入算话涉诉风险汇总查询接口,申请编号为{}#########",businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		// 构建数据模型
		buildData(userDataModel);
		String uniqueNo = userDataModel.getUniqueNo();
		JSONObject result = null;
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("ShShesu");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########",json);
			return json;

		} else if (1 == status) {
			
			ShSheSuQuery shSheSuQuery = new ShSheSuQuery();
			shSheSuQuery.setUniqueNo(uniqueNo);
			ShSheSuDomain shSheSuDomain = shSheSuService.getOne(shSheSuQuery);
			
			if(shSheSuDomain==null){
				//不存在数据则获取
				shThirdPartyService.getSHShesu(userDataModel);
				jo = shThirdPartyService.determin(userDataModel);
			}else {
				jo = shThirdPartyService.determin(userDataModel);
			}
			
			
			logger.info("#####原始数据模型：{}####", jo);
			// 字典项转换
			try {
				result = convertEn2Cn(jo, "suanhua");
			} catch (Exception e) {
				logger.error("####英文转中文异常####");
				ExceptionUtils.throwBaseException("####英文转中文异常####");
			}
			logger.info("#########返回数据模型为：{}#########",result);
			return result;

		}
		logger.error("###该接口配置错误###");
		logger.info("#########返回数据模型为：{}#########",result);
		ExceptionUtils.throwBaseException("###该接口配置错误###");
		return result;

	}

	/**
	 * 手机号在网时长
	 * 
	 * @param phone
	 * @param businessKey
	 * @return
	 */
	@RequestMapping(value = "getShPhoneInNetTime", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "算话手机号在网时长接口", requestMethod = RequestMethod.GET)
	public Object getShPhoneInNetTime(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		logger.info("#########进入算话手机号在网时长接口,申请编号为{}#########",businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		// 构建数据模型
		buildData(userDataModel);
		String uniqueNo = userDataModel.getUniqueNo();
		JSONObject result = null;
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("ShPhoneInNetTime");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########",json);
			return json;

		} else if (1 == status) {

			ShPhoneInNetTimeQuery shPhoneInNetTimeQuery = new ShPhoneInNetTimeQuery();
			shPhoneInNetTimeQuery.setUniqueNo(uniqueNo);
			ShPhoneInNetTimeDomain shPhoneInNetTimeDomain = shPhoneInNetTimeService.getOne(shPhoneInNetTimeQuery);
			
			if(shPhoneInNetTimeDomain==null){
				shThirdPartyService.getPhoneInNetTime(userDataModel);
				jo = shThirdPartyService.determin(userDataModel);
			}else {
				jo = shThirdPartyService.determin(userDataModel);
			}
			
			
			logger.info("#####原始数据模型：{}####", jo);
			// 字典项转换
			try {
				result = convertEn2Cn(jo, "suanhua");
			} catch (Exception e) {
				logger.error("####英文转中文异常####");
				ExceptionUtils.throwBaseException("####英文转中文异常####");
			}
			logger.info("#########返回数据模型为：{}#########",result);
			return result;

		}
		logger.error("###该接口配置错误###");
		logger.info("#########返回数据模型为：{}#########",result);
		ExceptionUtils.throwBaseException("###该接口配置错误###");
		return result;

	}
	
	/**
	 * 算话反欺诈欺诈评级
	 * @param phone
	 * @param name
	 * @param documentno
	 * @param businessKey
	 * @return
	 */
	@RequestMapping(value = "getFraudScore", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "算话反欺诈欺诈评级", requestMethod = RequestMethod.GET)
	public Object getFraudScore(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		
		logger.info("#########进入算话反欺诈欺诈评级接口,申请编号为{}#########",businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		// 构建数据模型
		buildData(userDataModel);
		String uniqueNo = userDataModel.getUniqueNo();
		JSONObject result = null;
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("getFraudScore");
		
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########",json);
			return json;

		} else if (1 == status) {
			
			MfNetgateSuanhuaFraudscore entity = new MfNetgateSuanhuaFraudscore();
			entity.setUniqueNo(uniqueNo);
			MfNetgateSuanhuaFraudscore mfNetgateSuanhuaFraudscore =mfNetgateSuanhuaFraudscoreBiz.selectOne(entity);
			
			
			if(mfNetgateSuanhuaFraudscore == null){
				//获取算话反欺诈欺诈评级原始数据
				shFraudScoreService.getFraudScore(userDataModel);
				//获取算话反欺诈欺诈评级规则输入项参数
				jo = shFraudScoreService.determin(userDataModel);
			}else{
				//获取算话反欺诈欺诈评级规则输入项参数
				jo = shFraudScoreService.determin(userDataModel);
			}
			
			
			logger.info("#####原始数据模型：{}####", jo);
			// 字典项转换
			try {
				result = convertEn2Cn(jo, "shFraudScore");
			} catch (Exception e) {
				logger.error("####英文转中文异常####");
				ExceptionUtils.throwBaseException("####英文转中文异常####");
			}
			logger.info("#########返回数据模型为：{}#########",result);
			return result;
		}
		logger.error("###该接口配置错误###");
		logger.info("#########返回数据模型为：{}#########",result);
		ExceptionUtils.throwBaseException("###该接口配置错误###");
		return result;
	}
	
	
	
	/**
	 * 算话手机号码实名制比对
	 * @param phone
	 * @param name
	 * @param documentno
	 * @param businessKey
	 * @return
	 */
	@RequestMapping(value = "getPhoneRele", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "算话手机号码实名制比对", requestMethod = RequestMethod.GET)
	public Object getPhoneReleNameComp(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		
		logger.info("#########进入算话反欺诈欺诈评级接口,申请编号为{}#########",businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		// 构建数据模型
		buildData(userDataModel);
		String uniqueNo = userDataModel.getUniqueNo();
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("ShPhoneRele");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########",json);
			return json;

		} else if (1 == status) {
			MfNetgateSuanhuaShoujishiming entity = new MfNetgateSuanhuaShoujishiming();
			entity.setUniqueNo(uniqueNo);
			MfNetgateSuanhuaShoujishiming mfNetgateSuanhuaShoujishiming =mfNetgateSuanhuaShoujishimingBiz.selectOne(entity);
			if(mfNetgateSuanhuaShoujishiming == null){
				shThirdPartyService.getPhoneReleNameComp(userDataModel);
			}
		}
		
		logger.info("#####原始数据模型：{}####", jo);
		
		return jo;
	}
	
}
