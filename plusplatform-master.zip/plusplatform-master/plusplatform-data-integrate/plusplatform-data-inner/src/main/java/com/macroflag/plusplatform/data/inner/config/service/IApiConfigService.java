package com.macroflag.plusplatform.data.inner.config.service;

import com.macroflag.plusplatform.common.core.service.IBaseService;
import com.macroflag.plusplatform.common.web.ResultResponse;
import com.macroflag.plusplatform.data.inner.entity.ApiConfigDomain;

/**
 * 接口配置表的业务层接口
 * 
 * @author : Fredia
 * @since : 2018年05月09日
 * @version : v0.0.1
 */
public interface IApiConfigService extends IBaseService<ApiConfigDomain> {
	/**
	 * 验证接口状态
	 * 
	 * @param apiCode
	 * @return
	 * @author : Fredia
	 * @since : 2018年5月9日
	 * @return :ApiConfigDomain
	 */
	ApiConfigDomain getApiConfig(String apiCode);
}
