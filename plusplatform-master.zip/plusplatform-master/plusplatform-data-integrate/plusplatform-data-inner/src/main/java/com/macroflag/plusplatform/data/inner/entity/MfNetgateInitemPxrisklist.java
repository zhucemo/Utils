package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-19 14:13:33
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_initem_pxrisklist")
public class MfNetgateInitemPxrisklist implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Integer id;
	
	    //业务唯一标识
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //拍拍信是否是不良用户
    @Column(name = "is_black")
    private Integer isBlack;
	
	    //拍拍信是否是关注用户
    @Column(name = "is_alert")
    private Integer isAlert;
	
	    //预留字段1
    @Column(name = "spare1")
    private String spare1;
	
	    //预留字段2
    @Column(name = "spare2")
    private String spare2;
	
	    //预留字段3
    @Column(name = "spare3")
    private String spare3;
	
	    //预留字段4
    @Column(name = "spare4")
    private String spare4;
	
	    //创建用户
    @Column(name = "create_user")
    private Date createUser;
	
	    //创建时间
    @Column(name = "create_time")
    private Date createTime;
	
	    //更新用户
    @Column(name = "update_user")
    private Date updateUser;
	
	    //更新时间
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 设置：业务唯一标识
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：业务唯一标识
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：拍拍信是否是不良用户
	 */
	public void setIsBlack(Integer isBlack) {
		this.isBlack = isBlack;
	}
	/**
	 * 获取：拍拍信是否是不良用户
	 */
	public Integer getIsBlack() {
		return isBlack;
	}
	/**
	 * 设置：拍拍信是否是关注用户
	 */
	public void setIsAlert(Integer isAlert) {
		this.isAlert = isAlert;
	}
	/**
	 * 获取：拍拍信是否是关注用户
	 */
	public Integer getIsAlert() {
		return isAlert;
	}
	/**
	 * 设置：预留字段1
	 */
	public void setSpare1(String spare1) {
		this.spare1 = spare1;
	}
	/**
	 * 获取：预留字段1
	 */
	public String getSpare1() {
		return spare1;
	}
	/**
	 * 设置：预留字段2
	 */
	public void setSpare2(String spare2) {
		this.spare2 = spare2;
	}
	/**
	 * 获取：预留字段2
	 */
	public String getSpare2() {
		return spare2;
	}
	/**
	 * 设置：预留字段3
	 */
	public void setSpare3(String spare3) {
		this.spare3 = spare3;
	}
	/**
	 * 获取：预留字段3
	 */
	public String getSpare3() {
		return spare3;
	}
	/**
	 * 设置：预留字段4
	 */
	public void setSpare4(String spare4) {
		this.spare4 = spare4;
	}
	/**
	 * 获取：预留字段4
	 */
	public String getSpare4() {
		return spare4;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreateUser(Date createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：创建用户
	 */
	public Date getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(Date updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public Date getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
}
