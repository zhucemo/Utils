package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-31 09:39:41
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_initem_blacklistmatch")
public class MfNetgateInitemBlacklistmatch implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键id
    @Id
    private Long id;
	
	    //业务唯一标识
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //申请手机号黑名单
    @Column(name = "bltelflag")
    private String bltelflag;
	
	    //申请身份证黑名单
    @Column(name = "blidflag")
    private String blidflag;
	
	    //手机号、直系亲属联系人、其他联系人手机号命中阿里小号
    @Column(name = "bltelissmallno")
    private String bltelissmallno;
	
	    //虚拟小号号段前4位
    @Column(name = "mobilefirst4")
    private String mobilefirst4;
	
	    //姓名手机号身份证号击中外部黑名单
    @Column(name = "blouterflag")
    private String blouterflag;
	
	    //身份证号击中灰名单
    @Column(name = "blgidflag")
    private String blgidflag;
	
	    //申请手机号击中灰名单
    @Column(name = "blgtelflag")
    private String blgtelflag;
	
	    //身份证号击中疑似黑名单
    @Column(name = "blysidflag")
    private String blysidflag;
	
	    //申请手机号击中疑似黑名单
    @Column(name = "blystelflag")
    private String blystelflag;
	
	    //默认小号集合
    @Column(name = "smalllist")
    private String smalllist;
	
	    //年龄
    @Column(name = "age")
    private Integer age;
	
	    //申请手机号赌博 
    @Column(name = "bltelisgamble")
    private String bltelisgamble;
	
	    //申请手机号中介
    @Column(name = "mobilehitagent")
    private Integer mobilehitagent;
	
	    //身份证命中疑似灰名单
    @Column(name = "rgblysgidflag")
    private String rgblysgidflag;
	
	    //申请手机号命中疑似灰名单
    @Column(name = "rgblysgtelflag")
    private String rgblysgtelflag;
	
	    //id姓名命中疑似灰名单
    @Column(name = "rgblysgidouterflag")
    private String rgblysgidouterflag;
	
	    //姓名手机号命中疑似灰名单
    @Column(name = "rgblysgphoneouterflag")
    private String rgblysgphoneouterflag;
	
	    //亲属联系人命中黑名单
    @Column(name = "rgbltelcontact1flag")
    private String rgbltelcontact1flag;
	
	    //亲属联系人命中灰名单
    @Column(name = "rgblgtelcontact1flag")
    private String rgblgtelcontact1flag;
	
	    //亲属联系人命中疑似黑名单
    @Column(name = "rgblystelcontact1flag")
    private String rgblystelcontact1flag;
	
	    //亲属联系人命中疑似灰名单
    @Column(name = "rgblysgtelcontact1flag")
    private String rgblysgtelcontact1flag;
	
	    //其他联系人命中黑名单
    @Column(name = "rgbltelcontact2flag")
    private String rgbltelcontact2flag;
	
	    //其他联系人命中灰名单
    @Column(name = "rgblgtelcontact2flag")
    private String rgblgtelcontact2flag;
	
	    //其他联系人命中疑似黑名单
    @Column(name = "rgblystelcontact2flag")
    private String rgblystelcontact2flag;
	
	    //其他联系人命中疑似灰名单
    @Column(name = "rgblysgtelcontact2flag")
    private String rgblysgtelcontact2flag;
    
    	//工作单位命中黑名单
    @Column(name = "conamecontainblname")
    private String conamecontainblname;
    
    	//工作电话命中黑名单
    @Column(name = "conumhitblnum")
    private String conumhitblnum;
	
	    //预留字段1
    @Column(name = "spare1")
    private String spare1;
	
	    //预留字段2
    @Column(name = "spare2")
    private String spare2;
	
	    //预留字段3
    @Column(name = "spare3")
    private String spare3;
	
	    //预留字段4
    @Column(name = "spare4")
    private String spare4;
	
	    //创建用户
    @Column(name = "create_user")
    private Long createUser;
	
	    //创建时间
    @Column(name = "create_time")
    private Date createTime;
	
	    //更新用户
    @Column(name = "update_user")
    private Long updateUser;
	
	    //更新时间
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：业务唯一标识
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：业务唯一标识
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：申请手机号黑名单
	 */
	public void setBltelflag(String bltelflag) {
		this.bltelflag = bltelflag;
	}
	/**
	 * 获取：申请手机号黑名单
	 */
	public String getBltelflag() {
		return bltelflag;
	}
	/**
	 * 设置：申请身份证黑名单
	 */
	public void setBlidflag(String blidflag) {
		this.blidflag = blidflag;
	}
	/**
	 * 获取：申请身份证黑名单
	 */
	public String getBlidflag() {
		return blidflag;
	}
	/**
	 * 设置：手机号、直系亲属联系人、其他联系人手机号命中阿里小号
	 */
	public void setBltelissmallno(String bltelissmallno) {
		this.bltelissmallno = bltelissmallno;
	}
	/**
	 * 获取：手机号、直系亲属联系人、其他联系人手机号命中阿里小号
	 */
	public String getBltelissmallno() {
		return bltelissmallno;
	}
	/**
	 * 设置：虚拟小号号段前4位
	 */
	public void setMobilefirst4(String mobilefirst4) {
		this.mobilefirst4 = mobilefirst4;
	}
	/**
	 * 获取：虚拟小号号段前4位
	 */
	public String getMobilefirst4() {
		return mobilefirst4;
	}
	/**
	 * 设置：姓名手机号身份证号击中外部黑名单
	 */
	public void setBlouterflag(String blouterflag) {
		this.blouterflag = blouterflag;
	}
	/**
	 * 获取：姓名手机号身份证号击中外部黑名单
	 */
	public String getBlouterflag() {
		return blouterflag;
	}
	/**
	 * 设置：身份证号击中灰名单
	 */
	public void setBlgidflag(String blgidflag) {
		this.blgidflag = blgidflag;
	}
	/**
	 * 获取：身份证号击中灰名单
	 */
	public String getBlgidflag() {
		return blgidflag;
	}
	/**
	 * 设置：申请手机号击中灰名单
	 */
	public void setBlgtelflag(String blgtelflag) {
		this.blgtelflag = blgtelflag;
	}
	/**
	 * 获取：申请手机号击中灰名单
	 */
	public String getBlgtelflag() {
		return blgtelflag;
	}
	/**
	 * 设置：身份证号击中疑似黑名单
	 */
	public void setBlysidflag(String blysidflag) {
		this.blysidflag = blysidflag;
	}
	/**
	 * 获取：身份证号击中疑似黑名单
	 */
	public String getBlysidflag() {
		return blysidflag;
	}
	/**
	 * 设置：申请手机号击中疑似黑名单
	 */
	public void setBlystelflag(String blystelflag) {
		this.blystelflag = blystelflag;
	}
	/**
	 * 获取：申请手机号击中疑似黑名单
	 */
	public String getBlystelflag() {
		return blystelflag;
	}
	/**
	 * 设置：默认小号集合
	 */
	public void setSmalllist(String smalllist) {
		this.smalllist = smalllist;
	}
	/**
	 * 获取：默认小号集合
	 */
	public String getSmalllist() {
		return smalllist;
	}
	/**
	 * 设置：年龄
	 */
	public void setAge(Integer age) {
		this.age = age;
	}
	/**
	 * 获取：年龄
	 */
	public Integer getAge() {
		return age;
	}
	/**
	 * 设置：申请手机号赌博 
	 */
	public void setBltelisgamble(String bltelisgamble) {
		this.bltelisgamble = bltelisgamble;
	}
	/**
	 * 获取：申请手机号赌博 
	 */
	public String getBltelisgamble() {
		return bltelisgamble;
	}
	/**
	 * 设置：申请手机号中介
	 */
	public void setMobilehitagent(Integer mobilehitagent) {
		this.mobilehitagent = mobilehitagent;
	}
	/**
	 * 获取：申请手机号中介
	 */
	public Integer getMobilehitagent() {
		return mobilehitagent;
	}
	/**
	 * 设置：身份证命中疑似灰名单
	 */
	public void setRgblysgidflag(String rgblysgidflag) {
		this.rgblysgidflag = rgblysgidflag;
	}
	/**
	 * 获取：身份证命中疑似灰名单
	 */
	public String getRgblysgidflag() {
		return rgblysgidflag;
	}
	/**
	 * 设置：申请手机号命中疑似灰名单
	 */
	public void setRgblysgtelflag(String rgblysgtelflag) {
		this.rgblysgtelflag = rgblysgtelflag;
	}
	/**
	 * 获取：申请手机号命中疑似灰名单
	 */
	public String getRgblysgtelflag() {
		return rgblysgtelflag;
	}
	/**
	 * 设置：id姓名命中疑似灰名单
	 */
	public void setRgblysgidouterflag(String rgblysgidouterflag) {
		this.rgblysgidouterflag = rgblysgidouterflag;
	}
	/**
	 * 获取：id姓名命中疑似灰名单
	 */
	public String getRgblysgidouterflag() {
		return rgblysgidouterflag;
	}
	/**
	 * 设置：姓名手机号命中疑似灰名单
	 */
	public void setRgblysgphoneouterflag(String rgblysgphoneouterflag) {
		this.rgblysgphoneouterflag = rgblysgphoneouterflag;
	}
	/**
	 * 获取：姓名手机号命中疑似灰名单
	 */
	public String getRgblysgphoneouterflag() {
		return rgblysgphoneouterflag;
	}
	/**
	 * 设置：亲属联系人命中黑名单
	 */
	public void setRgbltelcontact1flag(String rgbltelcontact1flag) {
		this.rgbltelcontact1flag = rgbltelcontact1flag;
	}
	/**
	 * 获取：亲属联系人命中黑名单
	 */
	public String getRgbltelcontact1flag() {
		return rgbltelcontact1flag;
	}
	/**
	 * 设置：亲属联系人命中灰名单
	 */
	public void setRgblgtelcontact1flag(String rgblgtelcontact1flag) {
		this.rgblgtelcontact1flag = rgblgtelcontact1flag;
	}
	/**
	 * 获取：亲属联系人命中灰名单
	 */
	public String getRgblgtelcontact1flag() {
		return rgblgtelcontact1flag;
	}
	/**
	 * 设置：亲属联系人命中疑似黑名单
	 */
	public void setRgblystelcontact1flag(String rgblystelcontact1flag) {
		this.rgblystelcontact1flag = rgblystelcontact1flag;
	}
	/**
	 * 获取：亲属联系人命中疑似黑名单
	 */
	public String getRgblystelcontact1flag() {
		return rgblystelcontact1flag;
	}
	/**
	 * 设置：亲属联系人命中疑似灰名单
	 */
	public void setRgblysgtelcontact1flag(String rgblysgtelcontact1flag) {
		this.rgblysgtelcontact1flag = rgblysgtelcontact1flag;
	}
	/**
	 * 获取：亲属联系人命中疑似灰名单
	 */
	public String getRgblysgtelcontact1flag() {
		return rgblysgtelcontact1flag;
	}
	/**
	 * 设置：其他联系人命中黑名单
	 */
	public void setRgbltelcontact2flag(String rgbltelcontact2flag) {
		this.rgbltelcontact2flag = rgbltelcontact2flag;
	}
	/**
	 * 获取：其他联系人命中黑名单
	 */
	public String getRgbltelcontact2flag() {
		return rgbltelcontact2flag;
	}
	/**
	 * 设置：其他联系人命中灰名单
	 */
	public void setRgblgtelcontact2flag(String rgblgtelcontact2flag) {
		this.rgblgtelcontact2flag = rgblgtelcontact2flag;
	}
	/**
	 * 获取：其他联系人命中灰名单
	 */
	public String getRgblgtelcontact2flag() {
		return rgblgtelcontact2flag;
	}
	/**
	 * 设置：其他联系人命中疑似黑名单
	 */
	public void setRgblystelcontact2flag(String rgblystelcontact2flag) {
		this.rgblystelcontact2flag = rgblystelcontact2flag;
	}
	/**
	 * 获取：其他联系人命中疑似黑名单
	 */
	public String getRgblystelcontact2flag() {
		return rgblystelcontact2flag;
	}
	/**
	 * 设置：其他联系人命中疑似灰名单
	 */
	public void setRgblysgtelcontact2flag(String rgblysgtelcontact2flag) {
		this.rgblysgtelcontact2flag = rgblysgtelcontact2flag;
	}
	/**
	 * 获取：其他联系人命中疑似灰名单
	 */
	public String getRgblysgtelcontact2flag() {
		return rgblysgtelcontact2flag;
	}
	/**
	 * 设置：预留字段1
	 */
	public void setSpare1(String spare1) {
		this.spare1 = spare1;
	}
	/**
	 * 获取：预留字段1
	 */
	public String getSpare1() {
		return spare1;
	}
	/**
	 * 设置：预留字段2
	 */
	public void setSpare2(String spare2) {
		this.spare2 = spare2;
	}
	/**
	 * 获取：预留字段2
	 */
	public String getSpare2() {
		return spare2;
	}
	/**
	 * 设置：预留字段3
	 */
	public void setSpare3(String spare3) {
		this.spare3 = spare3;
	}
	/**
	 * 获取：预留字段3
	 */
	public String getSpare3() {
		return spare3;
	}
	/**
	 * 设置：预留字段4
	 */
	public void setSpare4(String spare4) {
		this.spare4 = spare4;
	}
	/**
	 * 获取：预留字段4
	 */
	public String getSpare4() {
		return spare4;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：创建用户
	 */
	public Long getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(Long updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public Long getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
	public String getConamecontainblname() {
		return conamecontainblname;
	}
	public void setConamecontainblname(String conamecontainblname) {
		this.conamecontainblname = conamecontainblname;
	}
	public String getConumhitblnum() {
		return conumhitblnum;
	}
	public void setConumhitblnum(String conumhitblnum) {
		this.conumhitblnum = conumhitblnum;
	}
}
