package com.macroflag.plusplatform.data.inner.dao.impl;

import com.macroflag.plusplatform.data.inner.dao.HuluBasicDao;
import com.macroflag.plusplatform.data.inner.entity.HuluBasicDomain;
import com.macroflag.plusplatform.data.inner.mapper.HuluBasicMapper;
import com.macroflag.plusplatform.data.inner.query.HuluBasicQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class HuluBasicDaoImpl implements HuluBasicDao {

    @Autowired
    HuluBasicMapper huluBasicMapper;

    @Override
    public HuluBasicDomain getOneByUnique(String uniqueNo) {
        HuluBasicQuery huluBasicQuery = new HuluBasicQuery();
        huluBasicQuery.setUniqueNo(uniqueNo);
        return huluBasicMapper.getOne(huluBasicQuery);
    }

    @Override
    public List<HuluBasicDomain> sameRealName(HuluBasicDomain huluBasicDomain) {
        return huluBasicMapper.sameRealName(huluBasicDomain);
    }
}
