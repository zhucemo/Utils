package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

import com.macroflag.plusplatform.encryption.annotation.EnDomain;
import com.macroflag.plusplatform.encryption.annotation.EnField;

/**
 * 葫芦短信数据的domain
 * @author : huangf
 * @since : 2018年04月24日
 * @version : v0.0.1
 */
@EnDomain
public class HuluSmsesDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*发送时间*/
	private Date startTime;
	
	/*数据获取时间*/
	private Date getDateTime;
	
	/*本次短信花费（元）*/
	private Double subtotal;
	
	/*流量使用地点*/
	private String place;
	
	/*呼叫类型*/
	private String initType;
	
	/*对方号码*/
	@EnField
	private String otherCellPhone;
	
	/*本机号码*/
	@EnField
	private String cellPhone;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public Date getStartTime(){
		return startTime;
	}
	
	public void setStartTime(Date startTime){
		this.startTime = startTime;
	}
	
	public Date getGetDateTime(){
		return getDateTime;
	}
	
	public void setGetDateTime(Date getDateTime){
		this.getDateTime = getDateTime;
	}
	
	public Double getSubtotal(){
		return subtotal;
	}
	
	public void setSubtotal(Double subtotal){
		this.subtotal = subtotal;
	}
	
	public String getPlace(){
		return place;
	}
	
	public void setPlace(String place){
		this.place = place;
	}
	
	public String getInitType(){
		return initType;
	}
	
	public void setInitType(String initType){
		this.initType = initType;
	}
	
	public String getOtherCellPhone(){
		return otherCellPhone;
	}
	
	public void setOtherCellPhone(String otherCellPhone){
		this.otherCellPhone = otherCellPhone;
	}
	
	public String getCellPhone(){
		return cellPhone;
	}
	
	public void setCellPhone(String cellPhone){
		this.cellPhone = cellPhone;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
