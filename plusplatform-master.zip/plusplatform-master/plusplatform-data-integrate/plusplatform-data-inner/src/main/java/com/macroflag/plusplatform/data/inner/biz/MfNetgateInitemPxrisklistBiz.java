package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateInitemPxrisklist;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateInitemPxrisklistMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-19 14:13:33
 * @version : v1.0.0
 */
@Service
public class MfNetgateInitemPxrisklistBiz extends BusinessBiz<MfNetgateInitemPxrisklistMapper,MfNetgateInitemPxrisklist> {

	@Autowired
	private MfNetgateInitemPxrisklistMapper mfNetgateInitemPxrisklistMapper;
	
	
	/**
	 * 更新规则输入项参数
	 * @param mfNetgateInitemPxrisklist
	 */
	public void updateByUniqueNo(MfNetgateInitemPxrisklist mfNetgateInitemPxrisklist) {
		
		mfNetgateInitemPxrisklistMapper.updateByUniqueNo(mfNetgateInitemPxrisklist);
	}
}