package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-19 10:55:25
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_ppxin_blacksummary")
public class MfNetgatePpxinBlacksummary implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Integer id;
	
	    //用户唯一标识
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //风险分类类型
    @Column(name = "black_type")
    private String blackType;
	
	    //风险分类项
    @Column(name = "label")
    private String label;
	
	    //风险分类项名称
    @Column(name = "item_name")
    private String itemName;
	
	    //风险分类项值规约
    @Column(name = "item_value")
    private String itemValue;
	
	    //预留字段1
    @Column(name = "spare1")
    private String spare1;
	
	    //预留字段2
    @Column(name = "spare2")
    private String spare2;
	
	    //预留字段3
    @Column(name = "spare3")
    private String spare3;
	
	    //预留字段4
    @Column(name = "spare4")
    private String spare4;
	
	    //创建用户
    @Column(name = "creat_user")
    private Date creatUser;
	
	    //创建时间
    @Column(name = "creat_time")
    private Date creatTime;
	
	    //更新用户
    @Column(name = "update_user")
    private Date updateUser;
	
	    //更新时间
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 设置：用户唯一标识
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：用户唯一标识
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：风险分类类型
	 */
	public void setBlackType(String blackType) {
		this.blackType = blackType;
	}
	/**
	 * 获取：风险分类类型
	 */
	public String getBlackType() {
		return blackType;
	}
	/**
	 * 设置：风险分类项
	 */
	public void setLabel(String label) {
		this.label = label;
	}
	/**
	 * 获取：风险分类项
	 */
	public String getLabel() {
		return label;
	}
	/**
	 * 设置：风险分类项名称
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	/**
	 * 获取：风险分类项名称
	 */
	public String getItemName() {
		return itemName;
	}
	/**
	 * 设置：风险分类项值规约
	 */
	public void setItemValue(String itemValue) {
		this.itemValue = itemValue;
	}
	/**
	 * 获取：风险分类项值规约
	 */
	public String getItemValue() {
		return itemValue;
	}
	/**
	 * 设置：预留字段1
	 */
	public void setSpare1(String spare1) {
		this.spare1 = spare1;
	}
	/**
	 * 获取：预留字段1
	 */
	public String getSpare1() {
		return spare1;
	}
	/**
	 * 设置：预留字段2
	 */
	public void setSpare2(String spare2) {
		this.spare2 = spare2;
	}
	/**
	 * 获取：预留字段2
	 */
	public String getSpare2() {
		return spare2;
	}
	/**
	 * 设置：预留字段3
	 */
	public void setSpare3(String spare3) {
		this.spare3 = spare3;
	}
	/**
	 * 获取：预留字段3
	 */
	public String getSpare3() {
		return spare3;
	}
	/**
	 * 设置：预留字段4
	 */
	public void setSpare4(String spare4) {
		this.spare4 = spare4;
	}
	/**
	 * 获取：预留字段4
	 */
	public String getSpare4() {
		return spare4;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreatUser(Date creatUser) {
		this.creatUser = creatUser;
	}
	/**
	 * 获取：创建用户
	 */
	public Date getCreatUser() {
		return creatUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreatTime(Date creatTime) {
		this.creatTime = creatTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreatTime() {
		return creatTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(Date updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public Date getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
}
