package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 白骑士规则内容明细的domain
 * @author : huangf
 * @since : 2018年04月25日
 * @version : v0.0.1
 */
public class BqsRuleDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键id*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*策略id*/
	private String strategyId;
	
	/*规则名称*/
	private String ruleName;
	
	/*规则id*/
	private String ruleId;
	
	/*规则风险系数*/
	private Integer score;
	
	/*风险名单比对规则决策结果*/
	private String decision;
	
	/*名单匹配规则击中分类明细*/
	private String memo;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long creatUser;
	
	/*创建时间*/
	private Date creatTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getStrategyId(){
		return strategyId;
	}
	
	public void setStrategyId(String strategyId){
		this.strategyId = strategyId;
	}
	
	public String getRuleName(){
		return ruleName;
	}
	
	public void setRuleName(String ruleName){
		this.ruleName = ruleName;
	}
	
	public String getRuleId(){
		return ruleId;
	}
	
	public void setRuleId(String ruleId){
		this.ruleId = ruleId;
	}
	
	public Integer getScore(){
		return score;
	}
	
	public void setScore(Integer score){
		this.score = score;
	}
	
	public String getDecision(){
		return decision;
	}
	
	public void setDecision(String decision){
		this.decision = decision;
	}
	
	public String getMemo(){
		return memo;
	}
	
	public void setMemo(String memo){
		this.memo = memo;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreatUser(){
		return creatUser;
	}
	
	public void setCreatUser(Long creatUser){
		this.creatUser = creatUser;
	}
	
	public Date getCreatTime(){
		return creatTime;
	}
	
	public void setCreatTime(Date creatTime){
		this.creatTime = creatTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
