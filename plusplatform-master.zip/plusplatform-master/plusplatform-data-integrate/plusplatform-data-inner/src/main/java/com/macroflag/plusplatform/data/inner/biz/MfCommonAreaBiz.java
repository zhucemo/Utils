package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfCommonArea;
import com.macroflag.plusplatform.data.inner.mapper.MfCommonAreaMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 行政区划代码对照表
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-08-06 10:16:01
 * @version : v1.0.0
 */
@Service
public class MfCommonAreaBiz extends BusinessBiz<MfCommonAreaMapper,MfCommonArea> {
}