package com.macroflag.plusplatform.data.inner.dao.impl;

import com.macroflag.plusplatform.data.inner.dao.HuluCallsDao;
import com.macroflag.plusplatform.data.inner.entity.HuluCallsDomain;
import com.macroflag.plusplatform.data.inner.mapper.HuluCallsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("huluCallsDaoImpl")
public class HuluCallsDaoImpl implements HuluCallsDao {

    @Autowired
    private HuluCallsMapper huluCallsMapper;

    @Override
    public List<HuluCallsDomain> getCallHistoryByUnique(String unique, int pageIndex, int pageSize) {
        HuluCallsDomain huluCallsDomain = new HuluCallsDomain();
        huluCallsDomain.setUniqueNo(unique);
        huluCallsDomain.setPageIndex((pageIndex - 1) * pageSize);
        huluCallsDomain.setPageSize(pageSize);
        return huluCallsMapper.getCallHistoryByUnique(huluCallsDomain);
    }

    @Override
    public List<HuluCallsDomain> getCallHistoryByUnique(String unique, int pageSize) {
        HuluCallsDomain huluCallsDomain = new HuluCallsDomain();
        huluCallsDomain.setUniqueNo(unique);
        huluCallsDomain.setPageSize(pageSize);
        return huluCallsMapper.getCallHistoryByUnique(huluCallsDomain);
    }

    @Override
    public List<HuluCallsDomain> getCallHistoryByUnique(String unique) {
        HuluCallsDomain huluCallsDomain = new HuluCallsDomain();
        huluCallsDomain.setUniqueNo(unique);
        return huluCallsMapper.getCallHistoryByUnique(huluCallsDomain);
    }

    @Override
    public int getContactTime(String phone, String otherPhone) {
        HuluCallsDomain huluCallsDomain = new HuluCallsDomain();
        huluCallsDomain.setCellPhone(phone);
        huluCallsDomain.setOtherCellPhone(otherPhone);
        return huluCallsMapper.getContactTime(huluCallsDomain).getCount();
    }

    @Override
    public List<HuluCallsDomain> getCallHistoryByPhone(String phone, int pageIndex, int pageSize) {
        HuluCallsDomain huluCallsDomain = new HuluCallsDomain();
        huluCallsDomain.setCellPhone(phone);
        huluCallsDomain.setPageIndex((pageIndex - 1) * pageSize);
        huluCallsDomain.setPageSize(pageSize);
        return huluCallsMapper.getCallHistoryByPhone(huluCallsDomain);
    }
}
