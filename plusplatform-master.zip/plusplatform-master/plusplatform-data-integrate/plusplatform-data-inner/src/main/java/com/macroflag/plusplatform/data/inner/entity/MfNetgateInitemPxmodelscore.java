package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-19 14:13:34
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_initem_pxmodelscore")
public class MfNetgateInitemPxmodelscore implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Integer id;
	
	    //业务唯一标识
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //拍拍信信用模型评分
    @Column(name = "score_sma")
    private Integer scoreSma;
	
	    //拍拍信风险等级
    @Column(name = "risk_rank")
    private String riskRank;
	
	    //拍拍信违约概率
    @Column(name = "proba_pility")
    private Double probaPility;
	
	    //拍拍信消费行为系数
    @Column(name = "consumption_confficient")
    private Double consumptionConfficient;
	
	    //拍拍信设备行为系数
    @Column(name = "device_confficient")
    private Double deviceConfficient;
	
	    //拍拍信社交行为系数
    @Column(name = "socialact_confficient")
    private Double socialactConfficient;
	
	    //预留字段1
    @Column(name = "sper1")
    private String sper1;
	
	    //预留字段2
    @Column(name = "sper2")
    private String sper2;
	
	    //预留字段3
    @Column(name = "sper3")
    private String sper3;
	
	    //预留字段4
    @Column(name = "sper4")
    private String sper4;
	
	    //创建用户
    @Column(name = "create_user")
    private Date createUser;
	
	    //创建时间
    @Column(name = "create_time")
    private Date createTime;
	
	    //更新用户
    @Column(name = "update_user")
    private Date updateUser;
	
	    //更新时间
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 设置：业务唯一标识
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：业务唯一标识
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：拍拍信信用模型评分
	 */
	public void setScoreSma(Integer scoreSma) {
		this.scoreSma = scoreSma;
	}
	/**
	 * 获取：拍拍信信用模型评分
	 */
	public Integer getScoreSma() {
		return scoreSma;
	}
	/**
	 * 设置：拍拍信风险等级
	 */
	public void setRiskRank(String riskRank) {
		this.riskRank = riskRank;
	}
	/**
	 * 获取：拍拍信风险等级
	 */
	public String getRiskRank() {
		return riskRank;
	}
	/**
	 * 设置：拍拍信违约概率
	 */
	public void setProbaPility(Double probaPility) {
		this.probaPility = probaPility;
	}
	/**
	 * 获取：拍拍信违约概率
	 */
	public Double getProbaPility() {
		return probaPility;
	}
	/**
	 * 设置：拍拍信消费行为系数
	 */
	public void setConsumptionConfficient(Double consumptionConfficient) {
		this.consumptionConfficient = consumptionConfficient;
	}
	/**
	 * 获取：拍拍信消费行为系数
	 */
	public Double getConsumptionConfficient() {
		return consumptionConfficient;
	}
	/**
	 * 设置：拍拍信设备行为系数
	 */
	public void setDeviceConfficient(Double deviceConfficient) {
		this.deviceConfficient = deviceConfficient;
	}
	/**
	 * 获取：拍拍信设备行为系数
	 */
	public Double getDeviceConfficient() {
		return deviceConfficient;
	}
	/**
	 * 设置：拍拍信社交行为系数
	 */
	public void setSocialactConfficient(Double socialactConfficient) {
		this.socialactConfficient = socialactConfficient;
	}
	/**
	 * 获取：拍拍信社交行为系数
	 */
	public Double getSocialactConfficient() {
		return socialactConfficient;
	}
	/**
	 * 设置：预留字段1
	 */
	public void setSper1(String sper1) {
		this.sper1 = sper1;
	}
	/**
	 * 获取：预留字段1
	 */
	public String getSper1() {
		return sper1;
	}
	/**
	 * 设置：预留字段2
	 */
	public void setSper2(String sper2) {
		this.sper2 = sper2;
	}
	/**
	 * 获取：预留字段2
	 */
	public String getSper2() {
		return sper2;
	}
	/**
	 * 设置：预留字段3
	 */
	public void setSper3(String sper3) {
		this.sper3 = sper3;
	}
	/**
	 * 获取：预留字段3
	 */
	public String getSper3() {
		return sper3;
	}
	/**
	 * 设置：预留字段4
	 */
	public void setSper4(String sper4) {
		this.sper4 = sper4;
	}
	/**
	 * 获取：预留字段4
	 */
	public String getSper4() {
		return sper4;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreateUser(Date createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：创建用户
	 */
	public Date getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(Date updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public Date getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
}
