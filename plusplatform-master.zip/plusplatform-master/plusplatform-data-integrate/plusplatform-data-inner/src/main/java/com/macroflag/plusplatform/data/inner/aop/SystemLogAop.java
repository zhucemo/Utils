package com.macroflag.plusplatform.data.inner.aop;

import java.lang.reflect.Method;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.macroflag.plusplatform.common.annotations.SystemLog;
import com.macroflag.plusplatform.common.exception.ExceptionUtils;
import com.macroflag.plusplatform.common.lang.Snowflake;
import com.macroflag.plusplatform.common.utils.IpUtils;
import com.macroflag.plusplatform.common.web.ResultResponse;
import com.macroflag.plusplatform.data.inner.entity.SystemLogsDomain;
import com.macroflag.plusplatform.data.inner.messages.service.ISystemLogsService;

/**
 * 系统API日志AOP
 * 
 * @author : Fredia
 * @since : 2018年4月26日
 * @version : v1.0.0
 */
@Aspect
@Order(1)
@Service
public class SystemLogAop {

	@Autowired
	private ISystemLogsService systemLogsService;

	// 配置接入点
	@Pointcut("execution(* com.macroflag.plusplatform.data.inner.controller.api..*.*(..))")
	private void controllerAspect() {
	}

	@Around("controllerAspect()")
	public Object around(ProceedingJoinPoint pjp) throws Throwable {
		// 常见日志实体对象
		SystemLogsDomain log = new SystemLogsDomain();
		// 获取登录用户账户
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();
		if (request.getMethod().equalsIgnoreCase(RequestMethod.GET.toString())) {
			String businessKey = request.getParameter("businessKey");
			log.setApplyNo(businessKey);
		} else {
			String businessKey = (String) request.getSession().getAttribute("businessKey");
			log.setApplyNo(businessKey);
		}

		// 获取系统时间
		log.setCreateTime(new Date());
		String ip = IpUtils.getIp(request);
		log.setReqIp(ip);
		log.setReqNo("LOG" + Snowflake.getMe().nextId());
		long start = System.currentTimeMillis();
		// 拦截
		Object target = pjp.getTarget();
		// 拦截的方法名称
		String methodName = pjp.getSignature().getName();
		// 拦截的方法参数
		Object[] args = pjp.getArgs();
		log.setReqParam(StringUtils.join(args));
		// 拦截的放参数类型
		Signature sig = pjp.getSignature();
		MethodSignature msig = null;
		if (!(sig instanceof MethodSignature)) {
			ExceptionUtils.throwBaseException(502, "该注解只能用于方法");
		}
		msig = (MethodSignature) sig;
		Class[] parameterTypes = msig.getMethod().getParameterTypes();

		Object object = null;
		// 获得被拦截的方法
		Method method = null;
		try {
			method = target.getClass().getMethod(methodName, parameterTypes);
		} catch (NoSuchMethodException e1) {
			ExceptionUtils.throwBaseException(500, e1.getMessage());
		} catch (SecurityException e2) {
			ExceptionUtils.throwBaseException(501, e2.getMessage());
		}
		if (null != method) {
			// 判断是否包含自定义的注解
			if (method.isAnnotationPresent(SystemLog.class)) {
				SystemLog systemlog = method.getAnnotation(SystemLog.class);
				log.setModule(systemlog.module());
				log.setMethod(systemlog.methods());
				log.setRequestMethod(systemlog.requestMethod().toString());
				log.setIsInternal(systemlog.isInternal() == true ? 1 : 0);

				try {
					object = pjp.proceed();
					long end = System.currentTimeMillis();
					// 将计算好的时间保存在实体中
					log.setRespWaitingTime("" + (end - start));
					log.setRespCode("200");
					try {
						log.setRespContent(object.toString());
					}catch (Exception e) {
						log.setRespCode("400");
					}
					systemLogsService.insert(log);
				} catch (Throwable e) {
					object = pjp.proceed();
					long end = System.currentTimeMillis();
					// 将计算好的时间保存在实体中
					log.setRespWaitingTime("" + (end - start));
					log.setRespCode("502");
					systemLogsService.insert(log);
				}
			} else {// 没有包含注解
				object = pjp.proceed();
			}
		} else { // 不需要拦截直接执行
			object = pjp.proceed();
		}
		return object;
	}
}