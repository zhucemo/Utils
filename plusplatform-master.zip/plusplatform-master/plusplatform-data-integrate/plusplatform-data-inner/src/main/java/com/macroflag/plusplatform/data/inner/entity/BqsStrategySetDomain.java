package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 白骑士策略集规则明细的domain
 * @author : huangf
 * @since : 2018年04月25日
 * @version : v0.0.1
 */
public class BqsStrategySetDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键id*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/**/
	private String flowno;
	
	/*策略名称*/
	private String strategyName;
	
	/*策略id*/
	private String strategyId;
	
	/*策略决策结果*/
	private String strategyDecision;
	
	/*策略匹配模式*/
	private String strategyMode;
	
	/*策略风险系数*/
	private Integer strategyScore;
	
	/*策略风险类型*/
	private String riskType;
	
	/*策略击中话术提示*/
	private String tips;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段*/
	private String spare2;
	
	/*预留字段*/
	private String spare3;
	
	/*预留字段*/
	private String spare4;
	
	/*创建用户*/
	private Long creatUser;
	
	/*创建时间*/
	private Date creatTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getFlowno(){
		return flowno;
	}
	
	public void setFlowno(String flowno){
		this.flowno = flowno;
	}
	
	public String getStrategyName(){
		return strategyName;
	}
	
	public void setStrategyName(String strategyName){
		this.strategyName = strategyName;
	}
	
	public String getStrategyId(){
		return strategyId;
	}
	
	public void setStrategyId(String strategyId){
		this.strategyId = strategyId;
	}
	
	public String getStrategyDecision(){
		return strategyDecision;
	}
	
	public void setStrategyDecision(String strategyDecision){
		this.strategyDecision = strategyDecision;
	}
	
	public String getStrategyMode(){
		return strategyMode;
	}
	
	public void setStrategyMode(String strategyMode){
		this.strategyMode = strategyMode;
	}
	
	public Integer getStrategyScore(){
		return strategyScore;
	}
	
	public void setStrategyScore(Integer strategyScore){
		this.strategyScore = strategyScore;
	}
	
	public String getRiskType(){
		return riskType;
	}
	
	public void setRiskType(String riskType){
		this.riskType = riskType;
	}
	
	public String getTips(){
		return tips;
	}
	
	public void setTips(String tips){
		this.tips = tips;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreatUser(){
		return creatUser;
	}
	
	public void setCreatUser(Long creatUser){
		this.creatUser = creatUser;
	}
	
	public Date getCreatTime(){
		return creatTime;
	}
	
	public void setCreatTime(Date creatTime){
		this.creatTime = creatTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
