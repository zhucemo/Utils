package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-08-03 16:32:51
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_cupd_tax_code")
public class MfNetgateCupdTaxCode implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Long id;
	
	    //用户唯一标识
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //响应码
    @Column(name = "code")
    private String code;
	
	    //系统查询时间
    @Column(name = "query_time")
    private Date queryTime;
	
	    //查询流水号
    @Column(name = "serial_id")
    private String serialId;
	
	    //返回时间
    @Column(name = "response_time")
    private Date responseTime;
	
	    //银行号
    @Column(name = "bank_code")
    private String bankCode;
	
	    //机构号
    @Column(name = "inst_code")
    private String instCode;
	
	    //系统id
    @Column(name = "system_id")
    private String systemId;
	
	    //结果信息
    @Column(name = "result")
    private String result;
	
	    //创建用户
    @Column(name = "create_user")
    private String createUser;
	
	    //创建时间
    @Column(name = "create_time")
    private Date createTime;
	
	    //更新用户
    @Column(name = "update_user")
    private String updateUser;
	
	    //update_time
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：用户唯一标识
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：用户唯一标识
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：响应码
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * 获取：响应码
	 */
	public String getCode() {
		return code;
	}
	/**
	 * 设置：系统查询时间
	 */
	public void setQueryTime(Date queryTime) {
		this.queryTime = queryTime;
	}
	/**
	 * 获取：系统查询时间
	 */
	public Date getQueryTime() {
		return queryTime;
	}
	/**
	 * 设置：查询流水号
	 */
	public void setSerialId(String serialId) {
		this.serialId = serialId;
	}
	/**
	 * 获取：查询流水号
	 */
	public String getSerialId() {
		return serialId;
	}
	/**
	 * 设置：返回时间
	 */
	public void setResponseTime(Date responseTime) {
		this.responseTime = responseTime;
	}
	/**
	 * 获取：返回时间
	 */
	public Date getResponseTime() {
		return responseTime;
	}
	/**
	 * 设置：银行号
	 */
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	/**
	 * 获取：银行号
	 */
	public String getBankCode() {
		return bankCode;
	}
	/**
	 * 设置：机构号
	 */
	public void setInstCode(String instCode) {
		this.instCode = instCode;
	}
	/**
	 * 获取：机构号
	 */
	public String getInstCode() {
		return instCode;
	}
	/**
	 * 设置：系统id
	 */
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}
	/**
	 * 获取：系统id
	 */
	public String getSystemId() {
		return systemId;
	}
	/**
	 * 设置：结果信息
	 */
	public void setResult(String result) {
		this.result = result;
	}
	/**
	 * 获取：结果信息
	 */
	public String getResult() {
		return result;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：创建用户
	 */
	public String getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public String getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：update_time
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：update_time
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
}
