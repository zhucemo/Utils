package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgatePpxinModelscore;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgatePpxinModelscoreMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-19 10:55:25
 * @version : v1.0.0
 */
@Service
public class MfNetgatePpxinModelscoreBiz extends BusinessBiz<MfNetgatePpxinModelscoreMapper,MfNetgatePpxinModelscore> {

	private MfNetgatePpxinModelscoreMapper mfNetgatePpxinModelscoreMapper;
	
	public MfNetgatePpxinModelscore getOne(String uniqueNo) {
		
		MfNetgatePpxinModelscore record = new MfNetgatePpxinModelscore();
		
		record.setUniqueNo(uniqueNo);
		
		return mfNetgatePpxinModelscoreMapper.selectOne(record);
	}
}