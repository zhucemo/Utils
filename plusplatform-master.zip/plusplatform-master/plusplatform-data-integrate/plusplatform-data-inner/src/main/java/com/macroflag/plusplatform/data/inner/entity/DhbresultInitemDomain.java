package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 贷后邦规则输入项的domain
 * @author : huangf
 * @since : 2018年04月25日
 * @version : v0.0.1
 */
public class DhbresultInitemDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键id*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*贷后邦近6个月累计通话时长*/
	private Integer callPeriodsumin180d;
	
	/*贷后邦近6个月累计通话次数*/
	private Integer callCntin180d;
	
	/*贷后邦近6个月不重复通话对端数*/
	private Integer numberCntin180d;
	
	/*贷后邦手机号出现在金融机构黑名单*/
	private String isMobileinfinBlacklist;
	
	/*贷后邦身份证出现在金融机构黑名单*/
	private String isIdinfinBlacklist;
	
	/*贷后邦身份证出现在法院黑名单*/
	private String isIdincourtBlacklist;
	
	/*贷后邦最早一次通话距今天数*/
	private Integer earliestCallDays;
	
	/*贷后邦近3个月p2p通话机构数*/
	private Integer p2pNumberCntin90d;
	
	/*贷后邦近3个月主动p2p机构数*/
	private Integer p2pOutNumberCntin90d;
	
	/*贷后邦近3个月被动p2p机构数*/
	private Integer p2pInNumberCntin90d;
	
	/*贷后邦近3月外包催收通数*/
	private Integer outCollcallCntin90d;
	
	/*贷后邦近1月银行催收通数*/
	private Integer bankCollcallCntin30d;
	
	/*贷后邦近1月非银行催收通数*/
	private Integer nonBankCollcallCntin30d;
	
	/*贷后邦近3月赌博通话对端数*/
	private Integer gambleCollNumberCntin90d;
	
	/*贷后邦近3月赌博通话通数*/
	private Integer gambleCollcallCntin90d;
	
	/*贷后邦近1月非银行催收机构数*/
	private Integer nonBankCollNumberCntin30d;
	
	/*贷后邦30天主动通话记录赌博号码数*/
	private Integer gambleColloutCallCntin30d;
	
	/*贷后邦30天被动通话记录赌博号码数*/
	private Integer gambleCollinCallCntin30d;
	
	/*贷后邦通话记录匹配内部黑名单数*/
	private Integer hlblcellsCount;
	
	/*贷后邦催收电话记录数*/
	private Integer collNumbercnt;
	
	/*贷后邦常用联系人手机内部黑名单*/
	private String oftenCallHitbl;
	
	/*贷后邦总活跃天数*/
	private Integer activeDays;
	
	/*贷后邦常用联系人手机匹配赌博电话库*/
	private String oftenCallHitgamble;
	
	/*贷后邦其他联系人手机号命中阿里小号*/
	private String oftenCallsMallno;
	
	/*贷后邦常用联系人手机内部灰名单*/
	private String hlblgOftenCallhitbl;
	
	/*贷后邦通话记录匹配内部灰名单数*/
	private Integer hlblgCellsCount;
	
	/*近180天通话对端数匹配灰及以上名单个数*/
	private Integer hlblgNumberCntin180d;
	
	/*贷后邦常用联系人手机内部疑似黑名单*/
	private String hlblysOftenCallhitbl;
	
	/*贷后邦通话记录匹配内部疑似黑名单数*/
	private Integer hlblysCellsCount;
	
	/*贷后邦通话对端数匹配内部疑似黑名单数*/
	private Integer hlblysNumberCntin180d;
	
	/*贷后邦通话对端数匹配内部黑名单数*/
	private Integer hlblNumberCntin180d;
	
	/*贷后邦近3月代办中介机构数*/
	private Integer agentNumberCntin90d;
	
	/*贷后邦近1月代办中介通数*/
	private Integer agentCallCntin30d;
	
	/*贷后邦近3月代办中介通数*/
	private Integer agentCallCntin90d;
	
	/*贷后邦常用联系人电话号码精确匹配中介数据库 */
	private Integer oftenCallHitagent;
	
	/*常用联系人命中电话疑似灰名单*/
	private String rgblysgOftenCallhitbl;
	
	/*通话记录匹配疑似灰名单个数*/
	private Integer rgblysgCellsCount;
	
	/*近180天匹配疑似灰名单对端数*/
	private Integer rgblysgNumberCntin180d;
	
	/*贷后邦通话对端数匹配内部灰名单数*/
	private Integer rgblgNumberCntin180d;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public Integer getCallPeriodsumin180d(){
		return callPeriodsumin180d;
	}
	
	public void setCallPeriodsumin180d(Integer callPeriodsumin180d){
		this.callPeriodsumin180d = callPeriodsumin180d;
	}
	
	public Integer getCallCntin180d(){
		return callCntin180d;
	}
	
	public void setCallCntin180d(Integer callCntin180d){
		this.callCntin180d = callCntin180d;
	}
	
	public Integer getNumberCntin180d(){
		return numberCntin180d;
	}
	
	public void setNumberCntin180d(Integer numberCntin180d){
		this.numberCntin180d = numberCntin180d;
	}
	
	public String getIsMobileinfinBlacklist(){
		return isMobileinfinBlacklist;
	}
	
	public void setIsMobileinfinBlacklist(String isMobileinfinBlacklist){
		this.isMobileinfinBlacklist = isMobileinfinBlacklist;
	}
	
	public String getIsIdinfinBlacklist(){
		return isIdinfinBlacklist;
	}
	
	public void setIsIdinfinBlacklist(String isIdinfinBlacklist){
		this.isIdinfinBlacklist = isIdinfinBlacklist;
	}
	
	public String getIsIdincourtBlacklist(){
		return isIdincourtBlacklist;
	}
	
	public void setIsIdincourtBlacklist(String isIdincourtBlacklist){
		this.isIdincourtBlacklist = isIdincourtBlacklist;
	}
	
	public Integer getEarliestCallDays(){
		return earliestCallDays;
	}
	
	public void setEarliestCallDays(Integer earliestCallDays){
		this.earliestCallDays = earliestCallDays;
	}
	
	public Integer getP2pNumberCntin90d(){
		return p2pNumberCntin90d;
	}
	
	public void setP2pNumberCntin90d(Integer p2pNumberCntin90d){
		this.p2pNumberCntin90d = p2pNumberCntin90d;
	}
	
	public Integer getP2pOutNumberCntin90d(){
		return p2pOutNumberCntin90d;
	}
	
	public void setP2pOutNumberCntin90d(Integer p2pOutNumberCntin90d){
		this.p2pOutNumberCntin90d = p2pOutNumberCntin90d;
	}
	
	public Integer getP2pInNumberCntin90d(){
		return p2pInNumberCntin90d;
	}
	
	public void setP2pInNumberCntin90d(Integer p2pInNumberCntin90d){
		this.p2pInNumberCntin90d = p2pInNumberCntin90d;
	}
	
	public Integer getOutCollcallCntin90d(){
		return outCollcallCntin90d;
	}
	
	public void setOutCollcallCntin90d(Integer outCollcallCntin90d){
		this.outCollcallCntin90d = outCollcallCntin90d;
	}
	
	public Integer getBankCollcallCntin30d(){
		return bankCollcallCntin30d;
	}
	
	public void setBankCollcallCntin30d(Integer bankCollcallCntin30d){
		this.bankCollcallCntin30d = bankCollcallCntin30d;
	}
	
	public Integer getNonBankCollcallCntin30d(){
		return nonBankCollcallCntin30d;
	}
	
	public void setNonBankCollcallCntin30d(Integer nonBankCollcallCntin30d){
		this.nonBankCollcallCntin30d = nonBankCollcallCntin30d;
	}
	
	public Integer getGambleCollNumberCntin90d(){
		return gambleCollNumberCntin90d;
	}
	
	public void setGambleCollNumberCntin90d(Integer gambleCollNumberCntin90d){
		this.gambleCollNumberCntin90d = gambleCollNumberCntin90d;
	}
	
	public Integer getGambleCollcallCntin90d(){
		return gambleCollcallCntin90d;
	}
	
	public void setGambleCollcallCntin90d(Integer gambleCollcallCntin90d){
		this.gambleCollcallCntin90d = gambleCollcallCntin90d;
	}
	
	public Integer getNonBankCollNumberCntin30d(){
		return nonBankCollNumberCntin30d;
	}
	
	public void setNonBankCollNumberCntin30d(Integer nonBankCollNumberCntin30d){
		this.nonBankCollNumberCntin30d = nonBankCollNumberCntin30d;
	}
	
	public Integer getGambleColloutCallCntin30d(){
		return gambleColloutCallCntin30d;
	}
	
	public void setGambleColloutCallCntin30d(Integer gambleColloutCallCntin30d){
		this.gambleColloutCallCntin30d = gambleColloutCallCntin30d;
	}
	
	public Integer getGambleCollinCallCntin30d(){
		return gambleCollinCallCntin30d;
	}
	
	public void setGambleCollinCallCntin30d(Integer gambleCollinCallCntin30d){
		this.gambleCollinCallCntin30d = gambleCollinCallCntin30d;
	}
	
	public Integer getHlblcellsCount(){
		return hlblcellsCount;
	}
	
	public void setHlblcellsCount(Integer hlblcellsCount){
		this.hlblcellsCount = hlblcellsCount;
	}
	
	public Integer getCollNumbercnt(){
		return collNumbercnt;
	}
	
	public void setCollNumbercnt(Integer collNumbercnt){
		this.collNumbercnt = collNumbercnt;
	}
	
	public String getOftenCallHitbl(){
		return oftenCallHitbl;
	}
	
	public void setOftenCallHitbl(String oftenCallHitbl){
		this.oftenCallHitbl = oftenCallHitbl;
	}
	
	public Integer getActiveDays(){
		return activeDays;
	}
	
	public void setActiveDays(Integer activeDays){
		this.activeDays = activeDays;
	}
	
	public String getOftenCallHitgamble(){
		return oftenCallHitgamble;
	}
	
	public void setOftenCallHitgamble(String oftenCallHitgamble){
		this.oftenCallHitgamble = oftenCallHitgamble;
	}
	
	public String getOftenCallsMallno(){
		return oftenCallsMallno;
	}
	
	public void setOftenCallsMallno(String oftenCallsMallno){
		this.oftenCallsMallno = oftenCallsMallno;
	}
	
	public String getHlblgOftenCallhitbl(){
		return hlblgOftenCallhitbl;
	}
	
	public void setHlblgOftenCallhitbl(String hlblgOftenCallhitbl){
		this.hlblgOftenCallhitbl = hlblgOftenCallhitbl;
	}
	
	public Integer getHlblgCellsCount(){
		return hlblgCellsCount;
	}
	
	public void setHlblgCellsCount(Integer hlblgCellsCount){
		this.hlblgCellsCount = hlblgCellsCount;
	}
	
	public Integer getHlblgNumberCntin180d(){
		return hlblgNumberCntin180d;
	}
	
	public void setHlblgNumberCntin180d(Integer hlblgNumberCntin180d){
		this.hlblgNumberCntin180d = hlblgNumberCntin180d;
	}
	
	public String getHlblysOftenCallhitbl(){
		return hlblysOftenCallhitbl;
	}
	
	public void setHlblysOftenCallhitbl(String hlblysOftenCallhitbl){
		this.hlblysOftenCallhitbl = hlblysOftenCallhitbl;
	}
	
	public Integer getHlblysCellsCount(){
		return hlblysCellsCount;
	}
	
	public void setHlblysCellsCount(Integer hlblysCellsCount){
		this.hlblysCellsCount = hlblysCellsCount;
	}
	
	public Integer getHlblysNumberCntin180d(){
		return hlblysNumberCntin180d;
	}
	
	public void setHlblysNumberCntin180d(Integer hlblysNumberCntin180d){
		this.hlblysNumberCntin180d = hlblysNumberCntin180d;
	}
	
	public Integer getHlblNumberCntin180d(){
		return hlblNumberCntin180d;
	}
	
	public void setHlblNumberCntin180d(Integer hlblNumberCntin180d){
		this.hlblNumberCntin180d = hlblNumberCntin180d;
	}
	
	public Integer getAgentNumberCntin90d(){
		return agentNumberCntin90d;
	}
	
	public void setAgentNumberCntin90d(Integer agentNumberCntin90d){
		this.agentNumberCntin90d = agentNumberCntin90d;
	}
	
	public Integer getAgentCallCntin30d(){
		return agentCallCntin30d;
	}
	
	public void setAgentCallCntin30d(Integer agentCallCntin30d){
		this.agentCallCntin30d = agentCallCntin30d;
	}
	
	public Integer getAgentCallCntin90d(){
		return agentCallCntin90d;
	}
	
	public void setAgentCallCntin90d(Integer agentCallCntin90d){
		this.agentCallCntin90d = agentCallCntin90d;
	}
	
	public Integer getOftenCallHitagent(){
		return oftenCallHitagent;
	}
	
	public void setOftenCallHitagent(Integer oftenCallHitagent){
		this.oftenCallHitagent = oftenCallHitagent;
	}
	
	public String getRgblysgOftenCallhitbl(){
		return rgblysgOftenCallhitbl;
	}
	
	public void setRgblysgOftenCallhitbl(String rgblysgOftenCallhitbl){
		this.rgblysgOftenCallhitbl = rgblysgOftenCallhitbl;
	}
	
	public Integer getRgblysgCellsCount(){
		return rgblysgCellsCount;
	}
	
	public void setRgblysgCellsCount(Integer rgblysgCellsCount){
		this.rgblysgCellsCount = rgblysgCellsCount;
	}
	
	public Integer getRgblysgNumberCntin180d(){
		return rgblysgNumberCntin180d;
	}
	
	public void setRgblysgNumberCntin180d(Integer rgblysgNumberCntin180d){
		this.rgblysgNumberCntin180d = rgblysgNumberCntin180d;
	}
	
	public Integer getRgblgNumberCntin180d(){
		return rgblgNumberCntin180d;
	}
	
	public void setRgblgNumberCntin180d(Integer rgblgNumberCntin180d){
		this.rgblgNumberCntin180d = rgblgNumberCntin180d;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
