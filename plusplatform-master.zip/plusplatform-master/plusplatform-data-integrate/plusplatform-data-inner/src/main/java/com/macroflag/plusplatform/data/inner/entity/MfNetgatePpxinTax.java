package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-19 10:55:24
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_ppxin_tax")
public class MfNetgatePpxinTax implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Integer id;
	
	    //
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //结果
    @Column(name = "result")
    private String result;
	
	    //查询状态
    @Column(name = "query_status")
    private String queryStatus;
	
	    //查询状态描述
    @Column(name = "query_status_sext")
    private String queryStatusSext;
	
	    //错误信息码
    @Column(name = "error_code")
    private String errorCode;
	
	    //错误信息
    @Column(name = "error_msg")
    private String errorMsg;
	
	    //预留字段1
    @Column(name = "spare1")
    private String spare1;
	
	    //预留字段2
    @Column(name = "spare2")
    private String spare2;
	
	    //预留字段3
    @Column(name = "spare3")
    private String spare3;
	
	    //预留字段4
    @Column(name = "spare4")
    private String spare4;
	
	    //创建用户
    @Column(name = "creat_user")
    private Date creatUser;
	
	    //创建时间
    @Column(name = "creat_time")
    private Date creatTime;
	
	    //更新用户
    @Column(name = "update_user")
    private Date updateUser;
	
	    //更新时间
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 设置：
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：结果
	 */
	public void setResult(String result) {
		this.result = result;
	}
	/**
	 * 获取：结果
	 */
	public String getResult() {
		return result;
	}
	/**
	 * 设置：查询状态
	 */
	public void setQueryStatus(String queryStatus) {
		this.queryStatus = queryStatus;
	}
	/**
	 * 获取：查询状态
	 */
	public String getQueryStatus() {
		return queryStatus;
	}
	/**
	 * 设置：查询状态描述
	 */
	public void setQueryStatusSext(String queryStatusSext) {
		this.queryStatusSext = queryStatusSext;
	}
	/**
	 * 获取：查询状态描述
	 */
	public String getQueryStatusSext() {
		return queryStatusSext;
	}
	/**
	 * 设置：错误信息码
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * 获取：错误信息码
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * 设置：错误信息
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	/**
	 * 获取：错误信息
	 */
	public String getErrorMsg() {
		return errorMsg;
	}
	/**
	 * 设置：预留字段1
	 */
	public void setSpare1(String spare1) {
		this.spare1 = spare1;
	}
	/**
	 * 获取：预留字段1
	 */
	public String getSpare1() {
		return spare1;
	}
	/**
	 * 设置：预留字段2
	 */
	public void setSpare2(String spare2) {
		this.spare2 = spare2;
	}
	/**
	 * 获取：预留字段2
	 */
	public String getSpare2() {
		return spare2;
	}
	/**
	 * 设置：预留字段3
	 */
	public void setSpare3(String spare3) {
		this.spare3 = spare3;
	}
	/**
	 * 获取：预留字段3
	 */
	public String getSpare3() {
		return spare3;
	}
	/**
	 * 设置：预留字段4
	 */
	public void setSpare4(String spare4) {
		this.spare4 = spare4;
	}
	/**
	 * 获取：预留字段4
	 */
	public String getSpare4() {
		return spare4;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreatUser(Date creatUser) {
		this.creatUser = creatUser;
	}
	/**
	 * 获取：创建用户
	 */
	public Date getCreatUser() {
		return creatUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreatTime(Date creatTime) {
		this.creatTime = creatTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreatTime() {
		return creatTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(Date updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public Date getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
}
