package com.macroflag.plusplatform.data.inner.dao;

import com.macroflag.plusplatform.data.inner.entity.HuluBasicDomain;

import java.util.ArrayList;
import java.util.List;

public interface HuluBasicDao {
    HuluBasicDomain getOneByUnique(String uniqueNo);

    List<HuluBasicDomain> sameRealName(HuluBasicDomain huluBasicDomain);

    default List<HuluBasicDomain> sameRealName(String uniqueNo) {
        HuluBasicDomain huluBasic = getOneByUnique(uniqueNo);
        if (huluBasic == null)
            return new ArrayList<>();
        return sameRealName(huluBasic);
    }
}
