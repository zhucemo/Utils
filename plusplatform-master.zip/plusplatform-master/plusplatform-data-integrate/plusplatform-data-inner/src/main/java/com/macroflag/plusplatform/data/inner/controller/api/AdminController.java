package com.macroflag.plusplatform.data.inner.controller.api;

import com.alibaba.fastjson.JSONArray;
import com.macroflag.plusplatform.common.util.LogUtil;
import com.macroflag.plusplatform.data.inner.entity.MfNetgateAcct;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateAcctMapper;
import com.macroflag.plusplatform.data.inner.service.CallRecordService;
import com.macroflag.plusplatform.data.inner.service.RealNameService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("admin")
@Slf4j
public class AdminController {

    @Autowired
    private MfNetgateAcctMapper netgateAcctMapper;

    @Autowired
    @Qualifier("callRecordServiceImpl")
    private CallRecordService callRecordService;

    @Autowired
    @Qualifier("realNameServiceImpl")
    private RealNameService realNameService;

    @PostMapping("getCallBlackOrYellow")
    public JSONArray getCallBlackOrYellow(@RequestParam String phoneNo) {
        JSONArray result = callRecordService.callHitBlackYellow(phoneNo);
        return result;
    }

    @PostMapping("getSameRealNameInBY")
    public JSONArray getSameRealNameInBY(@RequestParam String phoneNo, @RequestParam String idCard) {
        JSONArray result;
        MfNetgateAcct netgateAcct = new MfNetgateAcct();
        netgateAcct.setPhone(phoneNo);
        netgateAcct.setIdCard(idCard);
        netgateAcct = netgateAcctMapper.getLast(netgateAcct);
        if (netgateAcct == null) {
            log.warn("dataInner未找到相应客户:", LogUtil.CodeInfo());
            return new JSONArray();
        }
        result = realNameService.getSameRealNameInBY(netgateAcct.getUniqueNo());
        return result;
    }

}
