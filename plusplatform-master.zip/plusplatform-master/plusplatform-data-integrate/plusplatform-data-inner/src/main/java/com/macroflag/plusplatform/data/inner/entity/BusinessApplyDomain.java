package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 业务申请表的domain
 * 
 * @author : fredia
 * @since : 2018年04月28日
 * @version : v0.0.1
 */
public class BusinessApplyDomain implements Serializable {

	private static final long serialVersionUID = 1L;

	/**/
	private Long id;

	/* 申请单号 */
	private String applyNo;

	/* 用户唯一标示 */
	private String uniqueNo;

	/* 产品编号 */
	private String productNo;

	/*
	 * 准入申请状态: RGSHZT_TG通过 RGSHZT_JJ 拒绝 RGSHZT_SPZ 审批中 RGSHZT_WSP 未审批
	 */
	private String applyStatus;

	/*
	 * 人工审核状态,不传则返回所有状态订单 还需业务确定： RGSHZT_TG通过 RGSHZT_JJ 拒绝 RGSHZT_SPZ 审批中
	 * RGSHZT_WSP 未审批
	 * 
	 * 
	 * 
	 */
	private String approvalStatus;

	/* 流程id */
	private String flowId;

	/* 申请资料状态 */
	private String infoStatus;

	/* 进件标识 JJBS_ZD自动 JJBS_RG 人工 */
	private String entryType;

	/**/
	private String spare1;

	/**/
	private String spare2;

	/**/
	private String spare3;

	/**/
	private String spare4;

	/* 创建时间 */
	private Date createTime;

	/**/
	private Long createUser;

	/**/
	private Date updateTime;

	/**/
	private Long updateUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getApplyNo() {
		return applyNo;
	}

	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}

	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

	public String getApplyStatus() {
		return applyStatus;
	}

	public void setApplyStatus(String applyStatus) {
		this.applyStatus = applyStatus;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getFlowId() {
		return flowId;
	}

	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}

	public String getInfoStatus() {
		return infoStatus;
	}

	public void setInfoStatus(String infoStatus) {
		this.infoStatus = infoStatus;
	}

	public String getEntryType() {
		return entryType;
	}

	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}

	public String getSpare1() {
		return spare1;
	}

	public void setSpare1(String spare1) {
		this.spare1 = spare1;
	}

	public String getSpare2() {
		return spare2;
	}

	public void setSpare2(String spare2) {
		this.spare2 = spare2;
	}

	public String getSpare3() {
		return spare3;
	}

	public void setSpare3(String spare3) {
		this.spare3 = spare3;
	}

	public String getSpare4() {
		return spare4;
	}

	public void setSpare4(String spare4) {
		this.spare4 = spare4;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Long getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Long updateUser) {
		this.updateUser = updateUser;
	}

}
