package com.macroflag.plusplatform.data.inner.config.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.common.core.service.impl.BaseServiceImpl;
import com.macroflag.plusplatform.data.inner.entity.ApiConfigDomain;
import com.macroflag.plusplatform.data.inner.mapper.ApiConfigMapper;
import com.macroflag.plusplatform.data.inner.query.ApiConfigQuery;
import com.macroflag.plusplatform.data.inner.config.service.IApiConfigService;

/**
 * 接口配置表的业务实现类
 * 
 * @author : Fredia
 * @since : 2018年05月09日
 * @version : v0.0.1
 */
@Service("apiConfigService")
public class ApiConfigServiceImpl extends BaseServiceImpl<ApiConfigDomain> implements IApiConfigService {

	@Autowired
	private ApiConfigMapper apiConfigMapper;
	private static Logger logger = LoggerFactory.getLogger(ApiConfigServiceImpl.class);

	@Override
	public ApiConfigDomain getApiConfig(String apiCode) {

		logger.info("#########获取API数据模型#########");

		ApiConfigQuery apiConfigQuery = new ApiConfigQuery();
		apiConfigQuery.setApiCode(apiCode);
		return apiConfigMapper.getOne(apiConfigQuery);

	}

}
