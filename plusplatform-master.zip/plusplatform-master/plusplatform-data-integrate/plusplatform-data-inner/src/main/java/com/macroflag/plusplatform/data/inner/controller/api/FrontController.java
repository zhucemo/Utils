package com.macroflag.plusplatform.data.inner.controller.api;

import com.alibaba.fastjson.JSONObject;
import com.macroflag.plusplatform.common.component.SysConfigCache;
import com.macroflag.plusplatform.common.enums.PrefixEnums;
import com.macroflag.plusplatform.common.exception.BaseException;
import com.macroflag.plusplatform.common.exception.ExceptionUtils;
import com.macroflag.plusplatform.common.lang.Snowflake;
import com.macroflag.plusplatform.common.model.*;
import com.macroflag.plusplatform.common.model.req.*;
import com.macroflag.plusplatform.common.model.resp.*;
import com.macroflag.plusplatform.common.sys.service.ICommonEnumsService;
import com.macroflag.plusplatform.common.utils.DateUtils;
import com.macroflag.plusplatform.data.inner.biz.MfNetgateAcctBiz;
import com.macroflag.plusplatform.data.inner.dictionary.service.IParamsDictionaryService;
import com.macroflag.plusplatform.data.inner.entity.MfNetgateAcct;
import com.macroflag.plusplatform.data.inner.feign.InnerDataService;
import com.macroflag.plusplatform.data.inner.internal.component.IBlackListInnerService;
import com.macroflag.plusplatform.data.inner.rule.service.IDeclineCodeService;
import com.macroflag.plusplatform.data.inner.service.CallRecordService;
import com.macroflag.plusplatform.data.inner.thirdpart.component.ICupdPartyService;
import com.macroflag.plusplatform.data.inner.thirdpart.component.IDubboHuluService;
import com.macroflag.plusplatform.data.inner.thirdpart.model.ReqFrontDateModel;
import com.macroflag.plusplatform.data.inner.thirdpart.model.UserDataModel;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/inner")
public class FrontController {

    private static Logger logger = LoggerFactory.getLogger(FrontController.class);

    @Autowired
    private IDubboHuluService dubboHuluService;
    @Autowired
    private ICupdPartyService cupdPartyService;
    @Autowired
    private MfNetgateAcctBiz mfNetgateAcctBiz;
    @Autowired
    private IDeclineCodeService declineCodeService;
    @Autowired
    private IParamsDictionaryService paramsDictionaryService;
    @Autowired
    private InnerDataService innerDataService;
    @Autowired
    private ICommonEnumsService commonEnumsService;
    @Autowired
    private SysConfigCache sysConfigCache;

    @Autowired
    private IBlackListInnerService blackListInnerService;

    @Autowired
    @Qualifier("callRecordServiceImpl")
    private CallRecordService callRecordService;

    /**
     * 发送CUPD CQ1验证手机号
     *
     * @param json
     * @return
     */
    @PostMapping(value = "/phoneVerify")
    public PhoneVerifyModel phoneVerify(@RequestBody ReqSmsModel reqSmsModel) {
        logger.info("phoneVerify接收前端数据=====" + reqSmsModel.getBusinessKey() + ":" + reqSmsModel.getMobile() + ":" + reqSmsModel.getContent());
        ReqFrontDateModel reqFrontDateModel = new ReqFrontDateModel();
        reqFrontDateModel.setBusinessKey(reqSmsModel.getBusinessKey());
        reqFrontDateModel.setPhone(reqSmsModel.getMobile());
        reqFrontDateModel.setToken(reqSmsModel.getContent());
        reqFrontDateModel.setProductNo(reqSmsModel.getProductNo());
        PhoneVerifyModel phoneVerifyModel = cupdPartyService.phoneVerify(reqFrontDateModel);
        return phoneVerifyModel;

    }

    /**
     * CQ2 白名单验证
     *
     * @param json
     * @return
     */
    @PostMapping("/whriteList")
    public WhriteListModel whriteList(@RequestBody ReqIdCartWhriteListModel reqIdCartWhriteListModel) {
        ReqFrontDateModel reqFrontDateModel = new ReqFrontDateModel();
        reqFrontDateModel.setBusinessKey(reqIdCartWhriteListModel.getBusinessKey());
        reqFrontDateModel.setPhone(reqIdCartWhriteListModel.getPhoneNum());
        reqFrontDateModel.setName(reqIdCartWhriteListModel.getUserName());
        reqFrontDateModel.setDocumentno(reqIdCartWhriteListModel.getIdCard());
        reqFrontDateModel.setProductNo(reqIdCartWhriteListModel.getProductNo());
        WhriteListModel whriteListModel = cupdPartyService.whriteList(reqFrontDateModel);
        return whriteListModel;

    }


    /**
     * 发送运营商服务密码
     */
    @PostMapping("/serverPwdCerify")
    public RespPwdCerifyModel serverPwdCerify(@RequestBody ReqPwdCerifyModel reqPwdCerifyModel) {
        logger.info("********发送运营商服务密码********");
        ReqFrontDateModel reqFrontDateModel = new ReqFrontDateModel();
        reqFrontDateModel.setBusinessKey(reqPwdCerifyModel.getBusinessKey());
        reqFrontDateModel.setName(reqPwdCerifyModel.getUserName());
        reqFrontDateModel.setDocumentno(reqPwdCerifyModel.getIdCard());
        reqFrontDateModel.setPhone(reqPwdCerifyModel.getPhoneNum());
        reqFrontDateModel.setServerPwd(reqPwdCerifyModel.getServerPwd());
        RespPwdCerifyModel respPwdCerifyModel = dubboHuluService.serverPwdCerify(reqFrontDateModel);
        return respPwdCerifyModel;

    }


    /**
     * 提交登录(或查询详单)短信验证码接口
     */
    @PostMapping("/submitCaptcha")
    public RespSubmitCaptchaModel submitCaptcha(@RequestBody ReqSubmitCaptchaModel reqSubmitCaptchaModel) {
        logger.info("********提交登录(或查询详单)短信验证码接口********");
        ReqFrontDateModel reqFrontDateModel = new ReqFrontDateModel();
        reqFrontDateModel.setBusinessKey(reqSubmitCaptchaModel.getBusinessKey());
        reqFrontDateModel.setToken(reqSubmitCaptchaModel.getToken());
        reqFrontDateModel.setCaptcha(reqSubmitCaptchaModel.getCaptcha());
        RespSubmitCaptchaModel respSubmitCaptchaModel = dubboHuluService.submitCaptcha(reqFrontDateModel);
        return respSubmitCaptchaModel;
    }


    /**
     * 通知规则引擎执行规则
     *
     * @param ruleExcuteReqModel
     * @return
     * @throws Exception
     */
    @PostMapping("/postData")
    public CupdRespModel postData(@RequestBody InnerDataBaseModel innerDataBaseModel) throws Exception {
        RuleExcuteReqModel ruleExcuteReqModel = new RuleExcuteReqModel();

        //身份证号
        String documentno = innerDataBaseModel.getDocumentno();
        //手机号
        String phone = innerDataBaseModel.getPhone();
        String username = innerDataBaseModel.getName();
        String applyNo = innerDataBaseModel.getBusinessKey();
        String productNo = innerDataBaseModel.getProCode();

        //构建 reqparam添加基础属性
        Map<Object, Object> reqs = new Hashtable<Object, Object>();
        reqs.put("phone", phone);
        reqs.put("name", username);
        reqs.put("documentno", documentno);
        reqs.put("proCode", innerDataBaseModel.getProCode());
        reqs.put("businessKey", applyNo);

        //根据身份证和手机号查询第三方数据用户标识是否存在该用户数据
        MfNetgateAcct entity = new MfNetgateAcct();
        entity.setIdCard(documentno);
        entity.setPhone(phone);
        List<MfNetgateAcct> mfNetgateAcctList = mfNetgateAcctBiz.selectList(entity);

        String primaryKey = null;
        entity.setProductNo(productNo);
        entity.setCreateTime(DateUtils.now());
        entity.setUserName(username);
        entity.setApplyNo(applyNo);
        if (mfNetgateAcctList.isEmpty()) {
            //未查到数据生成第三方数据查询标识
            primaryKey = PrefixEnums.JQID.getDescription() + Snowflake.getMe().nextId();
            //用户三方数据标识号
            entity.setUniqueNo(primaryKey);
            //插入用户数据唯一标识表
            mfNetgateAcctBiz.insertSelective(entity);
        } else {
            logger.info("###查询库计算第三方数据查询唯一标识生命周期###");
            //获取第三方数据保存限制时间
            Long expire = Long.valueOf(sysConfigCache.getSysConfig("data.life.cycle"));
            if (DateUtils.getDistanceOfTwoDate(mfNetgateAcctList.get(0).getCreateTime(), new Date()) > expire.doubleValue()) {
                //超过数据保存时间上限，新增第三方数据查询标识
                primaryKey = PrefixEnums.JQID.getDescription() + Snowflake.getMe().nextId();
                //用户三方数据标识号
                entity.setUniqueNo(primaryKey);
                //插入用户数据唯一标识表
                mfNetgateAcctBiz.insertSelective(entity);
            } else {
                MfNetgateAcct entity1 = new MfNetgateAcct();
                entity1.setApplyNo(applyNo);
                //查询该用户申请号查询第三方数据用户标识是否存在该用户数据
                List<MfNetgateAcct> mfNetgateAccts = mfNetgateAcctBiz.selectList(entity1);
                primaryKey = mfNetgateAcctList.get(0).getUniqueNo();
                if (mfNetgateAccts.isEmpty()) {
                    //未超过限定时间，使用已有的用户三方数据标识号
                    entity.setUniqueNo(primaryKey);        //用户三方数据唯一标识号
                    //插入用户数据唯一标识表
                    mfNetgateAcctBiz.insertSelective(entity);
                }
            }

        }

        ruleExcuteReqModel.setBusinessKey(applyNo);
        ruleExcuteReqModel.setRuleParamMap(reqs);
        ruleExcuteReqModel.setProCode(innerDataBaseModel.getProCode());
        ruleExcuteReqModel.setSceneCode(innerDataBaseModel.getSceneCode());

        CupdRespModel cupdRespModel = new CupdRespModel();
        if (innerDataBaseModel.getIsAync() == 1) {

            //异步执行规则引擎服务
            declineCodeService.runAsynDrools(ruleExcuteReqModel);

        } else {

            //同步执行规则引擎服务
            RuleRspScoreModel ruleRspScoreModel = declineCodeService.ruleDrools(ruleExcuteReqModel);

            //加黑规则
            if (!StringUtils.isBlank(ruleRspScoreModel.getStrategyBranchCode())) {
                declineCodeService.transRun(ruleRspScoreModel, innerDataBaseModel, primaryKey);
            }

            //结果处理，发送银联CQ3接口
            UserDataModel userDataModel = new UserDataModel();
            userDataModel.setUniqueNo(primaryKey);
            userDataModel.setBusinessKey(applyNo);
            userDataModel.setDocumentno(documentno);
            userDataModel.setName(username);
            userDataModel.setPhone(phone);
            userDataModel.setProCode(innerDataBaseModel.getProCode());
            cupdRespModel = cupdPartyService.sendData(ruleRspScoreModel, userDataModel);

            if (!cupdRespModel.getRetCode().equals(commonEnumsService.getByPrimaryKey(18001).getName())) {
                //同步执行规则时；cupd返回失败进异常
                ExceptionUtils.throwBaseException(101, "CUPD POST请求异常" + cupdRespModel.getRetMsg());

            }
        }


        return cupdRespModel;

    }


    /**
     * 绑定银行卡
     */
    @PostMapping("/authbindCard")
    public RespAuthbindCardModel authbindCard(@RequestBody ReqAuthbindCardModel reqAuthbindCardModel) {
        logger.info("********绑定银行卡********");
        ReqFrontDateModel reqFrontDateModel = new ReqFrontDateModel();
        reqFrontDateModel.setName(reqAuthbindCardModel.getUserName());
        reqFrontDateModel.setDocumentno(reqAuthbindCardModel.getIdCard());
        reqFrontDateModel.setPhone(reqAuthbindCardModel.getPhoneNum());
        reqFrontDateModel.setCardNo(reqAuthbindCardModel.getCardNo());
        RespAuthbindCardModel respAuthbindCardModel = new RespAuthbindCardModel();
        respAuthbindCardModel.setUniqueNo(reqAuthbindCardModel.getUniqueNo());
        respAuthbindCardModel.setRetCode("0000000");
        respAuthbindCardModel.setRetMsg("绑卡成功!");
        return respAuthbindCardModel;
    }


    /**
     * 推送规则结果
     *
     * @throws Exception
     */
    @PostMapping("/pushRuleResult")
    public String pushRuleResult(@RequestBody JSONObject resp) {

        logger.info("返回参数：" + resp);
        if (resp == null) {
            logger.error("###规则引擎返回空值###");
            throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###不存在此用户三要素资料###");
        }
        CupdRespModel cupdRespModel = new CupdRespModel();
        //客户申请编号
        String businessKey = resp.getString("businessKey");
        cupdRespModel.setBusinessKey(businessKey);

        // 判定返回结果
        RuleExcuteRespModel respModel = (RuleExcuteRespModel) JSONObject.toJavaObject(resp, RuleExcuteRespModel.class);
        String rspCode = respModel.getResult();
        String redCode = "success";
        if (rspCode.equals("exception")) {
            logger.error("####规则引擎响异常#####");
            //TODO 调用fronts-manager修改轮循状态和申请状态
            innerDataService.updateUserApplyStatus(cupdRespModel);
            return redCode;
        }
        if (rspCode.equals("refuse")) {
            logger.info("####步入规则引擎拒绝#####");
        }
        if (rspCode.equals("end")) {
            logger.info("####规则引擎执行完毕#####");
        }

        // 提取规则引擎CUPD所需结果
        Map<String, Object> rspMap = respModel.getRspMap();

        try {
            // 字典服务
            JSONObject resps = paramsDictionaryService.convertCn2En(rspMap, "rule");
            logger.info("规则引擎返回结果：" + resps);
            //TODO 规则引擎返回接收状态 数据库更新为处理中,最终结果由规则引擎异步返回
            RuleRspScoreModel ruleRspScoreModel = new RuleRspScoreModel();
            // 审批标识:A,M,D
            ruleRspScoreModel.setApprovalId(resps.get("approvalId").toString());
            logger.info("==================拒绝原因码:" + resps.get("refuseCode").toString());
            //策略分支码去除0
            String strategyBranchCode = resps.get("strategyBranchCode").toString();
            strategyBranchCode = strategyBranchCode.substring(1);
            if (strategyBranchCode.contains(",")) {
                ruleRspScoreModel.setStrategyBranchCode(strategyBranchCode);

            } else {
                ruleRspScoreModel.setStrategyBranchCode("");
            }
            //获取拒绝原因码及其优先级
            declineCodeService.getDeclineCode(ruleRspScoreModel, strategyBranchCode);
            //查询客户信息
            MfNetgateAcct entity1 = new MfNetgateAcct();
            entity1.setApplyNo(businessKey);
            //查询该用户申请号查询第三方数据用户标识是否存在该用户数据
            List<MfNetgateAcct> mfNetgateAcct = mfNetgateAcctBiz.selectList(entity1);
            InnerDataBaseModel innerDataBaseModel = new InnerDataBaseModel();
            innerDataBaseModel.setDocumentno(mfNetgateAcct.get(0).getIdCard());
            innerDataBaseModel.setPhone(mfNetgateAcct.get(0).getPhone());
            //加黑规则
            if (!StringUtils.isBlank(ruleRspScoreModel.getStrategyBranchCode())) {
                logger.info("加黑规则命中策略分支码：" + ruleRspScoreModel.getStrategyBranchCode());
                declineCodeService.transRun(ruleRspScoreModel, innerDataBaseModel, mfNetgateAcct.get(0).getUniqueNo());
            }
            //结果处理，发送银联CQ3接口
            UserDataModel userDataModel = new UserDataModel();
            userDataModel.setUniqueNo(mfNetgateAcct.get(0).getUniqueNo());
            userDataModel.setBusinessKey(businessKey);
            userDataModel.setDocumentno(mfNetgateAcct.get(0).getIdCard());
            userDataModel.setName(mfNetgateAcct.get(0).getUserName());
            userDataModel.setPhone(mfNetgateAcct.get(0).getPhone());
            userDataModel.setProCode(mfNetgateAcct.get(0).getProductNo());
            cupdRespModel = cupdPartyService.sendData(ruleRspScoreModel, userDataModel);
        } catch (Exception e) {
            logger.error(businessKey + "####处理异常#####", e);
            //TODO 调用fronts-manager修改轮循状态和申请状态
            innerDataService.updateUserApplyStatus(cupdRespModel);
            return redCode;
        }

        //处理成功 调用fronts-manager修改轮循状态和申请状态
        innerDataService.updateUserApplyStatus(cupdRespModel);

        return redCode;
    }

    @PostMapping("/isBlackOrYellow")
    public JSONObject isBlackOrYellow(@RequestParam String phoneNo) {
        return blackListInnerService.isBlackOrYellow(phoneNo);
    }

    @PostMapping("/getContactTime")
    public int getContactTime(@RequestParam String phoneNo, @RequestParam String otherPhone) {
        return callRecordService.getContactTime(phoneNo, otherPhone);
    }
    
    
    /**
     * 调度任务发起CQ4
     */
    @PostMapping("/getInterruptLinkInfo")
    public void getInterruptLinkInfo(){
    	cupdPartyService.getInterruptLinkInfo();
    }
}
