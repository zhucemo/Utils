package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-08-01 15:57:54
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_user_params")
public class MfNetgateUserParams implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //id
    @Id
    private Long id;
	
	    //用户唯一标示
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //申请号
    @Column(name = "apply_no")
    private String applyNo;
	
	    //贷后邦token
    @Column(name = "token")
    private String token;
	
	    //
    @Column(name = "remark")
    private String remark;
	
	    //
    @Column(name = "description")
    private String description;
	
	    //
    @Column(name = "type")
    private String type;
	
	    //
    @Column(name = "spare1")
    private String spare1;
	
	    //
    @Column(name = "spare2")
    private String spare2;
	
	    //
    @Column(name = "spare3")
    private String spare3;
	
	    //
    @Column(name = "spare4")
    private String spare4;
	
	    //
    @Column(name = "spare5")
    private String spare5;
	
	    //
    @Column(name = "spare6")
    private String spare6;
	
	    //
    @Column(name = "create_time")
    private Date createTime;
	
	    //
    @Column(name = "create_user")
    private Long createUser;
	
	    //
    @Column(name = "update_time")
    private Date updateTime;
	
	    //
    @Column(name = "update_user")
    private Long updateUser;
	

	/**
	 * 设置：id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：用户唯一标示
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：用户唯一标示
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：申请号
	 */
	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}
	/**
	 * 获取：申请号
	 */
	public String getApplyNo() {
		return applyNo;
	}
	/**
	 * 设置：贷后邦token
	 */
	public void setToken(String token) {
		this.token = token;
	}
	/**
	 * 获取：贷后邦token
	 */
	public String getToken() {
		return token;
	}
	/**
	 * 设置：
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	/**
	 * 获取：
	 */
	public String getRemark() {
		return remark;
	}
	/**
	 * 设置：
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * 获取：
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * 设置：
	 */
	public void setType(String type) {
		this.type = type;
	}
	/**
	 * 获取：
	 */
	public String getType() {
		return type;
	}
	/**
	 * 设置：
	 */
	public void setSpare1(String spare1) {
		this.spare1 = spare1;
	}
	/**
	 * 获取：
	 */
	public String getSpare1() {
		return spare1;
	}
	/**
	 * 设置：
	 */
	public void setSpare2(String spare2) {
		this.spare2 = spare2;
	}
	/**
	 * 获取：
	 */
	public String getSpare2() {
		return spare2;
	}
	/**
	 * 设置：
	 */
	public void setSpare3(String spare3) {
		this.spare3 = spare3;
	}
	/**
	 * 获取：
	 */
	public String getSpare3() {
		return spare3;
	}
	/**
	 * 设置：
	 */
	public void setSpare4(String spare4) {
		this.spare4 = spare4;
	}
	/**
	 * 获取：
	 */
	public String getSpare4() {
		return spare4;
	}
	/**
	 * 设置：
	 */
	public void setSpare5(String spare5) {
		this.spare5 = spare5;
	}
	/**
	 * 获取：
	 */
	public String getSpare5() {
		return spare5;
	}
	/**
	 * 设置：
	 */
	public void setSpare6(String spare6) {
		this.spare6 = spare6;
	}
	/**
	 * 获取：
	 */
	public String getSpare6() {
		return spare6;
	}
	/**
	 * 设置：
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：
	 */
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：
	 */
	public Long getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
	/**
	 * 设置：
	 */
	public void setUpdateUser(Long updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：
	 */
	public Long getUpdateUser() {
		return updateUser;
	}
}
