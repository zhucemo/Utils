package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-19 10:55:25
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_ppxin_modelscore")
public class MfNetgatePpxinModelscore implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Integer id;
	
	    //用户唯一标识
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //信用模型评分
    @Column(name = "score_sma")
    private String scoreSma;
	
	    //风险等级
    @Column(name = "risk_rank")
    private String riskRank;
	
	    //违约概率
    @Column(name = "proba_pility")
    private String probaPility;
	
	    //消费行为系数
    @Column(name = "consumption_confficient")
    private String consumptionConfficient;
	
	    //设备行为系数
    @Column(name = "device_confficient")
    private String deviceConfficient;
	
	    //社交行为系数
    @Column(name = "socialact_confficient")
    private String socialactConfficient;
	
	    //查询状态
    @Column(name = "query_status")
    private String queryStatus;
	
	    //查询状态描述
    @Column(name = "query_statusText")
    private String queryStatustext;
	
	    //错误信息码
    @Column(name = "error_code")
    private String errorCode;
	
	    //错误信息
    @Column(name = "error_msg")
    private String errorMsg;
	
	    //预留字段1
    @Column(name = "spare1")
    private String spare1;
	
	    //预留字段2
    @Column(name = "spare2")
    private String spare2;
	
	    //预留字段3
    @Column(name = "spare3")
    private String spare3;
	
	    //预留字段4
    @Column(name = "spare4")
    private String spare4;
	
	    //创建用户
    @Column(name = "creat_user")
    private Date creatUser;
	
	    //创建时间
    @Column(name = "creat_time")
    private Date creatTime;
	
	    //更新用户
    @Column(name = "update_user")
    private Date updateUser;
	
	    //更新时间
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * 设置：用户唯一标识
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：用户唯一标识
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：信用模型评分
	 */
	public void setScoreSma(String scoreSma) {
		this.scoreSma = scoreSma;
	}
	/**
	 * 获取：信用模型评分
	 */
	public String getScoreSma() {
		return scoreSma;
	}
	/**
	 * 设置：风险等级
	 */
	public void setRiskRank(String riskRank) {
		this.riskRank = riskRank;
	}
	/**
	 * 获取：风险等级
	 */
	public String getRiskRank() {
		return riskRank;
	}
	/**
	 * 设置：违约概率
	 */
	public void setProbaPility(String probaPility) {
		this.probaPility = probaPility;
	}
	/**
	 * 获取：违约概率
	 */
	public String getProbaPility() {
		return probaPility;
	}
	/**
	 * 设置：消费行为系数
	 */
	public void setConsumptionConfficient(String consumptionConfficient) {
		this.consumptionConfficient = consumptionConfficient;
	}
	/**
	 * 获取：消费行为系数
	 */
	public String getConsumptionConfficient() {
		return consumptionConfficient;
	}
	/**
	 * 设置：设备行为系数
	 */
	public void setDeviceConfficient(String deviceConfficient) {
		this.deviceConfficient = deviceConfficient;
	}
	/**
	 * 获取：设备行为系数
	 */
	public String getDeviceConfficient() {
		return deviceConfficient;
	}
	/**
	 * 设置：社交行为系数
	 */
	public void setSocialactConfficient(String socialactConfficient) {
		this.socialactConfficient = socialactConfficient;
	}
	/**
	 * 获取：社交行为系数
	 */
	public String getSocialactConfficient() {
		return socialactConfficient;
	}
	/**
	 * 设置：查询状态
	 */
	public void setQueryStatus(String queryStatus) {
		this.queryStatus = queryStatus;
	}
	/**
	 * 获取：查询状态
	 */
	public String getQueryStatus() {
		return queryStatus;
	}
	/**
	 * 设置：查询状态描述
	 */
	public void setQueryStatustext(String queryStatustext) {
		this.queryStatustext = queryStatustext;
	}
	/**
	 * 获取：查询状态描述
	 */
	public String getQueryStatustext() {
		return queryStatustext;
	}
	/**
	 * 设置：错误信息码
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * 获取：错误信息码
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * 设置：错误信息
	 */
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	/**
	 * 获取：错误信息
	 */
	public String getErrorMsg() {
		return errorMsg;
	}
	/**
	 * 设置：预留字段1
	 */
	public void setSpare1(String spare1) {
		this.spare1 = spare1;
	}
	/**
	 * 获取：预留字段1
	 */
	public String getSpare1() {
		return spare1;
	}
	/**
	 * 设置：预留字段2
	 */
	public void setSpare2(String spare2) {
		this.spare2 = spare2;
	}
	/**
	 * 获取：预留字段2
	 */
	public String getSpare2() {
		return spare2;
	}
	/**
	 * 设置：预留字段3
	 */
	public void setSpare3(String spare3) {
		this.spare3 = spare3;
	}
	/**
	 * 获取：预留字段3
	 */
	public String getSpare3() {
		return spare3;
	}
	/**
	 * 设置：预留字段4
	 */
	public void setSpare4(String spare4) {
		this.spare4 = spare4;
	}
	/**
	 * 获取：预留字段4
	 */
	public String getSpare4() {
		return spare4;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreatUser(Date creatUser) {
		this.creatUser = creatUser;
	}
	/**
	 * 获取：创建用户
	 */
	public Date getCreatUser() {
		return creatUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreatTime(Date creatTime) {
		this.creatTime = creatTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreatTime() {
		return creatTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(Date updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public Date getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
}
