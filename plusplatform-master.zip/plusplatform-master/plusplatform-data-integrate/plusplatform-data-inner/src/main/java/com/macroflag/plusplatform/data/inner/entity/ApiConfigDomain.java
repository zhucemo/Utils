package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 接口配置表的domain
 * @author : Fredia
 * @since : 2018年05月09日
 * @version : v0.0.1
 */
public class ApiConfigDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*id*/
	private Long id;
	
	/*接口标示*/
	private String apiCode;
	
	/*接口中文名*/
	private String apiName;
	
	/*接口url*/
	private String apiUrl;
	
	/**/
	private String apiConfig;
	
	/*是否为内部接口：
0-外部接口
1-内部接口*/
	private Integer isInternal;
	
	/*接口状态
0-关闭接口：调用返回错误
1-开启接口：正常模式，查询库计算生命周期
2-空对象：熔断自定义数据模板
3-强制更新：刷新数据库*/
	private Integer status;
	
	/*熔断模板*/
	private String fallbackContent;
	
	/**/
	private Integer isRealTimeUpdate;
	
	/*数据生命周期
0 :永久有效
>0:正常*/
	private Long dataLifeCycle;
	
	/*备注*/
	private String remark;
	
	/**/
	private String spare1;
	
	/**/
	private String spare2;
	
	/**/
	private String spare3;
	
	/**/
	private String spare4;
	
	/**/
	private Date createTime;
	
	/**/
	private Long createUser;
	
	/**/
	private Date updateTime;
	
	/**/
	private Long updateUser;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getApiCode(){
		return apiCode;
	}
	
	public void setApiCode(String apiCode){
		this.apiCode = apiCode;
	}
	
	public String getApiName(){
		return apiName;
	}
	
	public void setApiName(String apiName){
		this.apiName = apiName;
	}
	
	public String getApiUrl(){
		return apiUrl;
	}
	
	public void setApiUrl(String apiUrl){
		this.apiUrl = apiUrl;
	}
	
	public String getApiConfig(){
		return apiConfig;
	}
	
	public void setApiConfig(String apiConfig){
		this.apiConfig = apiConfig;
	}
	
	public Integer getIsInternal(){
		return isInternal;
	}
	
	public void setIsInternal(Integer isInternal){
		this.isInternal = isInternal;
	}
	
	public Integer getStatus(){
		return status;
	}
	
	public void setStatus(Integer status){
		this.status = status;
	}
	
	public String getFallbackContent(){
		return fallbackContent;
	}
	
	public void setFallbackContent(String fallbackContent){
		this.fallbackContent = fallbackContent;
	}
	
	public Integer getIsRealTimeUpdate(){
		return isRealTimeUpdate;
	}
	
	public void setIsRealTimeUpdate(Integer isRealTimeUpdate){
		this.isRealTimeUpdate = isRealTimeUpdate;
	}
	
	public Long getDataLifeCycle(){
		return dataLifeCycle;
	}
	
	public void setDataLifeCycle(Long dataLifeCycle){
		this.dataLifeCycle = dataLifeCycle;
	}
	
	public String getRemark(){
		return remark;
	}
	
	public void setRemark(String remark){
		this.remark = remark;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	
}
