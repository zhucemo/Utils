package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateSuanhuaShoujishiming;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateSuanhuaShoujishimingMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-26 17:21:40
 * @version : v1.0.0
 */
@Service
public class MfNetgateSuanhuaShoujishimingBiz extends BusinessBiz<MfNetgateSuanhuaShoujishimingMapper,MfNetgateSuanhuaShoujishiming> {
}