package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-24 13:25:59
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_initem_pacraresult")
public class MfNetgateInitemPacraresult implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键id
    @Id
    private Long id;
	
	    //业务唯一标识
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //凭安染黑度评分
    @Column(name = "grayscalescore")
    private Integer grayscalescore;
	
	    //凭安手机号有风险标签
    @Column(name = "risklabel")
    private String risklabel;
	
	    //凭安30天银行催收电话记录数
    @Column(name = "pabankcollcallcntin30d")
    private Integer pabankcollcallcntin30d;
	
	    //凭安30天其他催收电话记录数
    @Column(name = "paothcollcallcntin30d")
    private Integer paothcollcallcntin30d;
	
	    //凭安90天委外催收电话记录数
    @Column(name = "paoutcollcallcntin90d")
    private Integer paoutcollcallcntin90d;
	
	    //凭安180天催收电话记录数
    @Column(name = "pacollcallcnt")
    private Integer pacollcallcnt;
	
	    //预留字段1
    @Column(name = "spare1")
    private String spare1;
	
	    //预留字段2
    @Column(name = "spare2")
    private String spare2;
	
	    //预留字段3
    @Column(name = "spare3")
    private String spare3;
	
	    //预留字段4
    @Column(name = "spare4")
    private String spare4;
	
	    //创建用户
    @Column(name = "create_user")
    private Long createUser;
	
	    //创建时间
    @Column(name = "create_time")
    private Date createTime;
	
	    //更新用户
    @Column(name = "update_user")
    private Long updateUser;
	
	    //更新时间
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键id
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：业务唯一标识
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：业务唯一标识
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：凭安染黑度评分
	 */
	public void setGrayscalescore(Integer grayscalescore) {
		this.grayscalescore = grayscalescore;
	}
	/**
	 * 获取：凭安染黑度评分
	 */
	public Integer getGrayscalescore() {
		return grayscalescore;
	}
	/**
	 * 设置：凭安手机号有风险标签
	 */
	public void setRisklabel(String risklabel) {
		this.risklabel = risklabel;
	}
	/**
	 * 获取：凭安手机号有风险标签
	 */
	public String getRisklabel() {
		return risklabel;
	}
	/**
	 * 设置：凭安30天银行催收电话记录数
	 */
	public void setPabankcollcallcntin30d(Integer pabankcollcallcntin30d) {
		this.pabankcollcallcntin30d = pabankcollcallcntin30d;
	}
	/**
	 * 获取：凭安30天银行催收电话记录数
	 */
	public Integer getPabankcollcallcntin30d() {
		return pabankcollcallcntin30d;
	}
	/**
	 * 设置：凭安30天其他催收电话记录数
	 */
	public void setPaothcollcallcntin30d(Integer paothcollcallcntin30d) {
		this.paothcollcallcntin30d = paothcollcallcntin30d;
	}
	/**
	 * 获取：凭安30天其他催收电话记录数
	 */
	public Integer getPaothcollcallcntin30d() {
		return paothcollcallcntin30d;
	}
	/**
	 * 设置：凭安90天委外催收电话记录数
	 */
	public void setPaoutcollcallcntin90d(Integer paoutcollcallcntin90d) {
		this.paoutcollcallcntin90d = paoutcollcallcntin90d;
	}
	/**
	 * 获取：凭安90天委外催收电话记录数
	 */
	public Integer getPaoutcollcallcntin90d() {
		return paoutcollcallcntin90d;
	}
	/**
	 * 设置：凭安180天催收电话记录数
	 */
	public void setPacollcallcnt(Integer pacollcallcnt) {
		this.pacollcallcnt = pacollcallcnt;
	}
	/**
	 * 获取：凭安180天催收电话记录数
	 */
	public Integer getPacollcallcnt() {
		return pacollcallcnt;
	}
	/**
	 * 设置：预留字段1
	 */
	public void setSpare1(String spare1) {
		this.spare1 = spare1;
	}
	/**
	 * 获取：预留字段1
	 */
	public String getSpare1() {
		return spare1;
	}
	/**
	 * 设置：预留字段2
	 */
	public void setSpare2(String spare2) {
		this.spare2 = spare2;
	}
	/**
	 * 获取：预留字段2
	 */
	public String getSpare2() {
		return spare2;
	}
	/**
	 * 设置：预留字段3
	 */
	public void setSpare3(String spare3) {
		this.spare3 = spare3;
	}
	/**
	 * 获取：预留字段3
	 */
	public String getSpare3() {
		return spare3;
	}
	/**
	 * 设置：预留字段4
	 */
	public void setSpare4(String spare4) {
		this.spare4 = spare4;
	}
	/**
	 * 获取：预留字段4
	 */
	public String getSpare4() {
		return spare4;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：创建用户
	 */
	public Long getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(Long updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public Long getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
}
