package com.macroflag.plusplatform.data.inner.dao;

import com.macroflag.plusplatform.data.inner.entity.HuluCallsDomain;

import java.util.List;

public interface HuluCallsDao {
    List<HuluCallsDomain> getCallHistoryByUnique(String unique, int pageIndex, int pageSize);

    List<HuluCallsDomain> getCallHistoryByUnique(String unique, int pageSize);

    List<HuluCallsDomain> getCallHistoryByUnique(String unique);

    int getContactTime(String phone, String otherPhone);

    List<HuluCallsDomain> getCallHistoryByPhone(String phone, int pageIndex, int pageSize);

}
