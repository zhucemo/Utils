package com.macroflag.plusplatform.data.inner.controller.api;

import java.util.List;

import com.macroflag.plusplatform.common.annotations.SystemLog;
import com.macroflag.plusplatform.common.exception.BaseException;
import com.macroflag.plusplatform.common.exception.ExceptionUtils;
import com.macroflag.plusplatform.data.inner.config.service.IApiConfigService;
import com.macroflag.plusplatform.data.inner.controller.base.BaseNetgateController;
import com.macroflag.plusplatform.data.inner.entity.*;
import com.macroflag.plusplatform.data.inner.initem.service.IQhFraudInitemService;
import com.macroflag.plusplatform.data.inner.query.QhAntifrauddooQuery;
import com.macroflag.plusplatform.data.inner.query.QhCredooQuery;
import com.macroflag.plusplatform.data.inner.query.QhLoaneeQuery;
import com.macroflag.plusplatform.data.inner.query.QhRskdooQuery;
import com.macroflag.plusplatform.data.inner.thirdpart.component.IQianhaiThirdPartyService;
import com.macroflag.plusplatform.data.inner.thirdpart.model.UserDataModel;
import com.macroflag.plusplatform.data.inner.thirdpart.service.IQhAntifrauddooService;
import com.macroflag.plusplatform.data.inner.thirdpart.service.IQhCredooService;
import com.macroflag.plusplatform.data.inner.thirdpart.service.IQhLoaneeService;
import com.macroflag.plusplatform.data.inner.thirdpart.service.IQhRskdooService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.wordnik.swagger.annotations.ApiParam;

/**
 * 前海 Controller
 * 
 * @author : Fredia
 * @since : 2018年4月13日
 * @version : v1.0.0
 */
@Scope(value = "prototype")
@RestController
@RequestMapping("/qianhai")
public class QianhaiThirdPartyController extends BaseNetgateController {

	@Autowired
	private IQianhaiThirdPartyService qianhaiThirdPartyService;
	
	@Autowired
	private IQhCredooService qhCredooService;
	
	@Autowired
	private IApiConfigService apiConfigService;
	
	@Autowired
	private IQhRskdooService qhRskdooService;
	
	@Autowired
	private IQhLoaneeService qhLoaneeService;
	
	@Autowired
	private IQhAntifrauddooService qhAntifrauddooService;
	
	@SuppressWarnings("unused")
	@Autowired
	private IQhFraudInitemService qhFraudInitemService;

	@RequestMapping(value = "getDataLoaneeInfo", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "前海常贷客接口", requestMethod = RequestMethod.GET)
	public Object getDataLoaneeInfo(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		logger.info("#########进入前海常贷客接口,申请编号为{}#########", businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		// 构建数据模型
		buildData(userDataModel);
		JSONObject result = null;
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("qhLoaneeInfo");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########", json);
			return json;

		} else if (1 == status) {
			/* 1.外部数据:先查询是否存在该用户原始数据 */
			QhLoaneeQuery qhLoaneeQuery = new QhLoaneeQuery();
			qhLoaneeQuery.setUniqueNo(userDataModel.getUniqueNo());
			List<QhLoaneeDomain> qhLoaneeDomain = qhLoaneeService.getList(qhLoaneeQuery);
			
			if(qhLoaneeDomain.isEmpty()){
				// 不存在就获取
				qianhaiThirdPartyService.getDataLoaneeInfo(userDataModel);
				jo = qianhaiThirdPartyService.determin(userDataModel);
			}else {
				jo = qianhaiThirdPartyService.determin(userDataModel);
			}
			
			logger.info("#####原始数据模型：{}####", jo);
			// 字典项转换
			try {
				result = convertEn2Cn(jo, "qianhai");
			} catch (Exception e) {
				logger.error("####英文转中文异常####");
				ExceptionUtils.throwBaseException("####英文转中文异常####");
			}
			logger.info("#########返回数据模型为：{}#########", result);
			return result;

		}
		logger.error("###该接口配置错误###");
		logger.info("#########返回数据模型为：{}#########", result);
		ExceptionUtils.throwBaseException("###该接口配置错误###");
		return result;

	}

	@RequestMapping(value = "getDataAntifrauddooInfo", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "前海好信欺诈度接口", requestMethod = RequestMethod.GET)
	public Object getDataAntifrauddooInfo(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		logger.info("#########进入前海好信欺诈度接口,申请编号为{}#########", businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		// 构建数据模型
		buildData(userDataModel);
		JSONObject result = null;
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("qhAntifrauddooInfo");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########", json);
			return json;

		} else if (1 == status) {
			
			/* 1.外部数据:先查询是否存在该用户原始数据 */
			QhAntifrauddooQuery qhAntifrauddooQuery = new QhAntifrauddooQuery();
			qhAntifrauddooQuery.setUniqueNo(userDataModel.getUniqueNo());
			QhAntifrauddooDomain qhAntifrauddooDomain = qhAntifrauddooService.getOne(qhAntifrauddooQuery);
			
			if(qhAntifrauddooDomain==null){
				//不存在就获取数据
				qianhaiThirdPartyService.getDataAntifrauddooInfo(userDataModel);
				jo = qianhaiThirdPartyService.determin(userDataModel);
			}else {
				jo = qianhaiThirdPartyService.determin(userDataModel);
			}
			
			
			logger.info("#####原始数据模型：{}####", jo);
			// 字典项转换
			try {
				result = convertEn2Cn(jo, "qianhai");
			} catch (Exception e) {
				logger.error("####英文转中文异常####");
				ExceptionUtils.throwBaseException("####英文转中文异常####");
			}
			logger.info("#########返回数据模型为：{}#########", result);
			return result;

		}
		logger.error("###该接口配置错误###");
		logger.info("#########返回数据模型为：{}#########", result);
		ExceptionUtils.throwBaseException("###该接口配置错误###");
		return result;

	}

	@RequestMapping(value = "getDataCredooInfo", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "前海好信度接口", requestMethod = RequestMethod.GET)
	public Object getDataCredooInfo(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		logger.info("#########进入前海好信度接口,申请编号为{}#########", businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		// 构建数据模型
		buildData(userDataModel);
		JSONObject result = null;
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("qhCredooInfo");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########", json);
			return json;

		} else if (1 == status) {
			
			/* 1.外部数据:先查询是否存在该用户原始数据 */
			QhCredooQuery qhCredooQuery = new QhCredooQuery();
			qhCredooQuery.setUniqueNo(userDataModel.getUniqueNo());
			QhCredooDomain qhCredooDomain = qhCredooService.getOne(qhCredooQuery);
			
			if(qhCredooDomain==null){
				//不存在则获取数据
				qianhaiThirdPartyService.getDataCredooInfo(userDataModel);
				jo = qianhaiThirdPartyService.determin(userDataModel);
			}else {
				jo = qianhaiThirdPartyService.determin(userDataModel);
			}
			
			logger.info("#####原始数据模型：{}####", jo);
			// 字典项转换
			try {
				result = convertEn2Cn(jo, "qianhai");
			} catch (Exception e) {
				logger.error("####英文转中文异常####");
				ExceptionUtils.throwBaseException("####英文转中文异常####");
			}
			logger.info("#########返回数据模型为：{}#########", result);
			return result;

		}
		logger.error("###该接口配置错误###");
		logger.info("#########返回数据模型为：{}#########", result);
		ExceptionUtils.throwBaseException("###该接口配置错误###");
		return result;

	}

	@RequestMapping(value = "getDataRskdooInfo", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "前海风险度提示接口", requestMethod = RequestMethod.GET)
	public Object getDataRskdooInfo(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		logger.info("#########进入前海风险度提示接口,申请编号为{}#########", businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		// 构建数据模型
		buildData(userDataModel);
		JSONObject result = null;
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("qhRskdooInfo");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########", json);
			return json;

		} else if (1 == status) {
			
			/* 1.外部数据:先查询是否存在该用户原始数据 */
			QhRskdooQuery qhRskdooQuery = new QhRskdooQuery();
			qhRskdooQuery.setUniqueNo(userDataModel.getUniqueNo());
			List<QhRskdooDomain> qhRskdooDomain = qhRskdooService.getList(qhRskdooQuery);
			
			if(qhRskdooDomain.isEmpty()){
				// 不存在就获取
				qianhaiThirdPartyService.getDataRskdooInfo(userDataModel);
				jo = qianhaiThirdPartyService.determin(userDataModel);
			}else {
				jo = qianhaiThirdPartyService.determin(userDataModel);
			}
			
			logger.info("#####原始数据模型：{}####", jo);
			// 字典项转换
			try {
				result = convertEn2Cn(jo, "qianhai");
			} catch (Exception e) {
				logger.error("####英文转中文异常####");
				ExceptionUtils.throwBaseException("####英文转中文异常####");
			}
			logger.info("#########返回数据模型为：{}#########", result);
			return result;

		}
		logger.error("###该接口配置错误###");
		logger.info("#########返回数据模型为：{}#########", result);
		ExceptionUtils.throwBaseException("###该接口配置错误###");
		return result;

	}
}