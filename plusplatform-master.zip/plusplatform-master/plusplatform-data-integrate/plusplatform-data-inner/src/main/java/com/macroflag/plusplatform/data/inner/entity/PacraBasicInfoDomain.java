package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

import com.macroflag.plusplatform.encryption.annotation.EnDomain;
import com.macroflag.plusplatform.encryption.annotation.EnField;

/**
 * 凭安基本信息的domain
 * @author : huangf
 * @since : 2018年04月18日
 * @version : v0.0.1
 */
@EnDomain
public class PacraBasicInfoDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*姓名*/
    @EnField
	private String uname;
	
	/*年龄*/
	private Integer age;
	
	/*手机号码*/
    @EnField
	private String phone;
	
	/*手机号码归属地*/
	private String phoneOwnership;
	
	/*手机运营商*/
	private String operator;
	
	/*身份证是否有效*/
	private String effectiveIdcard;
	
	/*染黑分*/
	private Integer grayscaleScore;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getUname(){
		return uname;
	}
	
	public void setUname(String uname){
		this.uname = uname;
	}
	
	public Integer getAge(){
		return age;
	}
	
	public void setAge(Integer age){
		this.age = age;
	}
	
	public String getPhone(){
		return phone;
	}
	
	public void setPhone(String phone){
		this.phone = phone;
	}
	
	public String getPhoneOwnership(){
		return phoneOwnership;
	}
	
	public void setPhoneOwnership(String phoneOwnership){
		this.phoneOwnership = phoneOwnership;
	}
	
	public String getOperator(){
		return operator;
	}
	
	public void setOperator(String operator){
		this.operator = operator;
	}
	
	public String getEffectiveIdcard(){
		return effectiveIdcard;
	}
	
	public void setEffectiveIdcard(String effectiveIdcard){
		this.effectiveIdcard = effectiveIdcard;
	}
	
	public Integer getGrayscaleScore(){
		return grayscaleScore;
	}
	
	public void setGrayscaleScore(Integer grayscaleScore){
		this.grayscaleScore = grayscaleScore;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
