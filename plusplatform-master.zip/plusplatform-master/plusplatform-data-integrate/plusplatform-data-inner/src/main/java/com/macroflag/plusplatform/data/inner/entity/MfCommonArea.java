package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 行政区划代码对照表
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-08-06 10:16:01
 * @version : v1.0.0
 */
@Table(name = "mf_common_area")
public class MfCommonArea implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Long id;
	
	    //行政区划编码
    @Column(name = "area_code")
    private String areaCode;
	
	    //省市区名称
    @Column(name = "area_name")
    private String areaName;
	
	    //省市编码
    @Column(name = "pro_ci_code")
    private String proCiCode;
	
	    //排序代码
    @Column(name = "disorder")
    private String disorder;
	
	    //省区域代码
    @Column(name = "procode")
    private String procode;
	

	/**
	 * 设置：主键
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：行政区划编码
	 */
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
	/**
	 * 获取：行政区划编码
	 */
	public String getAreaCode() {
		return areaCode;
	}
	/**
	 * 设置：省市区名称
	 */
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	/**
	 * 获取：省市区名称
	 */
	public String getAreaName() {
		return areaName;
	}
	/**
	 * 设置：省市编码
	 */
	public void setProCiCode(String proCiCode) {
		this.proCiCode = proCiCode;
	}
	/**
	 * 获取：省市编码
	 */
	public String getProCiCode() {
		return proCiCode;
	}
	/**
	 * 设置：排序代码
	 */
	public void setDisorder(String disorder) {
		this.disorder = disorder;
	}
	/**
	 * 获取：排序代码
	 */
	public String getDisorder() {
		return disorder;
	}
	/**
	 * 设置：省区域代码
	 */
	public void setProcode(String procode) {
		this.procode = procode;
	}
	/**
	 * 获取：省区域代码
	 */
	public String getProcode() {
		return procode;
	}
}
