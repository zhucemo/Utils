package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateInitemShfraudscore;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateInitemShfraudscoreMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-20 10:04:42
 * @version : v1.0.0
 */
@Service
public class MfNetgateInitemShfraudscoreBiz extends BusinessBiz<MfNetgateInitemShfraudscoreMapper,MfNetgateInitemShfraudscore> {

	@Autowired
	private MfNetgateInitemShfraudscoreMapper mfNetgateInitemShfraudscoreMapper;
	
	
	public void updateByUniqueNo(MfNetgateInitemShfraudscore mfNetgateInitemShfraudscore) {
		
		mfNetgateInitemShfraudscoreMapper.updateByUniqueNo(mfNetgateInitemShfraudscore);
		
	}
}