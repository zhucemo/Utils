package com.macroflag.plusplatform.data.inner.controller.api;


import com.macroflag.plusplatform.common.exception.BaseException;
import com.macroflag.plusplatform.common.exception.ExceptionUtils;
import com.macroflag.plusplatform.data.inner.config.service.IApiConfigService;
import com.macroflag.plusplatform.data.inner.controller.base.BaseNetgateController;
import com.macroflag.plusplatform.data.inner.entity.ApiConfigDomain;
import com.macroflag.plusplatform.data.inner.internal.component.IFaceInnerService;
import com.macroflag.plusplatform.data.inner.thirdpart.model.UserDataModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.wordnik.swagger.annotations.ApiParam;

/**
 * face Controller
 * 
 * @author : Fredia
 * @since : 2018年4月13日
 * @version : v1.0.0
 */
@Scope(value = "prototype")
@RestController
@RequestMapping("/face")
public class FaceInnerController extends BaseNetgateController {

	@Autowired
	private IFaceInnerService faceInnerService;

	@Autowired
	private IApiConfigService apiConfigService;
	

	@RequestMapping(value = "getFaceData", method = RequestMethod.GET)
	public Object getFaceData(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		logger.info("#########进入Face++数据接口,申请编号为{}#########",businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		// 构建数据模型
		buildData(userDataModel);
		JSONObject result = null;
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("face");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########",json);
			return json;

		} else if (1 == status) {
			
			//查询规则输入项参数
			jo = faceInnerService.determin(userDataModel);
			
			logger.info("#####原始数据模型：{}####", jo);
			// 字典项转换
			try {
				result = convertEn2Cn(jo, "face");
			} catch (Exception e) {
				logger.error("####英文转中文异常####");
				ExceptionUtils.throwBaseException("####英文转中文异常####");
			}
			logger.info("#########返回数据模型为：{}#########",result);
			return result;

		}
		logger.error("###该接口配置错误###");
		logger.info("#########返回数据模型为：{}#########",result);
		ExceptionUtils.throwBaseException("###该接口配置错误###");
		return result;

	}
}
