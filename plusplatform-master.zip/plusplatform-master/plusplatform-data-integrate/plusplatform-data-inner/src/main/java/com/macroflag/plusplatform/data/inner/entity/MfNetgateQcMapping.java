package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-11-07 17:47:15
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_qc_mapping")
public class MfNetgateQcMapping implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Long id;
	
	    //旗计步骤
    @Column(name = "qi_step")
    private String qiStep;
	
	    //银联步骤
    @Column(name = "cupd_step")
    private String cupdStep;
	
	    //产品号
    @Column(name = "product_no")
    private String productNo;
	
	    //描述
    @Column(name = "remark")
    private String remark;
	
	    //创建用户
    @Column(name = "create_user")
    private String createUser;
	
	    //创建时间
    @Column(name = "create_time")
    private Date createTime;
	
	    //更新用户
    @Column(name = "update_user")
    private String updateUser;
	
	    //更新时间
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：旗计步骤
	 */
	public void setQiStep(String qiStep) {
		this.qiStep = qiStep;
	}
	/**
	 * 获取：旗计步骤
	 */
	public String getQiStep() {
		return qiStep;
	}
	/**
	 * 设置：银联步骤
	 */
	public void setCupdStep(String cupdStep) {
		this.cupdStep = cupdStep;
	}
	/**
	 * 获取：银联步骤
	 */
	public String getCupdStep() {
		return cupdStep;
	}
	/**
	 * 设置：产品号
	 */
	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}
	/**
	 * 获取：产品号
	 */
	public String getProductNo() {
		return productNo;
	}
	/**
	 * 设置：描述
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	/**
	 * 获取：描述
	 */
	public String getRemark() {
		return remark;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：创建用户
	 */
	public String getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public String getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
}
