package com.macroflag.plusplatform.data.inner.controller;

import com.macroflag.plusplatform.data.inner.thirdpart.model.UserDataModel;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/test")
public class TestController {



    @PostMapping("service")
    public void testService(UserDataModel obj) {
   }
}
