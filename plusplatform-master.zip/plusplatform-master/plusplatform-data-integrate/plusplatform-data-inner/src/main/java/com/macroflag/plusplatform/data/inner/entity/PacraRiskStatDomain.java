package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 凭安风险度表的domain
 * @author : fredia
 * @since : 2018年04月25日
 * @version : v0.0.1
 */
public class PacraRiskStatDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*月均通话次数*/
	private Float callTimesAvg;
	
	/*联系人号码个数*/
	private Integer contactsCount;
	
	/*与催收号码有过联系的总天数*/
	private Integer dunTelCallDays;
	
	/*最早一次与催收号码联系距离今天过去了多少天*/
	private String dunTelCallEarliest;
	
	/*最近一次被哪类机构催收*/
	private String dunTelCallRecently;
	
	/*涉及催收号码个数*/
	private String dunTelCount;
	
	/*被催收过的机构类型，多个机构类型之间用顿号”、”分割*/
	private String dunTelOrgType;
	
	/*最长通话间隔*/
	private Integer maxCallInterval;
	
	/*静默天数(没有通话行为的天数)*/
	private Integer noCallDays;
	
	/*近一周与几个催收号码有过联系*/
	private Integer l1wwdcnTNumsCon;
	
	/*近一周与几家银行机构催收号码有过联系*/
	private Integer l1wwdcnTNumsConBank;
	
	/*近一周与几家消费金融机构催收号码有过联系*/
	private Integer l1wwdcnTNumsConCf;
	
	/*近一周与几家委外催收机构催收号码有过联系*/
	private Integer l1wwdcnTNumsConF;
	
	/*近一周与几家互联网金融机构催收号码有过联系*/
	private Integer l1wwdcnTNumsConIf;
	
	/*近一周涉及催收号码的总机构数*/
	private Integer l1wwdcnTNumsConOrg;
	
	/*近一周被催收号码呼叫次数*/
	private Integer l1wwdcnTTimesIn;
	
	/*近一周主叫催收号码次数*/
	private Integer l1wwdcnTTimesOut;
	
	/*近两周联系机构类型总数*/
	private Integer l2wwdcnTNumsConOrgtype;
	
	/*近三周联系互联网金融机构的总个数*/
	private Integer l3wwdcnTNumsConIf;
	
	/*近一月与几个催收号码有过联系*/
	private Integer l1mwdcnTNumsCon;
	
	/*近一月与几家银行机构催收号码有过联系*/
	private Integer l1mwdcnTNumsConBank;
	
	/*近一月与几家消费金融机构催收号码有过联系*/
	private Integer l1mwdcnTNumsConCf;
	
	/*近一月与几家委外催收机构催收号码有过联系*/
	private Integer l1mwdcnTNumsConF;
	
	/*近一月与几家互联网金融机构催收号码有过联系*/
	private Integer l1mwdcnTNumsConIf;
	
	/*近一月涉及催收号码的总机构数*/
	private Integer l1mwdcnTNumsConOrg;
	
	/*近一月被催收号码呼叫次数*/
	private Integer l1mwdcnTTimesIn;
	
	/*近一月主叫催收号码次数*/
	private Integer l1mwdcnTTimesOut;
	
	/*近两月被催收号码呼叫次数*/
	private Integer l2mwdcnTTimesIn;
	
	/*近两月申请人收到催收号的总个数*/
	private Integer l2mwdcnTNumsIn;
	
	/*近两月被单个催收号码呼叫的最大次数*/
	private Integer l2mwdcnMaxTimesIn;
	
	/*近两月申请人联系次数最大的催收号的总时长*/
	private Integer l2mwdcnMaxTimesCon;
	
	/*近两月晚上联系催收号的总天数*/
	private Integer l2mencnTDaysCon;
	
	/*近三月与几个催收号码有过联系*/
	private Integer l3mwdcnTNumsCon;
	
	/*近三月与几家银行机构催收号码有过联系*/
	private Integer l3mwdcnTNumsConBank;
	
	/*近三月与几家消费金融机构催收号码有过联系*/
	private Integer l3mwdcnTNumsConCf;
	
	/*近三月与几家委外催收机构催收号码有过联系*/
	private Integer l3mwdcnTNumsConF;
	
	/*近三月与几家互联网金融机构催收号码有过联系*/
	private Integer l3mwdcnTNumsConIf;
	
	/*近三月晚上涉及催收号码的总机构数*/
	private Integer l3mencnTNumsConOrg;
	
	/*近三月涉及催收号码的总机构数*/
	private Integer l3mwdcnTNumsConOrg;
	
	/*近三月被催收号码呼叫次数*/
	private Integer l3mwdcnTTimesIn;
	
	/*近三月主叫催收号码次数*/
	private Integer l3mwdcnTTimesOut;
	
	/*近三月新增机构数*/
	private Integer l3mwdcnAddTNumsInOrg;
	
	/*近三月被每个催收号呼叫的天数的最大值*/
	private Integer l3mwdcnMaxDaysIn;
	
	/*近四月申请人联系机构类型的总个数*/
	private Integer l4mwdcnTNumsConOrgtype;
	
	/*近四月非银机构呼入的总次数*/
	private Integer l4mwdcnTTimesInNonbank;
	
	/*近四月联系催收号的总时长*/
	private Integer l4mwdcnTDurCon;
	
	/*近四月联系催收号的总次数*/
	private Integer l4mwdcnTTimesCon;
	
	/*近四月与几家委外催收机构催收号码有过联系*/
	private Integer l4mwdcnTNumsConF;
	
	/*近四月被催收号呼叫的总时长*/
	private Integer l4mwdcnTDurIn;
	
	/*近四月被叫次数最大的催收号的总时长*/
	private Integer l4mwdcnTDurInMaxTimes;
	
	/*近四月被几家委外催收机构呼叫过*/
	private Integer l4mwdcnTNumsInF;
	
	/*近五月联系催收号的总天数*/
	private Integer l5mwdcnTDaysCon;
	
	/*近五月被委外催收号码呼叫的总时长*/
	private Integer l5mwdcnTDurInF;
	
	/*近五月联系催收手机总时长*/
	private Integer l5mwdcmTDurCon;
	
	/*近五月与几家互联网金融机构催收号码有过联系*/
	private Integer l5mwdcnTNumsConIf;
	
	/*详单周期内与几个催收号码有过联系*/
	private Integer allwdcnTNumsCon;
	
	/*详单周期内与几家银行机构催收号码有过联系*/
	private Integer allwdcnTNumsConBank;
	
	/*详单周期内与几家消费金融机构催收号码有过联系*/
	private Integer allwdcnTNumsConCf;
	
	/*详单周期内与几家委外催收机构催收号码有过联系*/
	private Integer allwdcnTNumsConF;
	
	/*详单周期内与几家互联网金融机构催收号码有过联系*/
	private Integer allwdcnTNumsConIf;
	
	/*详单周期内涉及催收号码的总机构数*/
	private Integer allwdcnTNumsConOrg;
	
	/*详单周期内被催收号码呼叫次数*/
	private Integer allwdcnTTimesIn;
	
	/*详单周期内主叫催收号码次数*/
	private Integer allwdcnTTimesOut;
	
	/*详单周期内被委外催收号码呼叫的总时长*/
	private Integer allwdcnTDurInF;
	
	/*详单周期内被叫次数最大的催收手机号的机构类型*/
	private Integer allwdcmMaxOrgtypeIn;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*预留字段5*/
	private String spare5;
	
	/*预留字段6*/
	private String spare6;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public Float getCallTimesAvg(){
		return callTimesAvg;
	}
	
	public void setCallTimesAvg(Float callTimesAvg){
		this.callTimesAvg = callTimesAvg;
	}
	
	public Integer getContactsCount(){
		return contactsCount;
	}
	
	public void setContactsCount(Integer contactsCount){
		this.contactsCount = contactsCount;
	}
	
	public Integer getDunTelCallDays(){
		return dunTelCallDays;
	}
	
	public void setDunTelCallDays(Integer dunTelCallDays){
		this.dunTelCallDays = dunTelCallDays;
	}
	
	public String getDunTelCallEarliest(){
		return dunTelCallEarliest;
	}
	
	public void setDunTelCallEarliest(String dunTelCallEarliest){
		this.dunTelCallEarliest = dunTelCallEarliest;
	}
	
	public String getDunTelCallRecently(){
		return dunTelCallRecently;
	}
	
	public void setDunTelCallRecently(String dunTelCallRecently){
		this.dunTelCallRecently = dunTelCallRecently;
	}
	
	public String getDunTelCount(){
		return dunTelCount;
	}
	
	public void setDunTelCount(String dunTelCount){
		this.dunTelCount = dunTelCount;
	}
	
	public String getDunTelOrgType(){
		return dunTelOrgType;
	}
	
	public void setDunTelOrgType(String dunTelOrgType){
		this.dunTelOrgType = dunTelOrgType;
	}
	
	public Integer getMaxCallInterval(){
		return maxCallInterval;
	}
	
	public void setMaxCallInterval(Integer maxCallInterval){
		this.maxCallInterval = maxCallInterval;
	}
	
	public Integer getNoCallDays(){
		return noCallDays;
	}
	
	public void setNoCallDays(Integer noCallDays){
		this.noCallDays = noCallDays;
	}
	
	public Integer getL1wwdcnTNumsCon(){
		return l1wwdcnTNumsCon;
	}
	
	public void setL1wwdcnTNumsCon(Integer l1wwdcnTNumsCon){
		this.l1wwdcnTNumsCon = l1wwdcnTNumsCon;
	}
	
	public Integer getL1wwdcnTNumsConBank(){
		return l1wwdcnTNumsConBank;
	}
	
	public void setL1wwdcnTNumsConBank(Integer l1wwdcnTNumsConBank){
		this.l1wwdcnTNumsConBank = l1wwdcnTNumsConBank;
	}
	
	public Integer getL1wwdcnTNumsConCf(){
		return l1wwdcnTNumsConCf;
	}
	
	public void setL1wwdcnTNumsConCf(Integer l1wwdcnTNumsConCf){
		this.l1wwdcnTNumsConCf = l1wwdcnTNumsConCf;
	}
	
	public Integer getL1wwdcnTNumsConF(){
		return l1wwdcnTNumsConF;
	}
	
	public void setL1wwdcnTNumsConF(Integer l1wwdcnTNumsConF){
		this.l1wwdcnTNumsConF = l1wwdcnTNumsConF;
	}
	
	public Integer getL1wwdcnTNumsConIf(){
		return l1wwdcnTNumsConIf;
	}
	
	public void setL1wwdcnTNumsConIf(Integer l1wwdcnTNumsConIf){
		this.l1wwdcnTNumsConIf = l1wwdcnTNumsConIf;
	}
	
	public Integer getL1wwdcnTNumsConOrg(){
		return l1wwdcnTNumsConOrg;
	}
	
	public void setL1wwdcnTNumsConOrg(Integer l1wwdcnTNumsConOrg){
		this.l1wwdcnTNumsConOrg = l1wwdcnTNumsConOrg;
	}
	
	public Integer getL1wwdcnTTimesIn(){
		return l1wwdcnTTimesIn;
	}
	
	public void setL1wwdcnTTimesIn(Integer l1wwdcnTTimesIn){
		this.l1wwdcnTTimesIn = l1wwdcnTTimesIn;
	}
	
	public Integer getL1wwdcnTTimesOut(){
		return l1wwdcnTTimesOut;
	}
	
	public void setL1wwdcnTTimesOut(Integer l1wwdcnTTimesOut){
		this.l1wwdcnTTimesOut = l1wwdcnTTimesOut;
	}
	
	public Integer getL2wwdcnTNumsConOrgtype(){
		return l2wwdcnTNumsConOrgtype;
	}
	
	public void setL2wwdcnTNumsConOrgtype(Integer l2wwdcnTNumsConOrgtype){
		this.l2wwdcnTNumsConOrgtype = l2wwdcnTNumsConOrgtype;
	}
	
	public Integer getL3wwdcnTNumsConIf(){
		return l3wwdcnTNumsConIf;
	}
	
	public void setL3wwdcnTNumsConIf(Integer l3wwdcnTNumsConIf){
		this.l3wwdcnTNumsConIf = l3wwdcnTNumsConIf;
	}
	
	public Integer getL1mwdcnTNumsCon(){
		return l1mwdcnTNumsCon;
	}
	
	public void setL1mwdcnTNumsCon(Integer l1mwdcnTNumsCon){
		this.l1mwdcnTNumsCon = l1mwdcnTNumsCon;
	}
	
	public Integer getL1mwdcnTNumsConBank(){
		return l1mwdcnTNumsConBank;
	}
	
	public void setL1mwdcnTNumsConBank(Integer l1mwdcnTNumsConBank){
		this.l1mwdcnTNumsConBank = l1mwdcnTNumsConBank;
	}
	
	public Integer getL1mwdcnTNumsConCf(){
		return l1mwdcnTNumsConCf;
	}
	
	public void setL1mwdcnTNumsConCf(Integer l1mwdcnTNumsConCf){
		this.l1mwdcnTNumsConCf = l1mwdcnTNumsConCf;
	}
	
	public Integer getL1mwdcnTNumsConF(){
		return l1mwdcnTNumsConF;
	}
	
	public void setL1mwdcnTNumsConF(Integer l1mwdcnTNumsConF){
		this.l1mwdcnTNumsConF = l1mwdcnTNumsConF;
	}
	
	public Integer getL1mwdcnTNumsConIf(){
		return l1mwdcnTNumsConIf;
	}
	
	public void setL1mwdcnTNumsConIf(Integer l1mwdcnTNumsConIf){
		this.l1mwdcnTNumsConIf = l1mwdcnTNumsConIf;
	}
	
	public Integer getL1mwdcnTNumsConOrg(){
		return l1mwdcnTNumsConOrg;
	}
	
	public void setL1mwdcnTNumsConOrg(Integer l1mwdcnTNumsConOrg){
		this.l1mwdcnTNumsConOrg = l1mwdcnTNumsConOrg;
	}
	
	public Integer getL1mwdcnTTimesIn(){
		return l1mwdcnTTimesIn;
	}
	
	public void setL1mwdcnTTimesIn(Integer l1mwdcnTTimesIn){
		this.l1mwdcnTTimesIn = l1mwdcnTTimesIn;
	}
	
	public Integer getL1mwdcnTTimesOut(){
		return l1mwdcnTTimesOut;
	}
	
	public void setL1mwdcnTTimesOut(Integer l1mwdcnTTimesOut){
		this.l1mwdcnTTimesOut = l1mwdcnTTimesOut;
	}
	
	public Integer getL2mwdcnTTimesIn(){
		return l2mwdcnTTimesIn;
	}
	
	public void setL2mwdcnTTimesIn(Integer l2mwdcnTTimesIn){
		this.l2mwdcnTTimesIn = l2mwdcnTTimesIn;
	}
	
	public Integer getL2mwdcnTNumsIn(){
		return l2mwdcnTNumsIn;
	}
	
	public void setL2mwdcnTNumsIn(Integer l2mwdcnTNumsIn){
		this.l2mwdcnTNumsIn = l2mwdcnTNumsIn;
	}
	
	public Integer getL2mwdcnMaxTimesIn(){
		return l2mwdcnMaxTimesIn;
	}
	
	public void setL2mwdcnMaxTimesIn(Integer l2mwdcnMaxTimesIn){
		this.l2mwdcnMaxTimesIn = l2mwdcnMaxTimesIn;
	}
	
	public Integer getL2mwdcnMaxTimesCon(){
		return l2mwdcnMaxTimesCon;
	}
	
	public void setL2mwdcnMaxTimesCon(Integer l2mwdcnMaxTimesCon){
		this.l2mwdcnMaxTimesCon = l2mwdcnMaxTimesCon;
	}
	
	public Integer getL2mencnTDaysCon(){
		return l2mencnTDaysCon;
	}
	
	public void setL2mencnTDaysCon(Integer l2mencnTDaysCon){
		this.l2mencnTDaysCon = l2mencnTDaysCon;
	}
	
	public Integer getL3mwdcnTNumsCon(){
		return l3mwdcnTNumsCon;
	}
	
	public void setL3mwdcnTNumsCon(Integer l3mwdcnTNumsCon){
		this.l3mwdcnTNumsCon = l3mwdcnTNumsCon;
	}
	
	public Integer getL3mwdcnTNumsConBank(){
		return l3mwdcnTNumsConBank;
	}
	
	public void setL3mwdcnTNumsConBank(Integer l3mwdcnTNumsConBank){
		this.l3mwdcnTNumsConBank = l3mwdcnTNumsConBank;
	}
	
	public Integer getL3mwdcnTNumsConCf(){
		return l3mwdcnTNumsConCf;
	}
	
	public void setL3mwdcnTNumsConCf(Integer l3mwdcnTNumsConCf){
		this.l3mwdcnTNumsConCf = l3mwdcnTNumsConCf;
	}
	
	public Integer getL3mwdcnTNumsConF(){
		return l3mwdcnTNumsConF;
	}
	
	public void setL3mwdcnTNumsConF(Integer l3mwdcnTNumsConF){
		this.l3mwdcnTNumsConF = l3mwdcnTNumsConF;
	}
	
	public Integer getL3mwdcnTNumsConIf(){
		return l3mwdcnTNumsConIf;
	}
	
	public void setL3mwdcnTNumsConIf(Integer l3mwdcnTNumsConIf){
		this.l3mwdcnTNumsConIf = l3mwdcnTNumsConIf;
	}
	
	public Integer getL3mencnTNumsConOrg(){
		return l3mencnTNumsConOrg;
	}
	
	public void setL3mencnTNumsConOrg(Integer l3mencnTNumsConOrg){
		this.l3mencnTNumsConOrg = l3mencnTNumsConOrg;
	}
	
	public Integer getL3mwdcnTNumsConOrg(){
		return l3mwdcnTNumsConOrg;
	}
	
	public void setL3mwdcnTNumsConOrg(Integer l3mwdcnTNumsConOrg){
		this.l3mwdcnTNumsConOrg = l3mwdcnTNumsConOrg;
	}
	
	public Integer getL3mwdcnTTimesIn(){
		return l3mwdcnTTimesIn;
	}
	
	public void setL3mwdcnTTimesIn(Integer l3mwdcnTTimesIn){
		this.l3mwdcnTTimesIn = l3mwdcnTTimesIn;
	}
	
	public Integer getL3mwdcnTTimesOut(){
		return l3mwdcnTTimesOut;
	}
	
	public void setL3mwdcnTTimesOut(Integer l3mwdcnTTimesOut){
		this.l3mwdcnTTimesOut = l3mwdcnTTimesOut;
	}
	
	public Integer getL3mwdcnAddTNumsInOrg(){
		return l3mwdcnAddTNumsInOrg;
	}
	
	public void setL3mwdcnAddTNumsInOrg(Integer l3mwdcnAddTNumsInOrg){
		this.l3mwdcnAddTNumsInOrg = l3mwdcnAddTNumsInOrg;
	}
	
	public Integer getL3mwdcnMaxDaysIn(){
		return l3mwdcnMaxDaysIn;
	}
	
	public void setL3mwdcnMaxDaysIn(Integer l3mwdcnMaxDaysIn){
		this.l3mwdcnMaxDaysIn = l3mwdcnMaxDaysIn;
	}
	
	public Integer getL4mwdcnTNumsConOrgtype(){
		return l4mwdcnTNumsConOrgtype;
	}
	
	public void setL4mwdcnTNumsConOrgtype(Integer l4mwdcnTNumsConOrgtype){
		this.l4mwdcnTNumsConOrgtype = l4mwdcnTNumsConOrgtype;
	}
	
	public Integer getL4mwdcnTTimesInNonbank(){
		return l4mwdcnTTimesInNonbank;
	}
	
	public void setL4mwdcnTTimesInNonbank(Integer l4mwdcnTTimesInNonbank){
		this.l4mwdcnTTimesInNonbank = l4mwdcnTTimesInNonbank;
	}
	
	public Integer getL4mwdcnTDurCon(){
		return l4mwdcnTDurCon;
	}
	
	public void setL4mwdcnTDurCon(Integer l4mwdcnTDurCon){
		this.l4mwdcnTDurCon = l4mwdcnTDurCon;
	}
	
	public Integer getL4mwdcnTTimesCon(){
		return l4mwdcnTTimesCon;
	}
	
	public void setL4mwdcnTTimesCon(Integer l4mwdcnTTimesCon){
		this.l4mwdcnTTimesCon = l4mwdcnTTimesCon;
	}
	
	public Integer getL4mwdcnTNumsConF(){
		return l4mwdcnTNumsConF;
	}
	
	public void setL4mwdcnTNumsConF(Integer l4mwdcnTNumsConF){
		this.l4mwdcnTNumsConF = l4mwdcnTNumsConF;
	}
	
	public Integer getL4mwdcnTDurIn(){
		return l4mwdcnTDurIn;
	}
	
	public void setL4mwdcnTDurIn(Integer l4mwdcnTDurIn){
		this.l4mwdcnTDurIn = l4mwdcnTDurIn;
	}
	
	public Integer getL4mwdcnTDurInMaxTimes(){
		return l4mwdcnTDurInMaxTimes;
	}
	
	public void setL4mwdcnTDurInMaxTimes(Integer l4mwdcnTDurInMaxTimes){
		this.l4mwdcnTDurInMaxTimes = l4mwdcnTDurInMaxTimes;
	}
	
	public Integer getL4mwdcnTNumsInF(){
		return l4mwdcnTNumsInF;
	}
	
	public void setL4mwdcnTNumsInF(Integer l4mwdcnTNumsInF){
		this.l4mwdcnTNumsInF = l4mwdcnTNumsInF;
	}
	
	public Integer getL5mwdcnTDaysCon(){
		return l5mwdcnTDaysCon;
	}
	
	public void setL5mwdcnTDaysCon(Integer l5mwdcnTDaysCon){
		this.l5mwdcnTDaysCon = l5mwdcnTDaysCon;
	}
	
	public Integer getL5mwdcnTDurInF(){
		return l5mwdcnTDurInF;
	}
	
	public void setL5mwdcnTDurInF(Integer l5mwdcnTDurInF){
		this.l5mwdcnTDurInF = l5mwdcnTDurInF;
	}
	
	public Integer getL5mwdcmTDurCon(){
		return l5mwdcmTDurCon;
	}
	
	public void setL5mwdcmTDurCon(Integer l5mwdcmTDurCon){
		this.l5mwdcmTDurCon = l5mwdcmTDurCon;
	}
	
	public Integer getL5mwdcnTNumsConIf(){
		return l5mwdcnTNumsConIf;
	}
	
	public void setL5mwdcnTNumsConIf(Integer l5mwdcnTNumsConIf){
		this.l5mwdcnTNumsConIf = l5mwdcnTNumsConIf;
	}
	
	public Integer getAllwdcnTNumsCon(){
		return allwdcnTNumsCon;
	}
	
	public void setAllwdcnTNumsCon(Integer allwdcnTNumsCon){
		this.allwdcnTNumsCon = allwdcnTNumsCon;
	}
	
	public Integer getAllwdcnTNumsConBank(){
		return allwdcnTNumsConBank;
	}
	
	public void setAllwdcnTNumsConBank(Integer allwdcnTNumsConBank){
		this.allwdcnTNumsConBank = allwdcnTNumsConBank;
	}
	
	public Integer getAllwdcnTNumsConCf(){
		return allwdcnTNumsConCf;
	}
	
	public void setAllwdcnTNumsConCf(Integer allwdcnTNumsConCf){
		this.allwdcnTNumsConCf = allwdcnTNumsConCf;
	}
	
	public Integer getAllwdcnTNumsConF(){
		return allwdcnTNumsConF;
	}
	
	public void setAllwdcnTNumsConF(Integer allwdcnTNumsConF){
		this.allwdcnTNumsConF = allwdcnTNumsConF;
	}
	
	public Integer getAllwdcnTNumsConIf(){
		return allwdcnTNumsConIf;
	}
	
	public void setAllwdcnTNumsConIf(Integer allwdcnTNumsConIf){
		this.allwdcnTNumsConIf = allwdcnTNumsConIf;
	}
	
	public Integer getAllwdcnTNumsConOrg(){
		return allwdcnTNumsConOrg;
	}
	
	public void setAllwdcnTNumsConOrg(Integer allwdcnTNumsConOrg){
		this.allwdcnTNumsConOrg = allwdcnTNumsConOrg;
	}
	
	public Integer getAllwdcnTTimesIn(){
		return allwdcnTTimesIn;
	}
	
	public void setAllwdcnTTimesIn(Integer allwdcnTTimesIn){
		this.allwdcnTTimesIn = allwdcnTTimesIn;
	}
	
	public Integer getAllwdcnTTimesOut(){
		return allwdcnTTimesOut;
	}
	
	public void setAllwdcnTTimesOut(Integer allwdcnTTimesOut){
		this.allwdcnTTimesOut = allwdcnTTimesOut;
	}
	
	public Integer getAllwdcnTDurInF(){
		return allwdcnTDurInF;
	}
	
	public void setAllwdcnTDurInF(Integer allwdcnTDurInF){
		this.allwdcnTDurInF = allwdcnTDurInF;
	}
	
	public Integer getAllwdcmMaxOrgtypeIn(){
		return allwdcmMaxOrgtypeIn;
	}
	
	public void setAllwdcmMaxOrgtypeIn(Integer allwdcmMaxOrgtypeIn){
		this.allwdcmMaxOrgtypeIn = allwdcmMaxOrgtypeIn;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public String getSpare5(){
		return spare5;
	}
	
	public void setSpare5(String spare5){
		this.spare5 = spare5;
	}
	
	public String getSpare6(){
		return spare6;
	}
	
	public void setSpare6(String spare6){
		this.spare6 = spare6;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
