package com.macroflag.plusplatform.data.inner.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.macroflag.plusplatform.common.annotations.SystemLog;
import com.macroflag.plusplatform.common.exception.BaseException;
import com.macroflag.plusplatform.common.exception.ExceptionUtils;
import com.macroflag.plusplatform.data.inner.biz.MfNetgateCupdTaxCodeBiz;
import com.macroflag.plusplatform.data.inner.config.service.IApiConfigService;
import com.macroflag.plusplatform.data.inner.controller.base.BaseNetgateController;
import com.macroflag.plusplatform.data.inner.entity.ApiConfigDomain;
import com.macroflag.plusplatform.data.inner.entity.MfNetgateCupdTaxCode;
import com.macroflag.plusplatform.data.inner.thirdpart.component.ICupdPartyService;
import com.macroflag.plusplatform.data.inner.thirdpart.model.UserDataModel;
import com.wordnik.swagger.annotations.ApiParam;

/**
 * 近期消费水平预测
 * @author huangf
 *
 */
@Scope(value = "prototype")
@RestController
@RequestMapping("/cupd")
public class CupdOccDataController extends BaseNetgateController{
	
	@Autowired
    private ICupdPartyService cupdPartyService;
	@Autowired
	private IApiConfigService apiConfigService;
	@Autowired
	private MfNetgateCupdTaxCodeBiz mfNetgateCupdTaxCodeBiz;

	@RequestMapping(value = "getCudeOccdata", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "近期消费水平预测", requestMethod = RequestMethod.GET)
    public Object getCudeOccdata(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey){
		
		logger.info("#########进入近期消费水平预测接口,申请编号为{}#########",businessKey);
		
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		
		// 构建数据模型
		buildData(userDataModel);
		String uniqueNo = userDataModel.getUniqueNo();
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("getCudeOccdata");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
			throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########",json);
			return json;

		} else if (1 == status) {
			/* 1.外部数据:先查询是否存在该用户原始数据 */
			MfNetgateCupdTaxCode entity = new MfNetgateCupdTaxCode();
			entity.setUniqueNo(uniqueNo);
			MfNetgateCupdTaxCode mfNetgateCupdTaxCode = mfNetgateCupdTaxCodeBiz.selectOne(entity);
			if(mfNetgateCupdTaxCode == null){
				logger.info("#########该客户未存在数据，调接口查询：{}#########");
				cupdPartyService.rcOccdata(userDataModel);
			}
			
		}
    	
    	return jo;
    }
}
