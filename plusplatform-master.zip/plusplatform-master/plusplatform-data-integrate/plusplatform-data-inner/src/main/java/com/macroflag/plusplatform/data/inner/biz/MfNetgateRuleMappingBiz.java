package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateRuleMapping;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateRuleMappingMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-31 20:08:06
 * @version : v1.0.0
 */
@Service
public class MfNetgateRuleMappingBiz extends BusinessBiz<MfNetgateRuleMappingMapper,MfNetgateRuleMapping> {
}