package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 前海输入项表的domain
 * @author : fredia
 * @since : 2018年04月24日
 * @version : v0.0.1
 */
public class QhFraudInitemDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键id*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*风险标记B1*/
	private String rskMark1;
	
	/*风险标记B2*/
	private String rskMark2;
	
	/**/
	private String rskMark;
	
	/*前海好信分*/
	private Integer credooScore;
	
	/*命中暴力破解*/
	private String hitForce;
	
	/*命中dns服务器*/
	private String hitDns;
	
	/*命中邮件服务器*/
	private String hitMailServ;
	
	/*命中seo*/
	private String hitSeo;
	
	/*命中组织出口*/
	private String hitOrg;
	
	/*命中爬虫*/
	private String hitCrawler;
	
	/*命中代理服务器*/
	private String hitProxy;
	
	/*命中ip第三方标注黑名单*/
	private String hitBlacklist;
	
	/*命中web服务器*/
	private String hitWebServ;
	
	/*命中vpn服务器*/
	private String hitVpn;
	
	/*命中手机号第三方标注黑名单*/
	private String hitBlMakt;
	
	/*命中命中骚扰电话*/
	private String hitCraCall;
	
	/*命中欺诈号码*/
	private String hitFraud;
	
	/*命中空号*/
	private String hitEmpty;
	
	/*命中收码平台号码*/
	private String hitYZMobile;
	
	/*命中小号*/
	private String hitSmallNo;
	
	/*命中社工库号码*/
	private String hitSZNo;
	
	/*前海近1个月查询次数*/
	private Integer queryCnts1Mth;
	
	/*前海近3个月查询次数*/
	private Integer queryCnts3Mth;
	
	/*前海近6个月查询次数*/
	private Integer queryCnts6Mth;
	
	/*前海近12个月查询次数*/
	private Integer queryCnts12Mth;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getRskMark1(){
		return rskMark1;
	}
	
	public void setRskMark1(String rskMark1){
		this.rskMark1 = rskMark1;
	}
	
	public String getRskMark2(){
		return rskMark2;
	}
	
	public void setRskMark2(String rskMark2){
		this.rskMark2 = rskMark2;
	}
	
	public String getRskMark(){
		return rskMark;
	}
	
	public void setRskMark(String rskMark){
		this.rskMark = rskMark;
	}
	
	public Integer getCredooScore(){
		return credooScore;
	}
	
	public void setCredooScore(Integer credooScore){
		this.credooScore = credooScore;
	}
	
	public String getHitForce(){
		return hitForce;
	}
	
	public void setHitForce(String hitForce){
		this.hitForce = hitForce;
	}
	
	public String getHitDns(){
		return hitDns;
	}
	
	public void setHitDns(String hitDns){
		this.hitDns = hitDns;
	}
	
	public String getHitMailServ(){
		return hitMailServ;
	}
	
	public void setHitMailServ(String hitMailServ){
		this.hitMailServ = hitMailServ;
	}
	
	public String getHitSeo(){
		return hitSeo;
	}
	
	public void setHitSeo(String hitSeo){
		this.hitSeo = hitSeo;
	}
	
	public String getHitOrg(){
		return hitOrg;
	}
	
	public void setHitOrg(String hitOrg){
		this.hitOrg = hitOrg;
	}
	
	public String getHitCrawler(){
		return hitCrawler;
	}
	
	public void setHitCrawler(String hitCrawler){
		this.hitCrawler = hitCrawler;
	}
	
	public String getHitProxy(){
		return hitProxy;
	}
	
	public void setHitProxy(String hitProxy){
		this.hitProxy = hitProxy;
	}
	
	public String getHitBlacklist(){
		return hitBlacklist;
	}
	
	public void setHitBlacklist(String hitBlacklist){
		this.hitBlacklist = hitBlacklist;
	}
	
	public String getHitWebServ(){
		return hitWebServ;
	}
	
	public void setHitWebServ(String hitWebServ){
		this.hitWebServ = hitWebServ;
	}
	
	public String getHitVpn(){
		return hitVpn;
	}
	
	public void setHitVpn(String hitVpn){
		this.hitVpn = hitVpn;
	}
	
	public String getHitBlMakt(){
		return hitBlMakt;
	}
	
	public void setHitBlMakt(String hitBlMakt){
		this.hitBlMakt = hitBlMakt;
	}
	
	public String getHitCraCall(){
		return hitCraCall;
	}
	
	public void setHitCraCall(String hitCraCall){
		this.hitCraCall = hitCraCall;
	}
	
	public String getHitFraud(){
		return hitFraud;
	}
	
	public void setHitFraud(String hitFraud){
		this.hitFraud = hitFraud;
	}
	
	public String getHitEmpty(){
		return hitEmpty;
	}
	
	public void setHitEmpty(String hitEmpty){
		this.hitEmpty = hitEmpty;
	}
	
	public String getHitYZMobile(){
		return hitYZMobile;
	}
	
	public void setHitYZMobile(String hitYZMobile){
		this.hitYZMobile = hitYZMobile;
	}
	
	public String getHitSmallNo(){
		return hitSmallNo;
	}
	
	public void setHitSmallNo(String hitSmallNo){
		this.hitSmallNo = hitSmallNo;
	}
	
	public String getHitSZNo(){
		return hitSZNo;
	}
	
	public void setHitSZNo(String hitSZNo){
		this.hitSZNo = hitSZNo;
	}
	
	public Integer getQueryCnts1Mth(){
		return queryCnts1Mth;
	}
	
	public void setQueryCnts1Mth(Integer queryCnts1Mth){
		this.queryCnts1Mth = queryCnts1Mth;
	}
	
	public Integer getQueryCnts3Mth(){
		return queryCnts3Mth;
	}
	
	public void setQueryCnts3Mth(Integer queryCnts3Mth){
		this.queryCnts3Mth = queryCnts3Mth;
	}
	
	public Integer getQueryCnts6Mth(){
		return queryCnts6Mth;
	}
	
	public void setQueryCnts6Mth(Integer queryCnts6Mth){
		this.queryCnts6Mth = queryCnts6Mth;
	}
	
	public Integer getQueryCnts12Mth(){
		return queryCnts12Mth;
	}
	
	public void setQueryCnts12Mth(Integer queryCnts12Mth){
		this.queryCnts12Mth = queryCnts12Mth;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
