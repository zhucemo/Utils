package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

import com.macroflag.plusplatform.encryption.annotation.EnDomain;
import com.macroflag.plusplatform.encryption.annotation.EnField;

/**
 * 凭安联系人标签模块的domain
 * @author : huangf
 * @since : 2018年04月18日
 * @version : v0.0.1
 */
@EnDomain
public class PacraContactTagDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*联系人号码*/
	@EnField
	private String number;
	
	/*当命中催收号码时，该字段为联系人号码所属的机构类型，若未命中催收号码，该字段为“普通联系人”*/
	private String orgType;
	
	/*需求类型，当命中催收号码时，该字段的值为“催收”，若未命中催收号码，该字段的值为空字符串*/
	private String demandType;
	
	/*与联系人的累计通话时长，不区分主被叫*/
	private Integer callDuration;
	
	/*联系次数，不区分主被叫*/
	private Integer callCount;
	
	/*主叫次数*/
	private Integer callOutCount;
	
	/*被叫次数*/
	private Integer callInCount;
	
	/*是否为周期性联系，若为周期性联系，则该字段值为“是”，若不是周期性联系，则该字段值为“否”)*/
	private String periodicallyContact;
	
	/*联系人紧密度，用来表示联系频率，可选值有: 不频繁、一般、经常联系、未知*/
	private String callFrequency;
	
	/*催收号码的最新曝光时间*/
	private String lastMarkDate;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getNumber(){
		return number;
	}
	
	public void setNumber(String number){
		this.number = number;
	}
	
	public String getOrgType(){
		return orgType;
	}
	
	public void setOrgType(String orgType){
		this.orgType = orgType;
	}
	
	public String getDemandType(){
		return demandType;
	}
	
	public void setDemandType(String demandType){
		this.demandType = demandType;
	}
	
	public Integer getCallDuration(){
		return callDuration;
	}
	
	public void setCallDuration(Integer callDuration){
		this.callDuration = callDuration;
	}
	
	public Integer getCallCount(){
		return callCount;
	}
	
	public void setCallCount(Integer callCount){
		this.callCount = callCount;
	}
	
	public Integer getCallOutCount(){
		return callOutCount;
	}
	
	public void setCallOutCount(Integer callOutCount){
		this.callOutCount = callOutCount;
	}
	
	public Integer getCallInCount(){
		return callInCount;
	}
	
	public void setCallInCount(Integer callInCount){
		this.callInCount = callInCount;
	}
	
	public String getPeriodicallyContact(){
		return periodicallyContact;
	}
	
	public void setPeriodicallyContact(String periodicallyContact){
		this.periodicallyContact = periodicallyContact;
	}
	
	public String getCallFrequency(){
		return callFrequency;
	}
	
	public void setCallFrequency(String callFrequency){
		this.callFrequency = callFrequency;
	}
	
	public String getLastMarkDate(){
		return lastMarkDate;
	}
	
	public void setLastMarkDate(String lastMarkDate){
		this.lastMarkDate = lastMarkDate;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
