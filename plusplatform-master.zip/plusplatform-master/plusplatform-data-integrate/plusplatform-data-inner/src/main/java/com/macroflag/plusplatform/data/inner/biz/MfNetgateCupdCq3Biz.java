package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.common.biz.BusinessBiz;
import com.macroflag.plusplatform.data.inner.entity.MfNetgateCupdCq3;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateCupdCq3Mapper;

/**
 * 
 * 
 * @author : Fredia
 * @email trumpey@163.com
 * @since : 2018-07-02 11:31:55
 * @version : v1.0.0
 */
@Service
public class MfNetgateCupdCq3Biz extends BusinessBiz<MfNetgateCupdCq3Mapper,MfNetgateCupdCq3> {

	@Autowired
	private MfNetgateCupdCq3Mapper netgateCupdCq3Mapper;
	
	public void updateBySerialNumber(MfNetgateCupdCq3 netgateCupdCq3) {
		
		MfNetgateCupdCq3 example = new MfNetgateCupdCq3();
		example.setSerialNumber(netgateCupdCq3.getSerialNumber());
		netgateCupdCq3Mapper.updateByExampleSelective(netgateCupdCq3, example);
	}
}