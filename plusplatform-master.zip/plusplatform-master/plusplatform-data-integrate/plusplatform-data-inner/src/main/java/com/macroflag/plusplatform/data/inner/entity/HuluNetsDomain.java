package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 葫芦流量记录的domain
 * @author : huangf
 * @since : 2018年04月24日
 * @version : v0.0.1
 */
public class HuluNetsDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*发送时间*/
	private Date startTime;
	
	/*数据获取时间*/
	private Date getDateTime;
	
	/*通话时长（秒）*/
	private Integer useTime;
	
	/*流量使用量（kb）*/
	private Double subflow;
	
	/*流量使用量（kb）*/
	private String netType;
	
	/*本次短信花费（元）*/
	private Double subtotal;
	
	/*流量使用地点*/
	private String place;
	
	/*本机号码*/
	private String cellPhone;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long creatUser;
	
	/*创建时间*/
	private Date creatTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public Date getStartTime(){
		return startTime;
	}
	
	public void setStartTime(Date startTime){
		this.startTime = startTime;
	}
	
	public Date getGetDateTime(){
		return getDateTime;
	}
	
	public void setGetDateTime(Date getDateTime){
		this.getDateTime = getDateTime;
	}
	
	public Integer getUseTime(){
		return useTime;
	}
	
	public void setUseTime(Integer useTime){
		this.useTime = useTime;
	}
	
	public Double getSubflow(){
		return subflow;
	}
	
	public void setSubflow(Double subflow){
		this.subflow = subflow;
	}
	
	public String getNetType(){
		return netType;
	}
	
	public void setNetType(String netType){
		this.netType = netType;
	}
	
	public Double getSubtotal(){
		return subtotal;
	}
	
	public void setSubtotal(Double subtotal){
		this.subtotal = subtotal;
	}
	
	public String getPlace(){
		return place;
	}
	
	public void setPlace(String place){
		this.place = place;
	}
	
	public String getCellPhone(){
		return cellPhone;
	}
	
	public void setCellPhone(String cellPhone){
		this.cellPhone = cellPhone;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreatUser(){
		return creatUser;
	}
	
	public void setCreatUser(Long creatUser){
		this.creatUser = creatUser;
	}
	
	public Date getCreatTime(){
		return creatTime;
	}
	
	public void setCreatTime(Date creatTime){
		this.creatTime = creatTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
