package com.macroflag.plusplatform.data.inner.biz;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateBlacklistPhone;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateBlacklistPhoneMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 手机黑名单
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-08-02 19:58:12
 * @version : v1.0.0
 */
@Service
public class MfNetgateBlacklistPhoneBiz extends BusinessBiz<MfNetgateBlacklistPhoneMapper,MfNetgateBlacklistPhone> {

	
	@Autowired
	private MfNetgateBlacklistPhoneMapper mfNetgateBlacklistPhoneMapper;
	
	
	public Map<String, Object> selectBlByPhone(String phoneVal) {
		Map<String, Object> map = mfNetgateBlacklistPhoneMapper.selectBlByPhone(phoneVal);
		return map;
	}


	public void updateByIdcard(MfNetgateBlacklistPhone mfNetgateBlacklistPhone) {
		MfNetgateBlacklistPhone entity = new MfNetgateBlacklistPhone();
		entity.setKeyVal(mfNetgateBlacklistPhone.getKeyVal());
		MfNetgateBlacklistPhone blacklistPhone = mfNetgateBlacklistPhoneMapper.selectOne(entity);
		mfNetgateBlacklistPhone.setId(blacklistPhone.getId());
		mfNetgateBlacklistPhoneMapper.updateByPrimaryKey(mfNetgateBlacklistPhone);
		
	}
}