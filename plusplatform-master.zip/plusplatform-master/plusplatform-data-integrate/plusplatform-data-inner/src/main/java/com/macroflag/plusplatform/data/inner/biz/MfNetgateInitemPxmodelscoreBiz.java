package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateInitemPxmodelscore;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateInitemPxmodelscoreMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-19 14:13:34
 * @version : v1.0.0
 */
@Service
public class MfNetgateInitemPxmodelscoreBiz extends BusinessBiz<MfNetgateInitemPxmodelscoreMapper,MfNetgateInitemPxmodelscore> {

	@Autowired
	private MfNetgateInitemPxmodelscoreMapper mfNetgateInitemPxmodelscoreMapper;
	
	
	
	/**
	 * 更新输入项参数
	 * @param mfNetgateInitemPxmodelscore
	 */
	public void updateByUniqueNo(MfNetgateInitemPxmodelscore mfNetgateInitemPxmodelscore) {
		
		mfNetgateInitemPxmodelscoreMapper.updateByUniqueNo(mfNetgateInitemPxmodelscore);
	}

	
}