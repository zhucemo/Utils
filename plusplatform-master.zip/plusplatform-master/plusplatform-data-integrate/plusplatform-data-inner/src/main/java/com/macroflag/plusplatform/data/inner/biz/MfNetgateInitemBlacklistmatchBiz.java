package com.macroflag.plusplatform.data.inner.biz;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateInitemBlacklistmatch;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateInitemBlacklistmatchMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-31 09:39:41
 * @version : v1.0.0
 */
@Service
public class MfNetgateInitemBlacklistmatchBiz extends BusinessBiz<MfNetgateInitemBlacklistmatchMapper,MfNetgateInitemBlacklistmatch> {

	@Autowired
	private MfNetgateInitemBlacklistmatchMapper mfNetgateInitemBlacklistmatchMapper;
	
	public int blIDFlag(Map<String, Object> params) {
		int count = mfNetgateInitemBlacklistmatchMapper.blIDFlag(params);
		return count;
	}

	public int blTelFlag(Map<String, Object> params) {
		int count = mfNetgateInitemBlacklistmatchMapper.blTelFlag(params);
		return count;
	}
	
	public int blTelIsSmallNo(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.blTelIsSmallNo(params);
		return count;
	}

	public int blTelIsGamble(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.blTelIsGamble(params);
		return count;
	}

	public int blOuterFlag(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.blOuterFlag(params);
		return count;
	}

	public int blgIDFlag(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.blgIDFlag(params);
		return count;
	}

	public int blgTelFlag(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.blgTelFlag(params);
		return count;
	}

	public int blysIDFlag(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.blysIDFlag(params);
		return count;
	}

	public int blysTelFlag(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.blysTelFlag(params);
		return count;
	}

	public Integer rgMobilehitAgent(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.rgMobilehitAgent(params);
		return count;
	}

	public int rgblysgIDFlag(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.rgblysgIDFlag(params);
		return count;
	}

	public int rgblysgTelFlag(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.rgblysgTelFlag(params);
		return count;
	}

	public int rgblysgIdOuterFlag(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.rgblysgIdOuterFlag(params);
		return count;
	}

	public int rgblysgPhoneOuterFlag(Map<String, Object> params){
		int count = mfNetgateInitemBlacklistmatchMapper.rgblysgPhoneOuterFlag(params);
		return count;
	}

	public void updateByUniqueNo(MfNetgateInitemBlacklistmatch blackListInitemDomain) {
		
		mfNetgateInitemBlacklistmatchMapper.updateByUniqueNo(blackListInitemDomain);
	}

	public int rgblTelContact1Flag(String immediateFamilyPhone) {
		int count = mfNetgateInitemBlacklistmatchMapper.rgblTelContact1Flag(immediateFamilyPhone);
		return count;
	}

	public int rgblgTelContact1Flag(String immediateFamilyPhone) {
		int count = mfNetgateInitemBlacklistmatchMapper.rgblgTelContact1Flag(immediateFamilyPhone);
		return count;
	}

	public int rgblysTelContact1Flag(String immediateFamilyPhone) {
		int count = mfNetgateInitemBlacklistmatchMapper.rgblysTelContact1Flag(immediateFamilyPhone);
		return count;
	}

	public int rgblysgTelContact1Flag(String immediateFamilyPhone) {
		int count = mfNetgateInitemBlacklistmatchMapper.rgblysgTelContact1Flag(immediateFamilyPhone);
		return count;
	}

	public int rgblTelContact2Flag(String anotherContactsPhone) {
		int count = mfNetgateInitemBlacklistmatchMapper.rgblTelContact2Flag(anotherContactsPhone);
		return count;
	}

	public int rgblgTelContact2Flag(String anotherContactsPhone) {
		int count = mfNetgateInitemBlacklistmatchMapper.rgblgTelContact2Flag(anotherContactsPhone);
		return count;
	}

	public int rgblysTelContact2Flag(String anotherContactsPhone) {
		int count = mfNetgateInitemBlacklistmatchMapper.rgblysTelContact2Flag(anotherContactsPhone);
		return count;
	}

	public int rgblysgTelContact2Flag(String anotherContactsPhone) {
		int count = mfNetgateInitemBlacklistmatchMapper.rgblysgTelContact2Flag(anotherContactsPhone);
		return count;
	}

	public int coNameContainBlname(String companyName) {
		int count = mfNetgateInitemBlacklistmatchMapper.coNameContainBlname(companyName);
		return count;
	}

	public int coNumhitBlnum(String companyPhone) {
		int count = mfNetgateInitemBlacklistmatchMapper.coNumhitBlnum(companyPhone);
		return count;
	}
}