package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

import com.macroflag.plusplatform.encryption.annotation.EnDomain;
import com.macroflag.plusplatform.encryption.annotation.EnField;

/**
 * 风险度提示表的domain
 * @author : fredia
 * @since : 2018年04月24日
 * @version : v0.0.1
 */
@EnDomain
public class QhRskdooDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*证件号码*/
	@EnField
	private String idNo;
	
	/*证件类型*/
	private String idType;
	
	/*主体名称*/
	@EnField
	private String name;
	
	/*序列号*/
	private String seqNo;
	
	/*来源代码*/
	private String sourceId;
	
	/*风险得分*/
	private String rskScore;
	
	/*风险标记*/
	private String rskMark;
	
	/*业务发生时间*/
	private String dataBuildTime;
	
	/*数据状态*/
	private String dataStatus;
	
	/*错误代码*/
	private String erCode;
	
	/*错误信息*/
	private String erMsg;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getIdNo(){
		return idNo;
	}
	
	public void setIdNo(String idNo){
		this.idNo = idNo;
	}
	
	public String getIdType(){
		return idType;
	}
	
	public void setIdType(String idType){
		this.idType = idType;
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getSeqNo(){
		return seqNo;
	}
	
	public void setSeqNo(String seqNo){
		this.seqNo = seqNo;
	}
	
	public String getSourceId(){
		return sourceId;
	}
	
	public void setSourceId(String sourceId){
		this.sourceId = sourceId;
	}
	
	public String getRskScore(){
		return rskScore;
	}
	
	public void setRskScore(String rskScore){
		this.rskScore = rskScore;
	}
	
	public String getRskMark(){
		return rskMark;
	}
	
	public void setRskMark(String rskMark){
		this.rskMark = rskMark;
	}
	
	public String getDataBuildTime(){
		return dataBuildTime;
	}
	
	public void setDataBuildTime(String dataBuildTime){
		this.dataBuildTime = dataBuildTime;
	}
	
	public String getDataStatus(){
		return dataStatus;
	}
	
	public void setDataStatus(String dataStatus){
		this.dataStatus = dataStatus;
	}
	
	public String getErCode(){
		return erCode;
	}
	
	public void setErCode(String erCode){
		this.erCode = erCode;
	}
	
	public String getErMsg(){
		return erMsg;
	}
	
	public void setErMsg(String erMsg){
		this.erMsg = erMsg;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
