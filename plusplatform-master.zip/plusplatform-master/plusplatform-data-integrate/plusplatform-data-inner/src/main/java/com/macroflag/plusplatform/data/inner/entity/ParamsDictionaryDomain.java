package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 参数字典表的domain
 * @author : Fredia
 * @since : 2018年05月05日
 * @version : v0.0.1
 */
public class ParamsDictionaryDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*中文名称*/
	private String cnName;
	
	/*英文名称*/
	private String enName;
	
	/*别名*/
	private String alias;
	
	/*参数类型，1-输入项，0-输出项*/
	private String type;
	
	/*所属第三方模块*/
	private String module;
	
	/*当前是否有效,1-有效，0-无效*/
	private String status;
	
	/**/
	private Date createTime;
	
	/**/
	private String createUser;
	
	/**/
	private Date updateTime;
	
	/**/
	private String updateUser;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getCnName(){
		return cnName;
	}
	
	public void setCnName(String cnName){
		this.cnName = cnName;
	}
	
	public String getEnName(){
		return enName;
	}
	
	public void setEnName(String enName){
		this.enName = enName;
	}
	
	public String getAlias(){
		return alias;
	}
	
	public void setAlias(String alias){
		this.alias = alias;
	}
	
	public String getType(){
		return type;
	}
	
	public void setType(String type){
		this.type = type;
	}
	
	public String getModule(){
		return module;
	}
	
	public void setModule(String module){
		this.module = module;
	}
	
	public String getStatus(){
		return status;
	}
	
	public void setStatus(String status){
		this.status = status;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public String getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(String createUser){
		this.createUser = createUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	public String getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(String updateUser){
		this.updateUser = updateUser;
	}
	
	
}
