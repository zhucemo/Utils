package com.macroflag.plusplatform.data.inner.entity;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;


/**
 * 黑名单类型表
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-09-19 14:53:47
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_black_type")
public class MfNetgateBlackType implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Long id;
	
	    //名单类型
    @Column(name = "black_type")
    private String blackType;
	
	    //一级
    @Column(name = "black_type1")
    private String blackType1;
	
	    //二级
    @Column(name = "black_type2")
    private String blackType2;
	
	    //三级
    @Column(name = "black_type3")
    private String blackType3;
	
	    //
    @Column(name = "black_type_u")
    private String blackTypeU;
	
	    //
    @Column(name = "black_type_u1")
    private String blackTypeU1;
	
	    //
    @Column(name = "black_type_u2")
    private String blackTypeU2;
	
	    //
    @Column(name = "black_type_u3")
    private String blackTypeU3;
	
	    //
    @Column(name = "create_time")
    private Date createTime;
	
	    //
    @Column(name = "create_user")
    private Long createUser;
	
	    //
    @Column(name = "update_time")
    private Date updateTime;
	
	    //
    @Column(name = "update_user")
    private Long updateUser;
	

	/**
	 * 设置：主键
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：名单类型
	 */
	public void setBlackType(String blackType) {
		this.blackType = blackType;
	}
	/**
	 * 获取：名单类型
	 */
	public String getBlackType() {
		return blackType;
	}
	/**
	 * 设置：一级
	 */
	public void setBlackType1(String blackType1) {
		this.blackType1 = blackType1;
	}
	/**
	 * 获取：一级
	 */
	public String getBlackType1() {
		return blackType1;
	}
	/**
	 * 设置：二级
	 */
	public void setBlackType2(String blackType2) {
		this.blackType2 = blackType2;
	}
	/**
	 * 获取：二级
	 */
	public String getBlackType2() {
		return blackType2;
	}
	/**
	 * 设置：三级
	 */
	public void setBlackType3(String blackType3) {
		this.blackType3 = blackType3;
	}
	/**
	 * 获取：三级
	 */
	public String getBlackType3() {
		return blackType3;
	}
	/**
	 * 设置：
	 */
	public void setBlackTypeU(String blackTypeU) {
		this.blackTypeU = blackTypeU;
	}
	/**
	 * 获取：
	 */
	public String getBlackTypeU() {
		return blackTypeU;
	}
	/**
	 * 设置：
	 */
	public void setBlackTypeU1(String blackTypeU1) {
		this.blackTypeU1 = blackTypeU1;
	}
	/**
	 * 获取：
	 */
	public String getBlackTypeU1() {
		return blackTypeU1;
	}
	/**
	 * 设置：
	 */
	public void setBlackTypeU2(String blackTypeU2) {
		this.blackTypeU2 = blackTypeU2;
	}
	/**
	 * 获取：
	 */
	public String getBlackTypeU2() {
		return blackTypeU2;
	}
	/**
	 * 设置：
	 */
	public void setBlackTypeU3(String blackTypeU3) {
		this.blackTypeU3 = blackTypeU3;
	}
	/**
	 * 获取：
	 */
	public String getBlackTypeU3() {
		return blackTypeU3;
	}
	/**
	 * 设置：
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：
	 */
	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：
	 */
	public Long getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
	/**
	 * 设置：
	 */
	public void setUpdateUser(Long updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：
	 */
	public Long getUpdateUser() {
		return updateUser;
	}
}
