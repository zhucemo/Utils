package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 系统接口日志表的domain
 * @author : Fredia
 * @since : 2018年04月26日
 * @version : v0.0.1
 */
public class SystemLogsDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*id*/
	private Long id;
	
	/*业务编号*/
	private String applyNo;
	
	/*请求编号*/
	private String reqNo;
	
	/*模块*/
	private String module;
	
	/*方法*/
	private String method;
	
	/*请求类型*/
	private String requestMethod;
	
	/*是否为内部请求0-否，1-是*/
	private Integer isInternal;
	
	/**/
	private String reqIp;
	
	/**/
	private String reqUrl;
	
	/**/
	private String reqParam;
	
	/**/
	private String respContent;
	
	/**/
	private String respCode;
	
	/*响应时间*/
	private String respWaitingTime;
	
	/**/
	private Date createTime;
	
	/**/
	private String createUser;
	
	/**/
	private Date updateTime;
	
	/**/
	private String updateUser;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getApplyNo(){
		return applyNo;
	}
	
	public void setApplyNo(String applyNo){
		this.applyNo = applyNo;
	}
	
	public String getReqNo(){
		return reqNo;
	}
	
	public void setReqNo(String reqNo){
		this.reqNo = reqNo;
	}
	
	public String getModule(){
		return module;
	}
	
	public void setModule(String module){
		this.module = module;
	}
	
	public String getMethod(){
		return method;
	}
	
	public void setMethod(String method){
		this.method = method;
	}
	
	public String getRequestMethod(){
		return requestMethod;
	}
	
	public void setRequestMethod(String requestMethod){
		this.requestMethod = requestMethod;
	}
	
	public Integer getIsInternal(){
		return isInternal;
	}
	
	public void setIsInternal(Integer isInternal){
		this.isInternal = isInternal;
	}
	
	public String getReqIp(){
		return reqIp;
	}
	
	public void setReqIp(String reqIp){
		this.reqIp = reqIp;
	}
	
	public String getReqUrl(){
		return reqUrl;
	}
	
	public void setReqUrl(String reqUrl){
		this.reqUrl = reqUrl;
	}
	
	public String getReqParam(){
		return reqParam;
	}
	
	public void setReqParam(String reqParam){
		this.reqParam = reqParam;
	}
	
	public String getRespContent(){
		return respContent;
	}
	
	public void setRespContent(String respContent){
		this.respContent = respContent;
	}
	
	public String getRespCode(){
		return respCode;
	}
	
	public void setRespCode(String respCode){
		this.respCode = respCode;
	}
	
	public String getRespWaitingTime(){
		return respWaitingTime;
	}
	
	public void setRespWaitingTime(String respWaitingTime){
		this.respWaitingTime = respWaitingTime;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public String getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(String createUser){
		this.createUser = createUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	public String getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(String updateUser){
		this.updateUser = updateUser;
	}
	
	
}
