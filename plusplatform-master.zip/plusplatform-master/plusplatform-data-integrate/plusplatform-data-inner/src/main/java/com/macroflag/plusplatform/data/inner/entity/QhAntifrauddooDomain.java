package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

import com.macroflag.plusplatform.encryption.annotation.EnDomain;
import com.macroflag.plusplatform.encryption.annotation.EnField;

/**
 * 好信欺诈度数据表的domain
 * @author : fredia
 * @since : 2018年04月24日
 * @version : v0.0.1
 */
@EnDomain
public class QhAntifrauddooDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*手机号码*/
	@EnField
	private String mobileNo;
	
	/*ip地址*/
	private String ip;
	
	/*序列号*/
	private String seqNo;
	
	/*命中暴力破解*/
	private String isMachdForce;
	
	/*命中dns服务器*/
	private String isMachdDns;
	
	/*命中邮件服务器*/
	private String isMachdMailServ;
	
	/*命中seo*/
	private String isMachdSeo;
	
	/*命中组织出口*/
	private String isMachdOrg;
	
	/*命中爬虫*/
	private String isMachdCrawler;
	
	/*命中代理服务器*/
	private String isMachdProxy;
	
	/*命中第三方标注黑名单*/
	private String isMachdBlacklist;
	
	/*命中web服务器*/
	private String isMachdWebServ;
	
	/*命中vpn服务器*/
	private String isMachdVpn;
	
	/*风险评分*/
	private String rskScore;
	
	/*ip风险时间*/
	private String iUpdateDate;
	
	/*命中第三方标注黑名单*/
	private String isMachdBlMakt;
	
	/*命中骚扰电话*/
	private String isMachCraCall;
	
	/*命中欺诈号码*/
	private String isMachFraud;
	
	/*命中空号（非正常短信语音号码）*/
	private String isMachEmpty;
	
	/*命中收码平台号码*/
	private String isMachYZMobile;
	
	/*命中小号*/
	private String isMachSmallNo;
	
	/*命中社工库号码*/
	private String isMachSZNo;
	
	/*手机号码风险时间*/
	private String mUpdateDate;
	
	/*ip风险描述*/
	private String iRskDesc;
	
	/*手机号码风险描述*/
	private String mRskDesc;
	
	/*不良信息描述*/
	private String badInfoDesc;
	
	/*不良信息发生时间*/
	private String badInfoTime;
	
	/*错误代码*/
	private String erCode;
	
	/*错误信息*/
	private String erMsg;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getMobileNo(){
		return mobileNo;
	}
	
	public void setMobileNo(String mobileNo){
		this.mobileNo = mobileNo;
	}
	
	public String getIp(){
		return ip;
	}
	
	public void setIp(String ip){
		this.ip = ip;
	}
	
	public String getSeqNo(){
		return seqNo;
	}
	
	public void setSeqNo(String seqNo){
		this.seqNo = seqNo;
	}
	
	public String getIsMachdForce(){
		return isMachdForce;
	}
	
	public void setIsMachdForce(String isMachdForce){
		this.isMachdForce = isMachdForce;
	}
	
	public String getIsMachdDns(){
		return isMachdDns;
	}
	
	public void setIsMachdDns(String isMachdDns){
		this.isMachdDns = isMachdDns;
	}
	
	public String getIsMachdMailServ(){
		return isMachdMailServ;
	}
	
	public void setIsMachdMailServ(String isMachdMailServ){
		this.isMachdMailServ = isMachdMailServ;
	}
	
	public String getIsMachdSeo(){
		return isMachdSeo;
	}
	
	public void setIsMachdSeo(String isMachdSeo){
		this.isMachdSeo = isMachdSeo;
	}
	
	public String getIsMachdOrg(){
		return isMachdOrg;
	}
	
	public void setIsMachdOrg(String isMachdOrg){
		this.isMachdOrg = isMachdOrg;
	}
	
	public String getIsMachdCrawler(){
		return isMachdCrawler;
	}
	
	public void setIsMachdCrawler(String isMachdCrawler){
		this.isMachdCrawler = isMachdCrawler;
	}
	
	public String getIsMachdProxy(){
		return isMachdProxy;
	}
	
	public void setIsMachdProxy(String isMachdProxy){
		this.isMachdProxy = isMachdProxy;
	}
	
	public String getIsMachdBlacklist(){
		return isMachdBlacklist;
	}
	
	public void setIsMachdBlacklist(String isMachdBlacklist){
		this.isMachdBlacklist = isMachdBlacklist;
	}
	
	public String getIsMachdWebServ(){
		return isMachdWebServ;
	}
	
	public void setIsMachdWebServ(String isMachdWebServ){
		this.isMachdWebServ = isMachdWebServ;
	}
	
	public String getIsMachdVpn(){
		return isMachdVpn;
	}
	
	public void setIsMachdVpn(String isMachdVpn){
		this.isMachdVpn = isMachdVpn;
	}
	
	public String getRskScore(){
		return rskScore;
	}
	
	public void setRskScore(String rskScore){
		this.rskScore = rskScore;
	}
	
	public String getiUpdateDate(){
		return iUpdateDate;
	}
	
	public void setiUpdateDate(String iUpdateDate){
		this.iUpdateDate = iUpdateDate;
	}
	
	public String getIsMachdBlMakt(){
		return isMachdBlMakt;
	}
	
	public void setIsMachdBlMakt(String isMachdBlMakt){
		this.isMachdBlMakt = isMachdBlMakt;
	}
	
	public String getIsMachCraCall(){
		return isMachCraCall;
	}
	
	public void setIsMachCraCall(String isMachCraCall){
		this.isMachCraCall = isMachCraCall;
	}
	
	public String getIsMachFraud(){
		return isMachFraud;
	}
	
	public void setIsMachFraud(String isMachFraud){
		this.isMachFraud = isMachFraud;
	}
	
	public String getIsMachEmpty(){
		return isMachEmpty;
	}
	
	public void setIsMachEmpty(String isMachEmpty){
		this.isMachEmpty = isMachEmpty;
	}
	
	public String getIsMachYZMobile(){
		return isMachYZMobile;
	}
	
	public void setIsMachYZMobile(String isMachYZMobile){
		this.isMachYZMobile = isMachYZMobile;
	}
	
	public String getIsMachSmallNo(){
		return isMachSmallNo;
	}
	
	public void setIsMachSmallNo(String isMachSmallNo){
		this.isMachSmallNo = isMachSmallNo;
	}
	
	public String getIsMachSZNo(){
		return isMachSZNo;
	}
	
	public void setIsMachSZNo(String isMachSZNo){
		this.isMachSZNo = isMachSZNo;
	}
	
	public String getmUpdateDate(){
		return mUpdateDate;
	}
	
	public void setmUpdateDate(String mUpdateDate){
		this.mUpdateDate = mUpdateDate;
	}
	
	public String getiRskDesc(){
		return iRskDesc;
	}
	
	public void setiRskDesc(String iRskDesc){
		this.iRskDesc = iRskDesc;
	}
	
	public String getmRskDesc(){
		return mRskDesc;
	}
	
	public void setmRskDesc(String mRskDesc){
		this.mRskDesc = mRskDesc;
	}
	
	public String getBadInfoDesc(){
		return badInfoDesc;
	}
	
	public void setBadInfoDesc(String badInfoDesc){
		this.badInfoDesc = badInfoDesc;
	}
	
	public String getBadInfoTime(){
		return badInfoTime;
	}
	
	public void setBadInfoTime(String badInfoTime){
		this.badInfoTime = badInfoTime;
	}
	
	public String getErCode(){
		return erCode;
	}
	
	public void setErCode(String erCode){
		this.erCode = erCode;
	}
	
	public String getErMsg(){
		return erMsg;
	}
	
	public void setErMsg(String erMsg){
		this.erMsg = erMsg;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
