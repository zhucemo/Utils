package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateQcMapping;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateQcMappingMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-11-07 17:47:15
 * @version : v1.0.0
 */
@Service
public class MfNetgateQcMappingBiz extends BusinessBiz<MfNetgateQcMappingMapper,MfNetgateQcMapping> {
}