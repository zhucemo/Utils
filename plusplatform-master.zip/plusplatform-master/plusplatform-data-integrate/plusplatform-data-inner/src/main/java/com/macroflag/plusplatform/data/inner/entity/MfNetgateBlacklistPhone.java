package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

import com.macroflag.plusplatform.encryption.annotation.EnDomain;
import com.macroflag.plusplatform.encryption.annotation.EnField;


/**
 * 手机黑名单
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-08-02 19:58:12
 * @version : v1.0.0
 */
@EnDomain
@Table(name = "mf_netgate_blacklist_phone")
public class MfNetgateBlacklistPhone implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Long id;
	
	    //手机号
    @EnField
    @Column(name = "key_val")
    private String keyVal;
	
	    //键值类型:1.本人 2.联系人
    @Column(name = "key_val_type")
    private Integer keyValType;
	
	    //
    @Column(name = "black_type")
    private String blackType;
	
	    //黑名单来源
    @Column(name = "black_source")
    private String blackSource;
	
	    //
    @Column(name = "relevance_case")
    private String relevanceCase;
	
	    //状态:1.启用 0.停用
    @Column(name = "status")
    private Integer status;
	
	    //备注
    @Column(name = "remark")
    private String remark;
	
	    //生效日期
    @Column(name = "effective_date")
    private Date effectiveDate;
	
	    //失效日期
    @Column(name = "expiry_date")
    private Date expiryDate;
	
	    //创建时间
    @Column(name = "create_time")
    private Date createTime;
	
	    //创建人
    @Column(name = "create_user")
    private String createUser;
	
	    //更新日期
    @Column(name = "update_time")
    private Date updateTime;
	
	    //更新用户
    @Column(name = "update_user")
    private String updateUser;
	

	/**
	 * 设置：主键
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：键值
	 */
	public void setKeyVal(String keyVal) {
		this.keyVal = keyVal;
	}
	/**
	 * 获取：键值
	 */
	public String getKeyVal() {
		return keyVal;
	}
	/**
	 * 设置：键值类型:1.本人 2.联系人
	 */
	public void setKeyValType(Integer keyValType) {
		this.keyValType = keyValType;
	}
	/**
	 * 获取：键值类型:1.本人 2.联系人
	 */
	public Integer getKeyValType() {
		return keyValType;
	}
	/**
	 * 设置：
	 */
	public void setBlackType(String blackType) {
		this.blackType = blackType;
	}
	/**
	 * 获取：
	 */
	public String getBlackType() {
		return blackType;
	}
	/**
	 * 设置：黑名单来源
	 */
	public void setBlackSource(String blackSource) {
		this.blackSource = blackSource;
	}
	/**
	 * 获取：黑名单来源
	 */
	public String getBlackSource() {
		return blackSource;
	}
	/**
	 * 设置：
	 */
	public void setRelevanceCase(String relevanceCase) {
		this.relevanceCase = relevanceCase;
	}
	/**
	 * 获取：
	 */
	public String getRelevanceCase() {
		return relevanceCase;
	}
	/**
	 * 设置：状态:1.启用 0.停用
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}
	/**
	 * 获取：状态:1.启用 0.停用
	 */
	public Integer getStatus() {
		return status;
	}
	/**
	 * 设置：备注
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	/**
	 * 获取：备注
	 */
	public String getRemark() {
		return remark;
	}
	/**
	 * 设置：生效日期
	 */
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	/**
	 * 获取：生效日期
	 */
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	/**
	 * 设置：失效日期
	 */
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	/**
	 * 获取：失效日期
	 */
	public Date getExpiryDate() {
		return expiryDate;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：创建人
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：创建人
	 */
	public String getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：更新日期
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新日期
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public String getUpdateUser() {
		return updateUser;
	}
}
