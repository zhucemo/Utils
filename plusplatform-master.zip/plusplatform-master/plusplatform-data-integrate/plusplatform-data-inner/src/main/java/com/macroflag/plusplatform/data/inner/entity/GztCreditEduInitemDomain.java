package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 算话规则输入项的domain
 * @author : huangf
 * @since : 2018年04月25日
 * @version : v0.0.1
 */
public class GztCreditEduInitemDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键id*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*算话在网时长*/
	private String zwDuration;
	
	/*算话司法案例信息条数*/
	private Integer alCount;
	
	/*算话司法执行信息条数*/
	private Integer zxCount;
	
	/*算话司法失信信息条数*/
	private Integer sxCount;
	
	/*算话网贷逾期信息条数*/
	private Integer wdyqCount;
	
	/*算话裁判文书条数*/
	private Integer cpwsCount;
	
	/*算话开庭公告条数*/
	private Integer ktggCount;
	
	/*算话案件流程条数*/
	private Integer ajlcCount;
	
	/*算话不良信息评分*/
	private Integer buliangScore;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getZwDuration(){
		return zwDuration;
	}
	
	public void setZwDuration(String zwDuration){
		this.zwDuration = zwDuration;
	}
	
	public Integer getAlCount(){
		return alCount;
	}
	
	public void setAlCount(Integer alCount){
		this.alCount = alCount;
	}
	
	public Integer getZxCount(){
		return zxCount;
	}
	
	public void setZxCount(Integer zxCount){
		this.zxCount = zxCount;
	}
	
	public Integer getSxCount(){
		return sxCount;
	}
	
	public void setSxCount(Integer sxCount){
		this.sxCount = sxCount;
	}
	
	public Integer getWdyqCount(){
		return wdyqCount;
	}
	
	public void setWdyqCount(Integer wdyqCount){
		this.wdyqCount = wdyqCount;
	}
	
	public Integer getCpwsCount(){
		return cpwsCount;
	}
	
	public void setCpwsCount(Integer cpwsCount){
		this.cpwsCount = cpwsCount;
	}
	
	public Integer getKtggCount(){
		return ktggCount;
	}
	
	public void setKtggCount(Integer ktggCount){
		this.ktggCount = ktggCount;
	}
	
	public Integer getAjlcCount(){
		return ajlcCount;
	}
	
	public void setAjlcCount(Integer ajlcCount){
		this.ajlcCount = ajlcCount;
	}
	
	public Integer getBuliangScore(){
		return buliangScore;
	}
	
	public void setBuliangScore(Integer buliangScore){
		this.buliangScore = buliangScore;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
