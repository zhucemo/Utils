package com.macroflag.plusplatform.data.inner.biz;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateBlacklistIdcard;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateBlacklistIdcardMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 身份证黑名单
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-08-02 19:58:12
 * @version : v1.0.0
 */
@Service
public class MfNetgateBlacklistIdcardBiz extends BusinessBiz<MfNetgateBlacklistIdcardMapper,MfNetgateBlacklistIdcard> {

	@Autowired
	private MfNetgateBlacklistIdcardMapper mfNetgateBlacklistIdcardMapper;
	
	
	public Map<String, Object> selectBlByIdcard(String idCardVal) {
		Map<String, Object> map = mfNetgateBlacklistIdcardMapper.selectBlByIdcard(idCardVal);
		return map;
	}


	public void updateByIdcard(MfNetgateBlacklistIdcard mfNetgateBlacklistIdcard) {
		
		MfNetgateBlacklistIdcard entity = new MfNetgateBlacklistIdcard();
		entity.setKeyVal(mfNetgateBlacklistIdcard.getKeyVal());
		MfNetgateBlacklistIdcard netgateBlacklistIdcard = mfNetgateBlacklistIdcardMapper.selectOne(entity);
		mfNetgateBlacklistIdcard.setId(netgateBlacklistIdcard.getId());
		mfNetgateBlacklistIdcardMapper.updateByPrimaryKey(mfNetgateBlacklistIdcard);
	}
}