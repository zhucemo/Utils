package com.macroflag.plusplatform.data.inner.controller.base;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.macroflag.plusplatform.data.inner.biz.MfNetgateAcctBiz;
import com.macroflag.plusplatform.data.inner.dictionary.service.IParamsDictionaryService;
import com.macroflag.plusplatform.data.inner.entity.MfNetgateAcct;
import com.macroflag.plusplatform.data.inner.entity.ParamsDictionaryDomain;
import com.macroflag.plusplatform.data.inner.query.ParamsDictionaryQuery;
import com.macroflag.plusplatform.data.inner.thirdpart.model.UserDataModel;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.macroflag.plusplatform.common.component.SysConfigCache;
import com.macroflag.plusplatform.common.exception.ExceptionUtils;
import com.macroflag.plusplatform.common.util.BeanUtils;
import com.macroflag.plusplatform.common.web.BaseController;

/**
 * 网关基类controller
 * 
 * @author : Fredia
 * @since : 2018年4月13日
 * @version : v1.0.0
 */
public class BaseNetgateController extends BaseController {
	@Autowired
	private IParamsDictionaryService paramsDictionaryService;
	@Autowired
    private MfNetgateAcctBiz mfNetgateAcctBiz;

	private static final String status = BeanUtils.getBean(SysConfigCache.class).getSysConfig("mf.apply.validate");
	
	
	/**
	 * 构建用户数据模型
	 * 
	 * @param userDataModel
	 * @author : Fredia
	 * @since : 2018年5月9日
	 * @return :void
	 */
	protected void buildData(UserDataModel userDataModel) {
		if (status.equalsIgnoreCase("false")) {
			return;
		} else {

			beanValidator(userDataModel);
			logger.info("#########开始构建用户数据模型#########");
			MfNetgateAcct entity = new MfNetgateAcct();
			entity.setApplyNo(userDataModel.getBusinessKey());
			List<MfNetgateAcct> mfNetgateAcct = mfNetgateAcctBiz.selectList(entity);
			//根据申请号查询该客户最新的第三方数据唯一标识号
			if (mfNetgateAcct.size()>0) {
				userDataModel.setUniqueNo(mfNetgateAcct.get(0).getUniqueNo());
				userDataModel.setName(mfNetgateAcct.get(0).getUserName());
				userDataModel.setDocumentno(mfNetgateAcct.get(0).getIdCard());
				userDataModel.setPhone(mfNetgateAcct.get(0).getPhone());
				userDataModel.setProCode(mfNetgateAcct.get(0).getProductNo());
			} else {
				ExceptionUtils.throwBaseException(500, "########未查到该客户第三方数据唯一标识号########");
			}
		}

	}

	/**
	 * 英文属性转中文
	 * 
	 * @param jo
	 * @author : Fredia
	 * @since : 2018年5月9日
	 * @return :void
	 */
	protected JSONObject convertEn2Cn(JSONObject jo, String api) {
		Map<String, Object> map = jo;
		logger.info("#########开始英文转中文#########");
		ParamsDictionaryQuery paramsDictionaryQuery = new ParamsDictionaryQuery();
		paramsDictionaryQuery.setStatus("1");
		paramsDictionaryQuery.setModule(api);
		paramsDictionaryQuery.setType("1");
		List<ParamsDictionaryDomain> list = paramsDictionaryService.getList(paramsDictionaryQuery);
		Map<Object, Object> map1 = new HashMap<Object, Object>();
		// 1.list转map
		Map<String, String> dictionary = list.stream()
				.collect(Collectors.toMap(ParamsDictionaryDomain::getEnName, ParamsDictionaryDomain::getCnName));
		// 2. 遍历map,用value替换掉key
		map.forEach((k, v) -> {
			if (dictionary.get(k) != null) {
				map1.put(dictionary.get(k), v);
			}
		});
		JSONObject json = JSONObject.parseObject(JSON.toJSONString(map1));
		return json;

	}

}
