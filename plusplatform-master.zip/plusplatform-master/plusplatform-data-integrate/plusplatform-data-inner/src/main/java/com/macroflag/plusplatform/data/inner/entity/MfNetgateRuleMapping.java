package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-31 20:08:06
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_rule_mapping")
public class MfNetgateRuleMapping implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Long id;
	
	    //策略分支码
    @Column(name = "strategy_code")
    private String strategyCode;
	
	    //拒绝原因码
    @Column(name = "decline_code")
    private String declineCode;
	
	    //优先级
    @Column(name = "priority")
    private Integer priority;
	
	    //策略分数
    @Column(name = "score")
    private Integer score;
	

	/**
	 * 设置：主键
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：策略分支码
	 */
	public void setStrategyCode(String strategyCode) {
		this.strategyCode = strategyCode;
	}
	/**
	 * 获取：策略分支码
	 */
	public String getStrategyCode() {
		return strategyCode;
	}
	/**
	 * 设置：拒绝原因码
	 */
	public void setDeclineCode(String declineCode) {
		this.declineCode = declineCode;
	}
	/**
	 * 获取：拒绝原因码
	 */
	public String getDeclineCode() {
		return declineCode;
	}
	/**
	 * 设置：优先级
	 */
	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	/**
	 * 获取：优先级
	 */
	public Integer getPriority() {
		return priority;
	}
	/**
	 * 设置：策略分数
	 */
	public void setScore(Integer score) {
		this.score = score;
	}
	/**
	 * 获取：策略分数
	 */
	public Integer getScore() {
		return score;
	}
}
