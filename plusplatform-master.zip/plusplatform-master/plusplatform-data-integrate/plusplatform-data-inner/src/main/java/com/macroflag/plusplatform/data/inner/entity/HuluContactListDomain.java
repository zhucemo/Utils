package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

import com.macroflag.plusplatform.encryption.annotation.EnDomain;
import com.macroflag.plusplatform.encryption.annotation.EnField;

/**
 * 葫芦运营商通话详情的domain
 * @author : huangf
 * @since : 2018年04月19日
 * @version : v0.0.1
 */
@EnDomain
public class HuluContactListDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*号码*/
	@EnField
	private String phoneNum;
	
	/*号码归属地*/
	private String phoneNumLoc;
	
	/*号码标注*/
	private String contactName;
	
	/*需求类别*/
	private String needsType;
	
	/*通话次数*/
	private Integer callCnt;
	
	/*通话时长*/
	private Float callLen;
	
	/*呼出次数*/
	private Integer callOutCnt;
	
	/*呼入次数*/
	private Integer callInCnt;
	
	/*呼入时间*/
	private Float callInLen;
	
	/*呼出时间*/
	private Float callOutLen;
	
	/*关系推测*/
	private String pRelation;
	
	/*最近一周联系次数*/
	private Integer contact1w;
	
	/*最近一月联系次数*/
	private Integer contact1m;
	
	/*最近三月联系次数*/
	private Integer contact3m;
	
	/*三个月以上联系次数*/
	private Integer contact3mPlus;
	
	/*凌晨联系次数*/
	private Integer contactEarlyMorning;
	
	/*上午联系次数*/
	private Integer contactMorning;
	
	/*中午联系次数*/
	private Integer contactNoon;
	
	/*下午联系次数*/
	private Integer contactAfternoon;
	
	/*晚上联系次数*/
	private Integer contactNight;
	
	/*是否全天联系*/
	private String contactAllDay;
	
	/*周中联系次数*/
	private Integer contactWeekday;
	
	/*周末联系次数*/
	private Integer contactWeekend;
	
	/*节假日联系次数*/
	private Integer contactHoliday;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long creatUser;
	
	/*创建时间*/
	private Date creatTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getPhoneNum(){
		return phoneNum;
	}
	
	public void setPhoneNum(String phoneNum){
		this.phoneNum = phoneNum;
	}
	
	public String getPhoneNumLoc(){
		return phoneNumLoc;
	}
	
	public void setPhoneNumLoc(String phoneNumLoc){
		this.phoneNumLoc = phoneNumLoc;
	}
	
	public String getContactName(){
		return contactName;
	}
	
	public void setContactName(String contactName){
		this.contactName = contactName;
	}
	
	public String getNeedsType(){
		return needsType;
	}
	
	public void setNeedsType(String needsType){
		this.needsType = needsType;
	}
	
	public Integer getCallCnt(){
		return callCnt;
	}
	
	public void setCallCnt(Integer callCnt){
		this.callCnt = callCnt;
	}
	
	public Float getCallLen(){
		return callLen;
	}
	
	public void setCallLen(Float callLen){
		this.callLen = callLen;
	}
	
	public Integer getCallOutCnt(){
		return callOutCnt;
	}
	
	public void setCallOutCnt(Integer callOutCnt){
		this.callOutCnt = callOutCnt;
	}
	
	public Integer getCallInCnt(){
		return callInCnt;
	}
	
	public void setCallInCnt(Integer callInCnt){
		this.callInCnt = callInCnt;
	}
	
	public Float getCallInLen(){
		return callInLen;
	}
	
	public void setCallInLen(Float callInLen){
		this.callInLen = callInLen;
	}
	
	public Float getCallOutLen(){
		return callOutLen;
	}
	
	public void setCallOutLen(Float callOutLen){
		this.callOutLen = callOutLen;
	}
	
	public String getpRelation(){
		return pRelation;
	}
	
	public void setpRelation(String pRelation){
		this.pRelation = pRelation;
	}
	
	public Integer getContact1w(){
		return contact1w;
	}
	
	public void setContact1w(Integer contact1w){
		this.contact1w = contact1w;
	}
	
	public Integer getContact1m(){
		return contact1m;
	}
	
	public void setContact1m(Integer contact1m){
		this.contact1m = contact1m;
	}
	
	public Integer getContact3m(){
		return contact3m;
	}
	
	public void setContact3m(Integer contact3m){
		this.contact3m = contact3m;
	}
	
	public Integer getContact3mPlus(){
		return contact3mPlus;
	}
	
	public void setContact3mPlus(Integer contact3mPlus){
		this.contact3mPlus = contact3mPlus;
	}
	
	public Integer getContactEarlyMorning(){
		return contactEarlyMorning;
	}
	
	public void setContactEarlyMorning(Integer contactEarlyMorning){
		this.contactEarlyMorning = contactEarlyMorning;
	}
	
	public Integer getContactMorning(){
		return contactMorning;
	}
	
	public void setContactMorning(Integer contactMorning){
		this.contactMorning = contactMorning;
	}
	
	public Integer getContactNoon(){
		return contactNoon;
	}
	
	public void setContactNoon(Integer contactNoon){
		this.contactNoon = contactNoon;
	}
	
	public Integer getContactAfternoon(){
		return contactAfternoon;
	}
	
	public void setContactAfternoon(Integer contactAfternoon){
		this.contactAfternoon = contactAfternoon;
	}
	
	public Integer getContactNight(){
		return contactNight;
	}
	
	public void setContactNight(Integer contactNight){
		this.contactNight = contactNight;
	}
	
	public String getContactAllDay(){
		return contactAllDay;
	}
	
	public void setContactAllDay(String contactAllDay){
		this.contactAllDay = contactAllDay;
	}
	
	public Integer getContactWeekday(){
		return contactWeekday;
	}
	
	public void setContactWeekday(Integer contactWeekday){
		this.contactWeekday = contactWeekday;
	}
	
	public Integer getContactWeekend(){
		return contactWeekend;
	}
	
	public void setContactWeekend(Integer contactWeekend){
		this.contactWeekend = contactWeekend;
	}
	
	public Integer getContactHoliday(){
		return contactHoliday;
	}
	
	public void setContactHoliday(Integer contactHoliday){
		this.contactHoliday = contactHoliday;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreatUser(){
		return creatUser;
	}
	
	public void setCreatUser(Long creatUser){
		this.creatUser = creatUser;
	}
	
	public Date getCreatTime(){
		return creatTime;
	}
	
	public void setCreatTime(Date creatTime){
		this.creatTime = creatTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
