package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-08-02 18:55:44
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_cp_mapping")
public class MfNetgateCpMapping implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Long id;
	
	    //分类
    @Column(name = "category")
    private String category;
	
	    //优先级
    @Column(name = "priority")
    private String priority;
	
	    //黑名单类型
    @Column(name = "black_type")
    private String blackType;
	
	    //降级分类
    @Column(name = "degrade_cat")
    private String degradeCat;
	
	    //
    @Column(name = "create_time")
    private Date createTime;
	
	    //
    @Column(name = "create_user")
    private String createUser;
	
	    //
    @Column(name = "update_time")
    private Date updateTime;
	
	    //
    @Column(name = "update_user")
    private String updateUser;
	

	/**
	 * 设置：主键
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：分类
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	/**
	 * 获取：分类
	 */
	public String getCategory() {
		return category;
	}
	/**
	 * 设置：优先级
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}
	/**
	 * 获取：优先级
	 */
	public String getPriority() {
		return priority;
	}
	/**
	 * 设置：黑名单类型
	 */
	public void setBlackType(String blackType) {
		this.blackType = blackType;
	}
	/**
	 * 获取：黑名单类型
	 */
	public String getBlackType() {
		return blackType;
	}
	/**
	 * 设置：降级分类
	 */
	public void setDegradeCat(String degradeCat) {
		this.degradeCat = degradeCat;
	}
	/**
	 * 获取：降级分类
	 */
	public String getDegradeCat() {
		return degradeCat;
	}
	/**
	 * 设置：
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：
	 */
	public String getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
	/**
	 * 设置：
	 */
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：
	 */
	public String getUpdateUser() {
		return updateUser;
	}
}
