package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgatePpxinTax;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgatePpxinTaxMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-19 10:55:24
 * @version : v1.0.0
 */
@Service
public class MfNetgatePpxinTaxBiz extends BusinessBiz<MfNetgatePpxinTaxMapper,MfNetgatePpxinTax> {
}