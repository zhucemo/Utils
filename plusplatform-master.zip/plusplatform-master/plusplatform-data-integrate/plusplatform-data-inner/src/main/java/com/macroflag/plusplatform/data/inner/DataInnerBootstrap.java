
package com.macroflag.plusplatform.data.inner;

import com.macroflag.plusplatform.cache.EnableFeCache;
import com.macroflag.plusplatform.encryption.annotation.EnableSuEncry;
import com.macroflag.plusplatform.merge.EnableFeMerge;
import com.spring4all.swagger.EnableSwagger2Doc;
import io.prometheus.client.spring.boot.EnablePrometheusEndpoint;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnablePrometheusEndpoint
@EnableEurekaClient
@EnableCircuitBreaker
@SpringBootApplication
@EnableFeignClients({"com.macroflag.plusplatform.data.inner.feign"})
@EnableFeCache
@EnableTransactionManagement
@MapperScan({"com.macroflag.plusplatform.data.inner.mapper", "com.macroflag.plusplatform.common.mapper.nongeneric"})
@EnableSwagger2Doc
@EnableFeMerge
@EnableSuEncry
@ComponentScan({"com.macroflag.plusplatform.common", "com.macroflag.plusplatform.data"})
@Component
public class DataInnerBootstrap {


    public static void main(String[] args) {
        new SpringApplicationBuilder(DataInnerBootstrap.class).web(true).run(args);
    }
}
