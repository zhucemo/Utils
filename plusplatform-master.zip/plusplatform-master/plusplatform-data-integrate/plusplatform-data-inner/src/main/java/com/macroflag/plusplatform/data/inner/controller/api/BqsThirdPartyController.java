package com.macroflag.plusplatform.data.inner.controller.api;


import com.macroflag.plusplatform.common.annotations.SystemLog;
import com.macroflag.plusplatform.common.exception.BaseException;
import com.macroflag.plusplatform.common.exception.ExceptionUtils;
import com.macroflag.plusplatform.data.inner.config.service.IApiConfigService;
import com.macroflag.plusplatform.data.inner.controller.base.BaseNetgateController;
import com.macroflag.plusplatform.data.inner.entity.ApiConfigDomain;
import com.macroflag.plusplatform.data.inner.entity.BqsResultDomain;
import com.macroflag.plusplatform.data.inner.query.BqsResultQuery;
import com.macroflag.plusplatform.data.inner.thirdpart.component.IBqsThirdPartyService;
import com.macroflag.plusplatform.data.inner.thirdpart.model.UserDataModel;
import com.macroflag.plusplatform.data.inner.thirdpart.service.IBqsResultService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.wordnik.swagger.annotations.ApiParam;

/**
 * 白骑士controller
 * 
 * @author huangf
 *
 */
@Scope(value = "prototype")
@RestController
@RequestMapping("/bqs")
public class BqsThirdPartyController extends BaseNetgateController {

	@Autowired
	private IBqsThirdPartyService bqsThirdPartyService;
	@Autowired
	private IApiConfigService apiConfigService;
	@Autowired
	private IBqsResultService bqsResultService;
	
	@RequestMapping(value = "getRiskListInfo", method = RequestMethod.GET)
	@SystemLog(module = "api", methods = "白骑士风险名单接口", requestMethod = RequestMethod.GET)
	public Object getRiskListInfo(@ApiParam(value = "手机号") @RequestParam(required = false) String phone,
			@ApiParam(value = "姓名") @RequestParam(required = false) String name,
			@ApiParam(value = "身份证") @RequestParam(required = false) String documentno,
			@ApiParam(value = "业务主键") @RequestParam(required = true) String businessKey) {
		logger.info("#########进入白骑士风险名单接口,申请编号为{}#########",businessKey);
		UserDataModel userDataModel = new UserDataModel();
		userDataModel.setBusinessKey(businessKey);
		userDataModel.setDocumentno(documentno);
		userDataModel.setName(name);
		userDataModel.setPhone(phone);
		// 构建数据模型
		buildData(userDataModel);
		JSONObject result = null;
		// API 检测
		logger.info("#########开始验证API数据模型#########");
		ApiConfigDomain apiConfigDomain = apiConfigService.getApiConfig("bqs");
		if (apiConfigDomain == null) {
			logger.error("###该接口配置不存在###");
            throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), "###该接口配置不存在###");
		}
		int status = apiConfigDomain.getStatus();
		JSONObject jo = null;
		if (0 == status) {
			logger.error("###该接口已关闭###");
			ExceptionUtils.throwBaseException("###该接口已关闭###");
		} else if (2 == status) {
			logger.info("###自定义空数据模板###");
			String content = apiConfigDomain.getFallbackContent();
			JSONObject json = JSONObject.parseObject(content);
			logger.info("#########返回数据模型为：{}#########",json);
			return json;

		} else if (1 == status) {
			
//			Long expire = apiConfigDomain.getDataLifeCycle();
			/* 1.外部数据:先查询是否存在该用户原始数据 */
			BqsResultQuery query = new BqsResultQuery();
			query.setUniqueNo(userDataModel.getUniqueNo());
			BqsResultDomain bqsResultDomain  = bqsResultService.getOne(query);

			if (bqsResultDomain == null) {
				bqsThirdPartyService.executeHttp(userDataModel);
				jo = bqsThirdPartyService.determin(userDataModel);
			} else {
				// 存在就直接提取数据
				jo = bqsThirdPartyService.determin(userDataModel);
			}
			logger.info("########原始数据模型：{}#########",jo);
			// 字典项转换
			try {
				result = convertEn2Cn(jo, "bqs");
			} catch (Exception e) {
				logger.error("####英文转中文异常####");
				ExceptionUtils.throwBaseException("####英文转中文异常####");
			}
			logger.info("#########返回数据模型为：{}#########",result);
			return result;

		}
		logger.error("###该接口配置错误###");
		logger.info("#########返回数据模型为：{}#########",result);
		ExceptionUtils.throwBaseException("###该接口配置错误###");
		return result;

	}
}
