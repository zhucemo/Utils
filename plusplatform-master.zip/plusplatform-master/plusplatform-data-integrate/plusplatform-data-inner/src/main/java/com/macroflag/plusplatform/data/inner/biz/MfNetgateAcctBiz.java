package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateAcct;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateAcctMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-08-01 11:29:12
 * @version : v1.0.0
 */
@Service
public class MfNetgateAcctBiz extends BusinessBiz<MfNetgateAcctMapper,MfNetgateAcct> {
}