package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;

import com.macroflag.plusplatform.encryption.annotation.EnDomain;
import com.macroflag.plusplatform.encryption.annotation.EnField;


/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-08-01 11:29:12
 * @version : v1.0.0
 */
@EnDomain
@Table(name = "mf_netgate_acct")
public class MfNetgateAcct implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Long id;
	
	    //用户三方数据唯一标识
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //申请编号
    @Column(name = "apply_no")
    private String applyNo;
	
	    //身份证
    @EnField
    @Column(name = "id_card")
    private String idCard;
	
	    //用户姓名
    @EnField
    @Column(name = "user_name")
    private String userName;
	
	    //手机号
    @EnField
    @Column(name = "phone")
    private String phone;
    
    	//产品号
    @Column(name = "product_no")
    private String productNo;
	
	    //预留字段1
    @Column(name = "spare1")
    private String spare1;
	
	    //预留字段2
    @Column(name = "spare2")
    private String spare2;
	
	    //预留字段3
    @Column(name = "spare3")
    private String spare3;
	
	    //预留字段4
    @Column(name = "spare4")
    private String spare4;
	
	    //创建用户
    @Column(name = "create_user")
    private String createUser;
	
	    //创建时间
    @Column(name = "create_time")
    @OrderBy("DESC")
    private Date createTime;
	
	    //更新用户
    @Column(name = "update_user")
    private String updateUser;
	
	    //更新时间
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：用户三方数据唯一标识
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：用户三方数据唯一标识
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：申请编号
	 */
	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}
	/**
	 * 获取：申请编号
	 */
	public String getApplyNo() {
		return applyNo;
	}
	/**
	 * 设置：身份证
	 */
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	/**
	 * 获取：身份证
	 */
	public String getIdCard() {
		return idCard;
	}
	/**
	 * 设置：用户姓名
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * 获取：用户姓名
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * 设置：手机号
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/**
	 * 获取：手机号
	 */
	public String getPhone() {
		return phone;
	}
	/**
	 * 获取：手机号
	 */
	public String getProductNo() {
		return productNo;
	}
	/**
	 * 设置：手机号
	 */
	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}
	/**
	 * 设置：预留字段1
	 */
	public void setSpare1(String spare1) {
		this.spare1 = spare1;
	}
	/**
	 * 获取：预留字段1
	 */
	public String getSpare1() {
		return spare1;
	}
	/**
	 * 设置：预留字段2
	 */
	public void setSpare2(String spare2) {
		this.spare2 = spare2;
	}
	/**
	 * 获取：预留字段2
	 */
	public String getSpare2() {
		return spare2;
	}
	/**
	 * 设置：预留字段3
	 */
	public void setSpare3(String spare3) {
		this.spare3 = spare3;
	}
	/**
	 * 获取：预留字段3
	 */
	public String getSpare3() {
		return spare3;
	}
	/**
	 * 设置：预留字段4
	 */
	public void setSpare4(String spare4) {
		this.spare4 = spare4;
	}
	/**
	 * 获取：预留字段4
	 */
	public String getSpare4() {
		return spare4;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：创建用户
	 */
	public String getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public String getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
}
