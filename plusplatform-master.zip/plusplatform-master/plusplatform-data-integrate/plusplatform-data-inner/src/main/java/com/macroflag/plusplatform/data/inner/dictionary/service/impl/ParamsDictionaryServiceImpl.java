package com.macroflag.plusplatform.data.inner.dictionary.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.macroflag.plusplatform.common.core.service.impl.BaseServiceImpl;
import com.macroflag.plusplatform.data.inner.entity.ParamsDictionaryDomain;
import com.macroflag.plusplatform.data.inner.mapper.ParamsDictionaryMapper;
import com.macroflag.plusplatform.data.inner.query.ParamsDictionaryQuery;
import com.macroflag.plusplatform.data.inner.dictionary.service.IParamsDictionaryService;

/**
 * 参数字典表的业务实现类
 * @author : Fredia
 * @since : 2018年05月05日
 * @version : v0.0.1
 */
@Service("paramsDictionaryService")
public class ParamsDictionaryServiceImpl extends BaseServiceImpl<ParamsDictionaryDomain> implements IParamsDictionaryService {
	private static Logger logger = LoggerFactory.getLogger(ParamsDictionaryServiceImpl.class);
	@Autowired
	private ParamsDictionaryMapper paramsDictionaryMapper;

	@Override
	public JSONObject convertCn2En(Map<String, Object> map,String module) {
//			Map<String, Object> map = jo;
			logger.info("#########开始中文转英文#########");
			ParamsDictionaryQuery paramsDictionaryQuery = new ParamsDictionaryQuery();
			paramsDictionaryQuery.setStatus("1");
			paramsDictionaryQuery.setModule(module);
			paramsDictionaryQuery.setType("0");
			List<ParamsDictionaryDomain> list = paramsDictionaryMapper.getList(paramsDictionaryQuery);
			Map<Object, Object> map1 = new HashMap<Object, Object>();
			// 1.list转map
			Map<String, String> dictionary = list.stream()
					.collect(Collectors.toMap(ParamsDictionaryDomain::getCnName, ParamsDictionaryDomain::getEnName));
			// 2. 遍历map,用value替换掉key
			map.forEach((k, v) -> {
				if (dictionary.get(k) != null) {
//					map.remove(k);
					map1.put(dictionary.get(k), v);
				}
			});
			JSONObject json = JSONObject.parseObject(JSON.toJSONString(map1));
			return json;

	}
	
}
