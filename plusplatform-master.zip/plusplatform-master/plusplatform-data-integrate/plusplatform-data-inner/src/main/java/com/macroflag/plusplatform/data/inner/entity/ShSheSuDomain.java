package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 算话涉诉风险汇总的domain
 * @author : huangf
 * @since : 2018年04月18日
 * @version : v0.0.1
 */
public class ShSheSuDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*数据状态*/
	private String status;
	
	/*裁判文书*/
	private Integer cpws;
	
	/*执行公告*/
	private Integer zxgg;
	
	/*失信公告*/
	private Integer sxgg;
	
	/*开庭公告*/
	private Integer ktgg;
	
	/*法院公告*/
	private Integer fygg;
	
	/*网贷黑名单*/
	private Integer wdhmd;
	
	/*案件流程信息*/
	private Integer ajlc;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getStatus(){
		return status;
	}
	
	public void setStatus(String status){
		this.status = status;
	}
	
	public Integer getCpws(){
		return cpws;
	}
	
	public void setCpws(Integer cpws){
		this.cpws = cpws;
	}
	
	public Integer getZxgg(){
		return zxgg;
	}
	
	public void setZxgg(Integer zxgg){
		this.zxgg = zxgg;
	}
	
	public Integer getSxgg(){
		return sxgg;
	}
	
	public void setSxgg(Integer sxgg){
		this.sxgg = sxgg;
	}
	
	public Integer getKtgg(){
		return ktgg;
	}
	
	public void setKtgg(Integer ktgg){
		this.ktgg = ktgg;
	}
	
	public Integer getFygg(){
		return fygg;
	}
	
	public void setFygg(Integer fygg){
		this.fygg = fygg;
	}
	
	public Integer getWdhmd(){
		return wdhmd;
	}
	
	public void setWdhmd(Integer wdhmd){
		this.wdhmd = wdhmd;
	}
	
	public Integer getAjlc(){
		return ajlc;
	}
	
	public void setAjlc(Integer ajlc){
		this.ajlc = ajlc;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
