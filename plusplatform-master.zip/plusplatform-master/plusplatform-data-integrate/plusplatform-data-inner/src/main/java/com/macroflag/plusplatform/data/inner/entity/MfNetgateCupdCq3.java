package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : Fredia
 * @email trumpey@163.com
 * @since : 2018-07-02 11:31:55
 * @version : v1.0.0
 */
@Table(name = "mf_netgate_cupd_cq3")
public class MfNetgateCupdCq3 implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //主键
    @Id
    private Long id;
	
	    //用户唯一标识
    @Column(name = "unique_no")
    private String uniqueNo;
	
	    //随机请求号
    @Column(name = "serial_number")
    private String serialNumber;
	
	    //CQ3发送报文
    @Column(name = "cq3_context")
    private String cq3Context;
	
	    //CQ3返回报文
    @Column(name = "cq3_return")
    private String cq3Return;
	
	    //拒绝原因码1
    @Column(name = "decline_code1")
    private String declineCode1;
	
	    //拒绝原因码2
    @Column(name = "decline_code2")
    private String declineCode2;
	
	    //拒绝原因码3
    @Column(name = "decline_code3")
    private String declineCode3;
	
	    //策略分支吗
    @Column(name = "rule_codes")
    private String ruleCodes;
	
	    //申请编号
    @Column(name = "apply_num")
    private String applyNum;
	
	    //CUPD返回码
    @Column(name = "state")
    private String state;
	
	    //QJ审批结果
    @Column(name = "result")
    private String result;
	
	    //创建用户
    @Column(name = "create_user")
    private String createUser;
	
	    //创建时间
    @Column(name = "create_time")
    private Date createTime;
	
	    //更新用户
    @Column(name = "update_user")
    private String updateUser;
	
	    //更新时间
    @Column(name = "update_time")
    private Date updateTime;
	

	/**
	 * 设置：主键
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：主键
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：用户唯一标识
	 */
	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	/**
	 * 获取：用户唯一标识
	 */
	public String getUniqueNo() {
		return uniqueNo;
	}
	/**
	 * 设置：随机请求号
	 */
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	/**
	 * 获取：随机请求号
	 */
	public String getSerialNumber() {
		return serialNumber;
	}
	/**
	 * 设置：CQ3发送报文
	 */
	public void setCq3Context(String cq3Context) {
		this.cq3Context = cq3Context;
	}
	/**
	 * 获取：CQ3发送报文
	 */
	public String getCq3Context() {
		return cq3Context;
	}
	/**
	 * 设置：CQ3返回报文
	 */
	public void setCq3Return(String cq3Return) {
		this.cq3Return = cq3Return;
	}
	/**
	 * 获取：CQ3返回报文
	 */
	public String getCq3Return() {
		return cq3Return;
	}
	/**
	 * 设置：拒绝原因码1
	 */
	public void setDeclineCode1(String declineCode1) {
		this.declineCode1 = declineCode1;
	}
	/**
	 * 获取：拒绝原因码1
	 */
	public String getDeclineCode1() {
		return declineCode1;
	}
	/**
	 * 设置：拒绝原因码2
	 */
	public void setDeclineCode2(String declineCode2) {
		this.declineCode2 = declineCode2;
	}
	/**
	 * 获取：拒绝原因码2
	 */
	public String getDeclineCode2() {
		return declineCode2;
	}
	/**
	 * 设置：拒绝原因码3
	 */
	public void setDeclineCode3(String declineCode3) {
		this.declineCode3 = declineCode3;
	}
	/**
	 * 获取：拒绝原因码3
	 */
	public String getDeclineCode3() {
		return declineCode3;
	}
	/**
	 * 设置：策略分支吗
	 */
	public void setRuleCodes(String ruleCodes) {
		this.ruleCodes = ruleCodes;
	}
	/**
	 * 获取：策略分支吗
	 */
	public String getRuleCodes() {
		return ruleCodes;
	}
	/**
	 * 设置：申请编号
	 */
	public void setApplyNum(String applyNum) {
		this.applyNum = applyNum;
	}
	/**
	 * 获取：申请编号
	 */
	public String getApplyNum() {
		return applyNum;
	}
	/**
	 * 设置：CUPD返回码
	 */
	public void setState(String state) {
		this.state = state;
	}
	/**
	 * 获取：CUPD返回码
	 */
	public String getState() {
		return state;
	}
	/**
	 * 设置：QJ审批结果
	 */
	public void setResult(String result) {
		this.result = result;
	}
	/**
	 * 获取：QJ审批结果
	 */
	public String getResult() {
		return result;
	}
	/**
	 * 设置：创建用户
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}
	/**
	 * 获取：创建用户
	 */
	public String getCreateUser() {
		return createUser;
	}
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() {
		return createTime;
	}
	/**
	 * 设置：更新用户
	 */
	public void setUpdateUser(String updateUser) {
		this.updateUser = updateUser;
	}
	/**
	 * 获取：更新用户
	 */
	public String getUpdateUser() {
		return updateUser;
	}
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() {
		return updateTime;
	}
}
