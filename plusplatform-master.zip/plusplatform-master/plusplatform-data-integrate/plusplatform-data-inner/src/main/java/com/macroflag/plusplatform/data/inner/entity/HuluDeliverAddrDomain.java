package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

import com.macroflag.plusplatform.encryption.annotation.EnDomain;
import com.macroflag.plusplatform.encryption.annotation.EnField;

/**
 * 葫芦电商地址记录的domain
 * @author : huangf
 * @since : 2018年04月18日
 * @version : v0.0.1
 */
@EnDomain
public class HuluDeliverAddrDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*收货地址*/
	@EnField
	private String address;
	
	/*经度*/
	private Float lng;
	
	/*纬度*/
	private Float lat;
	
	/*地址类型*/
	private String predictAddrType;
	
	/*开始送货时间*/
	private String beginDate;
	
	/*结束送货时间*/
	private String endDate;
	
	/*总送货金额*/
	private Float totalAmount;
	
	/*总送货次数*/
	private Integer totalCount;
	
	/*收货次数*/
	private Integer count;
	
	/*收货金额*/
	private Float amount;
	
	/*收货人名称*/
	@EnField
	private String consigneeName;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long createUser;
	
	/*创建时间*/
	private Date createTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getAddress(){
		return address;
	}
	
	public void setAddress(String address){
		this.address = address;
	}
	
	public Float getLng(){
		return lng;
	}
	
	public void setLng(Float lng){
		this.lng = lng;
	}
	
	public Float getLat(){
		return lat;
	}
	
	public void setLat(Float lat){
		this.lat = lat;
	}
	
	public String getPredictAddrType(){
		return predictAddrType;
	}
	
	public void setPredictAddrType(String predictAddrType){
		this.predictAddrType = predictAddrType;
	}
	
	public String getBeginDate(){
		return beginDate;
	}
	
	public void setBeginDate(String beginDate){
		this.beginDate = beginDate;
	}
	
	public String getEndDate(){
		return endDate;
	}
	
	public void setEndDate(String endDate){
		this.endDate = endDate;
	}
	
	public Float getTotalAmount(){
		return totalAmount;
	}
	
	public void setTotalAmount(Float totalAmount){
		this.totalAmount = totalAmount;
	}
	
	public Integer getTotalCount(){
		return totalCount;
	}
	
	public void setTotalCount(Integer totalCount){
		this.totalCount = totalCount;
	}
	
	public Integer getCount(){
		return count;
	}
	
	public void setCount(Integer count){
		this.count = count;
	}
	
	public Float getAmount(){
		return amount;
	}
	
	public void setAmount(Float amount){
		this.amount = amount;
	}
	
	public String getConsigneeName(){
		return consigneeName;
	}
	
	public void setConsigneeName(String consigneeName){
		this.consigneeName = consigneeName;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
