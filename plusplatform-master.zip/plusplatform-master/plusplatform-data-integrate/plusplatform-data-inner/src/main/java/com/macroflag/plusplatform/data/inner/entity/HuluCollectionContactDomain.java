package com.macroflag.plusplatform.data.inner.entity;

import java.io.Serializable;
import java.util.Date;

import com.macroflag.plusplatform.encryption.annotation.EnDomain;
import com.macroflag.plusplatform.encryption.annotation.EnField;

/**
 * 葫芦联系人名单的domain
 * @author : huangf
 * @since : 2018年04月18日
 * @version : v0.0.1
 */
@EnDomain
public class HuluCollectionContactDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*业务唯一标识*/
	private String uniqueNo;
	
	/*联系人姓名*/
	@EnField
	private String contactName;
	
	/*最早出现时间*/
	private String beginDate;
	
	/*最晚出现时间*/
	private String endDate;
	
	/*电商送货总数*/
	private Integer totalCount;
	
	/*电商送货总金额*/
	private Float totalAmount;
	
	/*电话号码*/
	private String phoneNum;
	
	/*号码归属地*/
	private String phoneNumLoc;
	
	/*呼叫次数*/
	private Integer callCnt;
	
	/*呼叫时长*/
	private Float callLen;
	
	/*呼出次数*/
	private Integer callOutCnt;
	
	/*呼入次数*/
	private Integer callInCnt;
	
	/*短信条数*/
	private Integer smsCnt;
	
	/*最早沟通时间*/
	private String transStart;
	
	/*最晚沟通时间*/
	private String transEnd;
	
	/*预留字段1*/
	private String spare1;
	
	/*预留字段2*/
	private String spare2;
	
	/*预留字段3*/
	private String spare3;
	
	/*预留字段4*/
	private String spare4;
	
	/*创建用户*/
	private Long creatUser;
	
	/*创建时间*/
	private Date creatTime;
	
	/*更新用户*/
	private Long updateUser;
	
	/*更新时间*/
	private Date updateTime;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getContactName(){
		return contactName;
	}
	
	public void setContactName(String contactName){
		this.contactName = contactName;
	}
	
	public String getBeginDate(){
		return beginDate;
	}
	
	public void setBeginDate(String beginDate){
		this.beginDate = beginDate;
	}
	
	public String getEndDate(){
		return endDate;
	}
	
	public void setEndDate(String endDate){
		this.endDate = endDate;
	}
	
	public Integer getTotalCount(){
		return totalCount;
	}
	
	public void setTotalCount(Integer totalCount){
		this.totalCount = totalCount;
	}
	
	public Float getTotalAmount(){
		return totalAmount;
	}
	
	public void setTotalAmount(Float totalAmount){
		this.totalAmount = totalAmount;
	}
	
	public String getPhoneNum(){
		return phoneNum;
	}
	
	public void setPhoneNum(String phoneNum){
		this.phoneNum = phoneNum;
	}
	
	public String getPhoneNumLoc(){
		return phoneNumLoc;
	}
	
	public void setPhoneNumLoc(String phoneNumLoc){
		this.phoneNumLoc = phoneNumLoc;
	}
	
	public Integer getCallCnt(){
		return callCnt;
	}
	
	public void setCallCnt(Integer callCnt){
		this.callCnt = callCnt;
	}
	
	public Float getCallLen(){
		return callLen;
	}
	
	public void setCallLen(Float callLen){
		this.callLen = callLen;
	}
	
	public Integer getCallOutCnt(){
		return callOutCnt;
	}
	
	public void setCallOutCnt(Integer callOutCnt){
		this.callOutCnt = callOutCnt;
	}
	
	public Integer getCallInCnt(){
		return callInCnt;
	}
	
	public void setCallInCnt(Integer callInCnt){
		this.callInCnt = callInCnt;
	}
	
	public Integer getSmsCnt(){
		return smsCnt;
	}
	
	public void setSmsCnt(Integer smsCnt){
		this.smsCnt = smsCnt;
	}
	
	public String getTransStart(){
		return transStart;
	}
	
	public void setTransStart(String transStart){
		this.transStart = transStart;
	}
	
	public String getTransEnd(){
		return transEnd;
	}
	
	public void setTransEnd(String transEnd){
		this.transEnd = transEnd;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Long getCreatUser(){
		return creatUser;
	}
	
	public void setCreatUser(Long creatUser){
		this.creatUser = creatUser;
	}
	
	public Date getCreatTime(){
		return creatTime;
	}
	
	public void setCreatTime(Date creatTime){
		this.creatTime = creatTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	
}
