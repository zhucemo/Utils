package com.macroflag.plusplatform.data.inner.biz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.data.inner.entity.MfNetgateInitemPacraresult;
import com.macroflag.plusplatform.data.inner.mapper.MfNetgateInitemPacraresultMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

/**
 * 
 * 
 * @author : huangf
 * @email hfei2801@163.com
 * @since : 2018-07-24 13:25:59
 * @version : v1.0.0
 */
@Service
public class MfNetgateInitemPacraresultBiz extends BusinessBiz<MfNetgateInitemPacraresultMapper,MfNetgateInitemPacraresult> {

	@Autowired
	private MfNetgateInitemPacraresultMapper mfNetgateInitemPacraresultMapper;
	
	
	public void updateByUniqueNo(MfNetgateInitemPacraresult paRisk) {
		
		mfNetgateInitemPacraresultMapper.updateByUniqueNo(paRisk);
		
	}
}