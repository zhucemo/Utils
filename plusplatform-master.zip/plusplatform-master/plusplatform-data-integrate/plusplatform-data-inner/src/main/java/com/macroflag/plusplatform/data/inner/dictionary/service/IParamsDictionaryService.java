package com.macroflag.plusplatform.data.inner.dictionary.service;

import java.util.Map;

import com.alibaba.fastjson.JSONObject;
import com.macroflag.plusplatform.common.core.service.IBaseService;
import com.macroflag.plusplatform.data.inner.entity.ParamsDictionaryDomain;

/**
 * 参数字典表的业务层接口
 * 
 * @author : Fredia
 * @since : 2018年05月05日
 * @version : v0.0.1
 */
public interface IParamsDictionaryService extends IBaseService<ParamsDictionaryDomain> {
	/**
	 * 结果中文转英文
	 * 
	 * @param jo
	 * @param module
	 * @return
	 * @author : Fredia
	 * @since : 2018年5月17日
	 * @return :JSONObject
	 */
	JSONObject convertCn2En(Map<String, Object> map, String module);

}
