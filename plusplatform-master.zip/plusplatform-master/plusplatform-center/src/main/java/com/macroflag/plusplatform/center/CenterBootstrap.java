
package com.macroflag.plusplatform.center;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

/**
 * Eureka注册中心
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
@EnableEurekaServer 
@SpringBootApplication
public class CenterBootstrap {
	public static void main(String[] args) {
		SpringApplication.run(CenterBootstrap.class, args);
	}
}
