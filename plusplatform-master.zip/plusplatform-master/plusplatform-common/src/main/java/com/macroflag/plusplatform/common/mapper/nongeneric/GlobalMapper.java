package com.macroflag.plusplatform.common.mapper.nongeneric;

public interface GlobalMapper {
    long getSequenceValueBySequenceName(String sequenceName);
}
