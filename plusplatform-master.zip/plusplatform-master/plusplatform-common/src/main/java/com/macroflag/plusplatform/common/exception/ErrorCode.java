package com.macroflag.plusplatform.common.exception;

/**
 * 自定义错误代码
 * 
 * @author : fredia
 * @since : 2017年11月2日
 * @version : v0.0.1
 */
public interface ErrorCode {

	/* 参数格式错误。 */
	Integer INVALID_ARGUMENT = 406;

	/* 资源不存在。 */
	Integer NOT_FOUND = 403;

	/* 短信发送失败 */
	Integer SMS_SEND_FAILED = 501;
}
