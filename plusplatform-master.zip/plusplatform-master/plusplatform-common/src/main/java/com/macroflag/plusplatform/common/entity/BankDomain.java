package com.macroflag.plusplatform.common.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 银行表的domain
 * @author : Fredia
 * @since : 2018年04月27日
 * @version : v0.0.1
 */
public class BankDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*主键*/
	private Long id;
	
	/*银行名称*/
	private String bankName;
	
	/*银行代码*/
	private String bankCode;
	
	/*备注*/
	private String remark;
	
	/*银行配置*/
	private String config;
	
	/*备用1*/
	private String spare1;
	
	/*备用2*/
	private String spare2;
	
	/*备用3*/
	private String spare3;
	
	/*备用4*/
	private String spare4;
	
	/*当前是否有效,1-有效，0-无效*/
	private Integer isActive;
	
	/**/
	private Date createTime;
	
	/**/
	private Long createUser;
	
	/**/
	private Date updateTime;
	
	/**/
	private Long updateUser;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getBankName(){
		return bankName;
	}
	
	public void setBankName(String bankName){
		this.bankName = bankName;
	}
	
	public String getBankCode(){
		return bankCode;
	}
	
	public void setBankCode(String bankCode){
		this.bankCode = bankCode;
	}
	
	public String getRemark(){
		return remark;
	}
	
	public void setRemark(String remark){
		this.remark = remark;
	}
	
	public String getConfig(){
		return config;
	}
	
	public void setConfig(String config){
		this.config = config;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Integer getIsActive(){
		return isActive;
	}
	
	public void setIsActive(Integer isActive){
		this.isActive = isActive;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	
}
