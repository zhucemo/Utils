package com.macroflag.plusplatform.common.product.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.common.core.service.impl.BaseServiceImpl;
import com.macroflag.plusplatform.common.mapper.nongeneric.ProductMapper;
import com.macroflag.plusplatform.common.entity.ProductDomain;
import com.macroflag.plusplatform.common.product.service.IProductService;

/**
 * 银行产品表的业务实现类
 * @author : fredia
 * @since : 2018年04月27日
 * @version : v0.0.1
 */
@Service("productService")
public class ProductServiceImpl extends BaseServiceImpl<ProductDomain> implements IProductService {
	
	@Autowired
	private ProductMapper productMapper;
	
}
