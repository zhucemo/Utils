package com.macroflag.plusplatform.common.model.resp;


import com.macroflag.plusplatform.common.model.resp.base.BaseModel;

/**
 * 手机服务密码验证返回model
 * @author huangf
 *
 */
public class RespPwdCerifyModel extends BaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 令牌
	 */
	private String token;
	
	/**
	 * 用户唯一编号
	 */
	private String uniqueNo;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	
	
}
