package com.macroflag.plusplatform.common.model;

import java.io.Serializable;

/**
 * 规则引擎评分对象
 * 
 * @author : Fredia
 * @since : 2018年3月13日
 * @version : v1.0.0
 */
public class RuleRspScoreModel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// 审批标示
	private String ApprovalId;
	// 拒绝原因码
	private String RejectReasonCode;
	// 策略分支码
	private String StrategyBranchCode;
	// 拒绝原因码1
	private String declineCode1 = "";
	// 拒绝原因码2
	private String declineCode2 = "";
	// 拒绝原因码3
	private String declineCode3 = "";

	public String getApprovalId() {
		return ApprovalId;
	}

	public void setApprovalId(String approvalId) {
		ApprovalId = approvalId;
	}

	public String getRejectReasonCode() {
		return RejectReasonCode;
	}

	public void setRejectReasonCode(String rejectReasonCode) {
		RejectReasonCode = rejectReasonCode;
	}

	public String getStrategyBranchCode() {
		return StrategyBranchCode;
	}

	public void setStrategyBranchCode(String strategyBranchCode) {
		StrategyBranchCode = strategyBranchCode;
	}

	public String getDeclineCode1() {
		return declineCode1;
	}

	public void setDeclineCode1(String declineCode1) {
		this.declineCode1 = declineCode1;
	}

	public String getDeclineCode2() {
		return declineCode2;
	}

	public void setDeclineCode2(String declineCode2) {
		this.declineCode2 = declineCode2;
	}

	public String getDeclineCode3() {
		return declineCode3;
	}

	public void setDeclineCode3(String declineCode3) {
		this.declineCode3 = declineCode3;
	}

}
