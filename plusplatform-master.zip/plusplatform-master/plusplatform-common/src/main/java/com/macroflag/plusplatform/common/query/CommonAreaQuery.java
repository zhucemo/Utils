package com.macroflag.plusplatform.common.query;

import com.macroflag.plusplatform.common.base.Query;

import java.util.Date;

/**
 * 用户的Query
 * @since : 2018年05月09日
 * @author : fredia
 * @version : v0.0.1
 */
public class CommonAreaQuery extends Query {

	/**
	* @Fields serialVersionUID : TODO
	*/
	private static final long serialVersionUID = 1L;
  
	/**
	 * 主键
	 */
	private Long id;
	
	/**
	 * 行政区划编码
	 */
	private String areaCode;
	
	/**
	 * 省市区名称
	 */
	private String areaName;
	
	/**
	 * 省市编码
	 */
	private String proCiCode;
	
	/**
	 * 排序代码
	 */
	private String disorder;
	
	/**
	 * 省区域代码
	 */
	private String procode;
	
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	
	public String getAreaCode(){
		return areaCode;
	}
	
	public void setAreaCode(String areaCode){
		this.areaCode = areaCode;
	}
	
	
	public String getAreaName(){
		return areaName;
	}
	
	public void setAreaName(String areaName){
		this.areaName = areaName;
	}
	
	
	public String getProCiCode(){
		return proCiCode;
	}
	
	public void setProCiCode(String proCiCode){
		this.proCiCode = proCiCode;
	}
	
	
	public String getDisorder(){
		return disorder;
	}
	
	public void setDisorder(String disorder){
		this.disorder = disorder;
	}
	
	
	public String getProcode(){
		return procode;
	}
	
	public void setProcode(String procode){
		this.procode = procode;
	}
	
	
}
