package com.macroflag.plusplatform.common.model.resp;


import com.macroflag.plusplatform.common.model.resp.base.BaseModel;

/**
 * dubbo 发送短信验证码返回实体类
 * @author huangf
 *
 */
public class RespSmsModel extends BaseModel {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 用户唯一编号
	 */
	private String uniqueNo;
	
	/**
	 * 手机号
	 */
	private String mobile;
	

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	
	
}
