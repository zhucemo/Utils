package com.macroflag.plusplatform.common.model.resp;


import com.macroflag.plusplatform.common.model.resp.base.BaseModel;

/**
 * 提交登录(或查询详单)短信验证码返回model
 * @author huangf
 *
 */
public class RespSubmitCaptchaModel extends BaseModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 用户唯一编号
	 */
	private String uniqueNo;

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}

}
