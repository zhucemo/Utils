package com.macroflag.plusplatform.common.sys.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.common.core.service.impl.BaseServiceImpl;
import com.macroflag.plusplatform.common.mapper.nongeneric.CommonEnumsMapper;
import com.macroflag.plusplatform.common.entity.CommonEnumsDomain;
import com.macroflag.plusplatform.common.sys.service.ICommonEnumsService;

/**
 * 枚举服务的业务实现类
 * @author : fredia
 * @since : 2018年04月24日
 * @version : v0.0.1
 */
@Service("commonEnumsService")
public class CommonEnumsServiceImpl extends BaseServiceImpl<CommonEnumsDomain> implements ICommonEnumsService {
	
	@Autowired
	private CommonEnumsMapper commonEnumsMapper;
	
}
