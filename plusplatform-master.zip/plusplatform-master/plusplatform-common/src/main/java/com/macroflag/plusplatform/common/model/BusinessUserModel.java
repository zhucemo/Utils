package com.macroflag.plusplatform.common.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * 业务系统用户数据模型
 * 
 * @author : Fredia
 * @since : 2018年4月27日
 * @version : v1.0.0
 */
public class BusinessUserModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String phone;
	// 姓名
	private String name;
	// 身份证
	private String documentno;
	// 产品号
	private String proCode;
	// 业务主键(申请编号)
	private String businessKey;
	// 用户唯一编号
	private String uniqueNo;

	/**
	 * 扩展参数-使用频率低的参数请存入此map,尽量避免冗余
	 */
	private Map<Object, Object> extendMap;

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDocumentno() {
		return documentno;
	}

	public void setDocumentno(String documentno) {
		this.documentno = documentno;
	}

	public String getProCode() {
		return proCode;
	}

	public void setProCode(String proCode) {
		this.proCode = proCode;
	}

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}

	public Map<Object, Object> getExtendMap() {
		return extendMap;
	}

	public void setExtendMap(Map<Object, Object> extendMap) {
		this.extendMap = extendMap;
	}

	public void put(Object key, Object obj) {
		if (this.extendMap == null) {
			this.extendMap = new HashMap<Object, Object>();
		}
		this.extendMap.put(key, obj);
	}

	@SuppressWarnings("unchecked")
	public <T> T get(Object key) {
		if (extendMap == null) {
			return null;
		}
		return (T) this.extendMap.get(key);
	}

}
