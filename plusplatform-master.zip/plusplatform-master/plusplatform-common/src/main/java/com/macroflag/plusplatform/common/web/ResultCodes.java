package com.macroflag.plusplatform.common.web;

/**
 * 系统状态码
 * 
 * @author : fredia
 * @since : 2017年2月9日
 * @version : v0.0.1
 */
public class ResultCodes {
	/**
	 * SUCCESS
	 */
	public static final int SUCCESS = 200;

	/**
	 * ERROR
	 */
	public static final int ERROR = 300;

	/**
	 * NOT_LOGIN
	 */
	public static final int NOT_LOGIN = 403;

	/**
	 * NOT_OPEN_ACCOUNT
	 */
	public static final int NOT_OPEN_ACCOUNT = 406;

	/**
	 * NOT_BIND_CARD
	 */
	public static final int NOT_BIND_CARD = 407;
}
