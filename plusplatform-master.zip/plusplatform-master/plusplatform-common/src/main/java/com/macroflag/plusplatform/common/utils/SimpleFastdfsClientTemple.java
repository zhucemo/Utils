package com.macroflag.plusplatform.common.utils;

import java.io.File;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import master.fastdfs.client2.SimpleFastdfsClient;
import master.fastdfs.client2.core.FastdfsExecutor;

/**

 * Description：对本文件的详细描述，原则上不能少于50字
 * 
 * 

 * @mender：（文件的修改者，文件创建者之外的人）
 * @version 1.0 Remark：认为有必要的其他信息
 */

public class SimpleFastdfsClientTemple {

	private static List<InetSocketAddress> trackers=new ArrayList<InetSocketAddress>();;

	private static ThreadLocal<SimpleFastdfsClient> dfs = new ThreadLocal<SimpleFastdfsClient>();

	private static ThreadLocal<FastdfsExecutor> executor = new ThreadLocal<FastdfsExecutor>();

	public SimpleFastdfsClientTemple() {
	}

	public SimpleFastdfsClientTemple(HashMap<String, Integer> iplist) {
			for (Map.Entry<String, Integer> entry : iplist.entrySet()) {
				trackers.add(new InetSocketAddress(entry.getKey(), entry.getValue()));
			}
	}

	private static FastdfsExecutor getExecutor() {
		if (executor.get() == null) {
			FastdfsExecutor obj = new FastdfsExecutor();
			obj.init();
			executor.set(obj);
		}
		return executor.get();
	}

	private static SimpleFastdfsClient getSimpleFastdfsClient() {
		if (dfs.get() == null) {
			dfs.set(new SimpleFastdfsClient(getExecutor(),trackers));
		}
		return dfs.get();
	}

	private static void executorShutdown() {
		FastdfsExecutor exe = getExecutor();
		if (exe != null) {
			exe.shutdown();
			dfs.remove();
			executor.remove();
		}
	}

	/**
	 * 
	 * 功能:上传 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param bytes
	 *            文件内容
	 * @param ext
	 *            文件扩展名
	 * @return
	 */
	public static String upload(byte[] bytes, String ext) {
		try {
			return getSimpleFastdfsClient().upload(bytes, ext);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:上传文件 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param bytes
	 *            文件内容
	 * @param ext
	 *            文件扩展名
	 * @param group
	 *            文件分组
	 * @return
	 */
	public String upload(byte[] bytes, String ext, String group) {
		try {
			return getSimpleFastdfsClient().upload(bytes, ext, group);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:上传本地文件 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param file
	 *            本地文件
	 * @return
	 */
	public static String upload(File file) {
		try {
			return getSimpleFastdfsClient().upload(file);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:上传本地文件 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param file
	 *            本地文件
	 * @param group
	 *            文件分组
	 * @return
	 */
	public String upload(File file, String group) {
		try {
			return getSimpleFastdfsClient().upload(file, group);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:上传 Appender 文件 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param bytes
	 *            文件内容
	 * @param ext
	 *            文件扩展名
	 * @return
	 */
	public String uploadAppender(byte[] bytes, String ext) {
		try {
			return getSimpleFastdfsClient().uploadAppender(bytes, ext);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能: 上传 Appender 文件 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param bytes
	 *            文件内容
	 * @param ext
	 *            文件扩展名
	 * @param group
	 *            文件分组
	 * @return
	 */
	public String uploadAppender(byte[] bytes, String ext, String group) {
		try {
			return getSimpleFastdfsClient().uploadAppender(bytes, ext, group);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:上传本地文件为 appender 文件 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param file
	 *            本地文件
	 * @return
	 */
	public String uploadAppender(File file) {
		try {
			return getSimpleFastdfsClient().uploadAppender(file);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:上传本地文件为 appender 文件 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param file
	 *            本地文件
	 * @param group
	 *            文件分组
	 * @return
	 */
	public String uploadAppender(File file, String group) {
		try {
			return getSimpleFastdfsClient().uploadAppender(file, group);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:下载文件 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param path
	 *            服务器存储路径
	 * @return
	 */
	public static byte[] download(String path) {
		try {
			return getSimpleFastdfsClient().download(path);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:删除文件 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param path
	 *            服务器存储路径
	 */
	public void delete(String path) {
		try {
			getSimpleFastdfsClient().delete(path);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:追加文件 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param path
	 *            服务器存储路径
	 * @param bytes
	 *            文件内容
	 */
	public void append(String path, byte[] bytes) {
		try {
			getSimpleFastdfsClient().append(path, bytes);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:修改文件内容 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param path
	 *            服务器存储路径
	 * @param bytes
	 *            修改内容
	 * @param offset
	 *            修改起始偏移量
	 */
	public void modify(String path, byte[] bytes, int offset) {
		try {
			getSimpleFastdfsClient().modify(path, bytes, offset);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:截取文件内容 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param path
	 *            服务器存储路径
	 */
	public void truncate(String path) {
		try {
			getSimpleFastdfsClient().truncate(path);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能: 截取文件内容 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param path
	 *            服务器存储路径
	 * @param truncatedSize
	 *            截取字节数
	 */
	public void truncate(String path, int truncatedSize) {
		try {
			getSimpleFastdfsClient().truncate(path, truncatedSize);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:设置文件元数据 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param path
	 *            服务器存储路径
	 * @param metadata
	 *            元数据
	 */
	public void setMetadata(String path, Map<String, String> metadata) {
		try {
			getSimpleFastdfsClient().setMetadata(path, metadata);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:设置文件元数据 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param path
	 *            服务器存储路径
	 * @param metadata
	 *            元数据
	 * @param flag
	 *            设置标识
	 */
	public void setMetadata(String path, Map<String, String> metadata, byte flag) {
		try {
			getSimpleFastdfsClient().setMetadata(path, metadata, flag);
		} finally {
			executorShutdown();
		}
	}

	/**
	 * 
	 * 功能:获取文件元数据 作者: 陈继伟 创建日期:2016-3-16
	 * 
	 * @param path
	 * @return
	 */
	public Map<String, String> getMetadata(String path) {
		try {
			return getSimpleFastdfsClient().getMetadata(path);
		} finally {
			executorShutdown();
		}
	}

}
