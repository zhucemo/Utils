package com.macroflag.plusplatform.common.product.service;


import com.macroflag.plusplatform.common.core.service.IBaseService;
import com.macroflag.plusplatform.common.entity.ProductDomain;

/**
 * 银行产品表的业务层接口
 * @author : fredia
 * @since : 2018年04月27日
 * @version : v0.0.1
 */
public interface IProductService extends IBaseService<ProductDomain> {

}
