package com.macroflag.plusplatform.common.utils;

import com.macroflag.plusplatform.common.util.BeanUtils;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.web.context.support.StandardServletEnvironment;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;


/**
 * 获取资源文件
 *
 * @author : fredia
 * @version : v0.0.1
 * @since : 2017年10月13日
 */
@Configuration
public class GlobalConstant {
    private static Map<String, String> properties = new HashMap<>();

    public static String getString(String key) {
        StandardServletEnvironment environment = (StandardServletEnvironment) BeanUtils.getBean(Environment.class);
        MutablePropertySources multipartProperties = environment.getPropertySources();
        Properties properties = (Properties) multipartProperties.get("applicationConfig: [classpath:/application.properties]").getSource();
        return properties.getProperty(key);
    }

}
