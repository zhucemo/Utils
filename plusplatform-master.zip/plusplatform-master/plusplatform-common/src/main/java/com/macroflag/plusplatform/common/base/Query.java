package com.macroflag.plusplatform.common.base;

import java.io.Serializable;
import java.util.List;

/**
 * DTO基类,参数bean
 * 
 * @author : fredia
 * @email : trumpey@163.com
 * @since : 2017年11月15日
 * @version : v0.0.1
 */

public class Query implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/* 当前页码 */
	private Integer pageIndex = 1;
	/* 页面大小，默认20 */
	private Integer pageSize = 20;
	/* 排序，指定字段 */
	private String orderBy;
	/* 排序，指定字段和排序方式 */
	private String sort;
	/* 是否倒序，默认是 */
	private Boolean isDesc = true;
	/* 使用主键in作为查询条件时使用 */
	@SuppressWarnings("rawtypes")
	private List idList;

	/* 分页开始行 */
	private Integer rowstartindex;
	/* 分页结束行 */
	private Integer rowendindex;

	public Integer getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getSort() {
		return sort;
	}

	public void setSort(String sort) {
		this.sort = sort;
	}

	public Boolean getIsDesc() {
		return isDesc;
	}

	public void setIsDesc(Boolean isDesc) {
		this.isDesc = isDesc;
	}

	@SuppressWarnings("rawtypes")
	public List getIdList() {
		return idList;
	}

	@SuppressWarnings("rawtypes")
	public void setIdList(List idList) {
		this.idList = idList;
	}

	public Integer getRowstartindex() {
		return rowstartindex;
	}

	public void setRowstartindex(Integer rowstartindex) {
		this.rowstartindex = rowstartindex;
	}

	public Integer getRowendindex() {
		return rowendindex;
	}

	public void setRowendindex(Integer rowendindex) {
		this.rowendindex = rowendindex;
	}

}
