package com.macroflag.plusplatform.common.model.resp;

import com.macroflag.plusplatform.common.model.resp.base.BaseModel;

/**
 * 绑定银行卡响应model
 * @author huangf
 *
 */
public class RespAuthbindCardModel extends BaseModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 用户唯一编号
	 */
	private String uniqueNo;

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
}
