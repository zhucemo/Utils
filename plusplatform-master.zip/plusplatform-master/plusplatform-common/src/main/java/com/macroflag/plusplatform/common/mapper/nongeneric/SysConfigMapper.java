package com.macroflag.plusplatform.common.mapper.nongeneric;

import com.macroflag.plusplatform.common.entity.SysConfig;
import com.macroflag.plusplatform.common.mapper.CommonMapper;

import java.util.List;

/**
 * 
 * 
 * @author : Fredia
 * @email trumpey@163.com
 * @since : 2018-06-26 16:25:23
 * @version : v1.0.0
 */
public interface SysConfigMapper extends CommonMapper<SysConfig> {
    List<SysConfig> findAll();
    SysConfig getOneByKey(String key);
}
