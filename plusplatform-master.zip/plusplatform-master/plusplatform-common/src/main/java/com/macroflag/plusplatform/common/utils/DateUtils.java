package com.macroflag.plusplatform.common.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

/**
 * 日期工具
 * 
 * @author : fredia
 * @email : trumpey@163.com
 * @since : 2017年11月16日
 * @version : v0.0.1
 */
public class DateUtils extends org.apache.commons.lang3.time.DateUtils {
	private static String[] parsePatterns = { "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm", "yyyy-MM",
			"yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy/MM", "yyyy.MM.dd", "yyyy.MM.dd HH:mm:ss",
			"yyyy.MM.dd HH:mm", "yyyy.MM", "yyyyMMdd" };

	/**
	 * 得到当前日期字符串 格式（yyyy-MM-dd）
	 */
	public static String getDate() {
		return getDate("yyyy-MM-dd");
	}

	/**
	 * 得到当前日期字符串 格式（yyyy-MM-dd） pattern可以为："yyyy-MM-dd" "HH:mm:ss" "E"
	 */
	public static String getDate(String pattern) {
		return DateFormatUtils.format(new Date(), pattern);
	}

	/**
	 * 得到日期字符串 默认格式（yyyy-MM-dd） pattern可以为："yyyy-MM-dd" "HH:mm:ss" "E"
	 */
	public static String formatDate(Date date, Object... pattern) {
		String formatDate = null;
		if (pattern != null && pattern.length > 0) {
			formatDate = DateFormatUtils.format(date, pattern[0].toString());
		} else {
			formatDate = DateFormatUtils.format(date, "yyyy-MM-dd");
		}
		return formatDate;
	}

	/**
	 * 得到日期时间字符串，转换格式（yyyy-MM-dd HH:mm:ss）
	 */
	public static String formatDateTime(Date date) {
		return formatDate(date, "yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * 得到当前时间字符串 格式（HH:mm:ss）
	 */
	public static String getTime() {
		return formatDate(new Date(), "HH:mm:ss");
	}

	/**
	 * 得到当前日期和时间字符串 格式（yyyy-MM-dd HH:mm:ss）
	 */
	public static String getDateTime() {
		return formatDate(new Date(), "yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * 得到当前年份字符串 格式（yyyy）
	 */
	public static String getYear() {
		return formatDate(new Date(), "yyyy");
	}

	/**
	 * 得到当前月份字符串 格式（MM）
	 */
	public static String getMonth() {
		return formatDate(new Date(), "MM");
	}

	/**
	 * 得到当天字符串 格式（dd）
	 */
	public static String getDay() {
		return formatDate(new Date(), "dd");
	}

	/**
	 * 得到当前星期字符串 格式（E）星期几
	 */
	public static String getWeek() {
		return formatDate(new Date(), "E");
	}

	/**
	 * 日期型字符串转化为日期 格式 { "yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm",
	 * "yyyy/MM/dd", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm", "yyyy.MM.dd",
	 * "yyyy.MM.dd HH:mm:ss", "yyyy.MM.dd HH:mm" }
	 */
	public static Date parseDate(Object str) {
		if (str == null) {
			return null;
		}
		try {
			return parseDate(str.toString(), parsePatterns);
		} catch (ParseException e) {
			return null;
		}
	}

	/**
	 * 获取过去的天数
	 *
	 * @param date
	 * @return
	 */
	public static long pastDays(Date date) {
		long t = new Date().getTime() - date.getTime();
		return t / (24 * 60 * 60 * 1000);
	}

	/**
	 * 获取过去的小时
	 *
	 * @param date
	 * @return
	 */
	public static long pastHour(Date date) {
		long t = new Date().getTime() - date.getTime();
		return t / (60 * 60 * 1000);
	}

	/**
	 * 获取过去的分钟
	 *
	 * @param date
	 * @return
	 */
	public static long pastMinutes(Date date) {
		long t = new Date().getTime() - date.getTime();
		return t / (60 * 1000);
	}

	/**
	 * 转换为时间（天,时:分:秒.毫秒）
	 *
	 * @param timeMillis
	 * @return
	 */
	public static String formatDateTime(long timeMillis) {
		long day = timeMillis / (24 * 60 * 60 * 1000);
		long hour = (timeMillis / (60 * 60 * 1000) - day * 24);
		long min = ((timeMillis / (60 * 1000)) - day * 24 * 60 - hour * 60);
		long s = (timeMillis / 1000 - day * 24 * 60 * 60 - hour * 60 * 60 - min * 60);
		long sss = (timeMillis - day * 24 * 60 * 60 * 1000 - hour * 60 * 60 * 1000 - min * 60 * 1000 - s * 1000);
		return (day > 0 ? day + "," : "") + hour + ":" + min + ":" + s + "." + sss;
	}

	/**
	 * 转换为时间（?天?小时?分?秒）
	 *
	 * @param timeMillis
	 * @return
	 */
	public static String formatDateTime2(long timeMillis) {
		long day = timeMillis / (24 * 60 * 60 * 1000);
		long hour = (timeMillis / (60 * 60 * 1000) - day * 24);
		long min = ((timeMillis / (60 * 1000)) - day * 24 * 60 - hour * 60);
		long s = (timeMillis / 1000 - day * 24 * 60 * 60 - hour * 60 * 60 - min * 60);
		return (day > 0 ? day + "天" : "") + hour + "小时" + min + "分" + s + "秒";
	}

	/**
	 * 获取两个日期之间的天数
	 *
	 * @param before
	 * @param after
	 * @return
	 */
	public static double getDistanceOfTwoDate(Date before, Date after) {
		long beforeTime = before.getTime();
		long afterTime = after.getTime();
	    BigDecimal b1 = new BigDecimal(afterTime - beforeTime);  
        BigDecimal b2 = new BigDecimal(1000 * 60 * 60 * 24);  
        
        //四舍五入取两位小数
        return b1.divide(b2,2,BigDecimal.ROUND_HALF_UP).doubleValue();
		
	}

	/**
	 * 获取date天的开始和结束时间
	 *
	 * @param date
	 *            日期
	 * @return [0] 开始时间 [1]结束时间
	 */
	public static Date[] getDayStartEnd(Date date) {
		Date[] result = new Date[2];
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		setCalendarDayStart(calendar);
		result[0] = calendar.getTime();

		setCalendarDayEnd(calendar);
		result[1] = calendar.getTime();

		return result;
	}

	/**
	 * 获取日期开始时间
	 *
	 * @param date
	 * @return 时间
	 */
	public static Date getDayStart(Date date) {
		if (date == null) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		setCalendarDayStart(calendar);
		return calendar.getTime();
	}

	/**
	 * 获取日期结束时间
	 *
	 * @param date
	 *            日期
	 * @return 时间
	 */
	public static Date getDayEnd(Date date) {
		if (date == null) {
			return null;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		setCalendarDayEnd(calendar);
		return calendar.getTime();
	}

	/**
	 * 获取优惠券日期时间
	 *
	 * @param date
	 *            日期
	 * @return 时间
	 */
	public static Date getCouponDayEnd(Date date) {
		if (date == null) {
			return null;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 58);
		return calendar.getTime();
	}

	/**
	 * 获取两个日期自然日差值
	 *
	 * @param startDate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @return 相差自然日天数
	 */
	public static int getNaturalDayCount(Date startDate, Date endDate) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(startDate);
		calendar.add(Calendar.DATE, 1);
		setCalendarDayStart(calendar);
		long startMillis = calendar.getTimeInMillis();

		calendar.setTime(endDate);
		setCalendarDayStart(calendar);
		long endMillis = calendar.getTimeInMillis();
		return Integer.parseInt((endMillis - startMillis) / (24 * 60 * 60 * 1000) + "");
	}

	/**
	 * 设置calendar为日期开始时间
	 *
	 * @param calendar
	 *            calendar
	 */
	private static void setCalendarDayStart(Calendar calendar) {
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
	}

	/**
	 * 设置calendar为日期结束时间
	 *
	 * @param calendar
	 *            calendar
	 */
	private static void setCalendarDayEnd(Calendar calendar) {
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		calendar.set(Calendar.MILLISECOND, 999);
	}

	/**
	 * 获取开始时间到今天的自然日天数
	 *
	 * @param startDate
	 *            开始时间
	 * @return 自然日天数
	 */
	public static int getNaturalDayCount(Date startDate) {
		return getNaturalDayCount(startDate, new Date());
	}

	public static int compareDate(Date d1, Date d2) {
		Date temp1 = getDayEnd(d1);
		Date temp2 = getDayEnd(d2);
		if(temp1 != null){
			return temp1.compareTo(temp2);
		}else {
			return -1;
		}
	}

	/**
	 * 获取指定天数之前的某一天
	 */
	public static String dayOfBefore(int days) {
		Calendar c = Calendar.getInstance();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		c.add(Calendar.DAY_OF_YEAR, -(days));
		return simpleDateFormat.format(c.getTime());
	}

	/**
	 * 获取指定天数之前的某月
	 */
	public static String monthOfBefore(int month) {
		Calendar c = Calendar.getInstance();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM");
		c.add(Calendar.MONTH, -(month));
		return simpleDateFormat.format(c.getTime());
	}

	/**
	 * 获取指定天数之前的某年
	 */
	public static String yeatOfBefore(int year) {
		Calendar c = Calendar.getInstance();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy");
		c.add(Calendar.YEAR, -(year));
		return simpleDateFormat.format(c.getTime());
	}

	/**
	 * 获取当前时间前一天
	 */
	public static Date getlastFristDay() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -1);
		return cal.getTime();
	}

	/**
	 * 获取后几分钟
	 */
	public static String getBeforeTime(Integer minute, String pattern) {
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Calendar beforeTime = Calendar.getInstance();
		beforeTime.add(Calendar.MINUTE, minute);
		Date beforeD = beforeTime.getTime();
		return sdf.format(beforeD);

	}

	public static Date now() {
		return new Date();
	}
	
	/**
	 * 判断身份证上返回的时间是否是有效时间
	 * @param valid_date
	 * @return
	 */
	 public static boolean isDate(String valid_date) {
	    	boolean isDateYN = true;
	    	try {
	    		String ValidityDateBegin = valid_date.substring(0,
	    				valid_date.indexOf("-"));
	    		String ValidityDateEnd = valid_date.substring(
	    				valid_date.indexOf("-") + 1, valid_date.length());
	    		String tmp1 = ValidityDateBegin.replace(".", "");//生效日期
	    		String tmp2 = ValidityDateEnd.replace(".", "");//失效日期
	    		SimpleDateFormat dtformat = new SimpleDateFormat("yyyyMMdd");
	    		dtformat.setLenient(false);//设置lenient为false,否则SimpleDateFormat会比较宽松地验证日期，比如2017/02/29会被接受，并转换成2017/03/01
//	    		Date dadaBegin = null;
//	    		Date dadaEnd = null;
	    		int beginlen = tmp1.length();
	    		int endlen = tmp2.length();
	    		if("长期".equals(tmp2)){//失效日期是“长期”的只校验生效日期
	        		if(beginlen!=8){
	        			isDateYN = false;
	        		}
//	        		else{
//	        			dadaBegin = dtformat.parse(tmp1);
//	        		}
	    		}else{
	    			if(beginlen!=8||endlen!=8){
	    				isDateYN = false;
	    			}
//	    			else{
//	    				dadaBegin = dtformat.parse(tmp1);
//	        			dadaEnd = dtformat.parse(tmp2);
//	    			}
	    		}
			} catch (Exception e) {
				isDateYN = false;
			}
	    	return isDateYN;
	    }
	 
	/**
	 * 根据出生年月计算年龄
	 * @param dateStr
	 * @return
	 */
	public static String getAgeByDate(String dateStr){
		SimpleDateFormat myFormatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date=new Date();     
		Date mydate;
		try {
			mydate = myFormatter.parse(dateStr);
			long day=(date.getTime()-mydate.getTime())/(24*60*60*1000) + 1;
			String year=new DecimalFormat("#").format(day/365f);
			return year;
		} catch (ParseException e) {
			throw new RuntimeException(e);
		}
	}
	
	public static String getSxByYear(String yearStr) {
		int year = Integer.parseInt(yearStr);
		 if (year < 1900) {
	            return "未知";
	        }
	        int start = 1900;
	        String[] years = new String[] { "鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊",
	                "猴", "鸡", "狗", "猪" };
	        return years[(year - start) % years.length];
	}
	
	 /**
    *
    * 此方法描述的是：根据时间字符串获取时间
    *
    * @param dateStr 为日期的字符串 ,如'2011-03-05'
    * @param pattern 日期的字符串格式 ,如"yyyy-MM-dd"
    * @return Date
    */
   public static Date getDate(String dateStr, String pattern) {
       if (null == pattern) {
           pattern = "yyyy-MM-dd";
       }
       if (StringUtils.isEmpty(dateStr)) {
           return null;
       }
       SimpleDateFormat sdf = new SimpleDateFormat(pattern);
       try {
           return sdf.parse(dateStr);
       } catch (ParseException e) {
           e.printStackTrace();
       }
       return null;
   }
   
   /**
    * 将字符型日期时间转换成date类型的日期时间格式
    * @param dateStr
    * @param pattern
    * @return
    */
   public static Date formatterDate(String dateStr, String pattern ){
       	Date ldt = null;
		try {
			ldt = DateUtils.parseDate(dateStr, pattern);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		   return ldt;
   }
   
   
}
