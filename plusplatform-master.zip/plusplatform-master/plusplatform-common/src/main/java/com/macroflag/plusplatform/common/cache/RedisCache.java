package com.macroflag.plusplatform.common.cache;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;

import com.macroflag.plusplatform.common.utils.ProtoStuffSerializerUtil;
import org.springframework.stereotype.Component;

/**
 * redis缓存
 * 
 * @author : Fredia
 * @since : 2018年4月16日
 * @version : v1.0.0
 */
@Component
public class RedisCache {

	/* spring redis 模版 */
	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	/* redis key值 操作前缀 */
	private String prefixname = "mf_";

	public RedisTemplate<String, String> getRedisTemplate() {
		return redisTemplate;
	}

	public void setRedisTemplate(RedisTemplate<String, String> redisTemplate) {
		this.redisTemplate = redisTemplate;
	}

	public String getPrefixname() {
		return prefixname;
	}

	public void setPrefixname(String prefixname) {
		this.prefixname = prefixname;
	}

	/*	*//**
			 * 存入单个对象
			 * 
			 * @param key
			 * @param obj
			 * @return
			 * @author : Fredia
			 * @since : 2018年4月16日
			 * @return :boolean
			 *//*
			 * public <T> boolean putCache(String key, T obj) { final byte[]
			 * bkey = (prefixname + key).getBytes(); final byte[] bvalue =
			 * ProtoStuffSerializerUtil.serialize(obj); boolean result =
			 * redisTemplate.execute(new RedisCallback<Boolean>() {
			 * 
			 * @Override public Boolean doInRedis(RedisConnection connection)
			 * throws DataAccessException { return connection.setNX(bkey,
			 * bvalue); } }); return result; }
			 */

	/**
	 * 存入单个对象 没有默认前缀
	 * 
	 * @param key
	 * @param obj
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :boolean
	 */
	public <T> boolean putCacheNotPrefix(String key, T obj) {
		final byte[] bkey = key.getBytes();
		final byte[] bvalue = ProtoStuffSerializerUtil.serialize(obj);
		boolean result = redisTemplate.execute(new RedisCallback<Boolean>() {
			@Override
			public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.setNX(bkey, bvalue);
			}
		});
		return result;
	}

	/**
	 * 存入单个对象并设定 有效时间
	 * 
	 * @param key
	 * @param obj
	 * @param expireTime
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :void
	 */
	public <T> void putCacheWithExpireTime(String key, T obj, final long expireTime) {
		final byte[] bkey = (prefixname + key).getBytes();
		final byte[] bvalue = ProtoStuffSerializerUtil.serialize(obj);
		redisTemplate.execute(new RedisCallback<Boolean>() {
			@Override
			public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
				connection.setEx(bkey, expireTime, bvalue);
				return true;
			}
		});
	}

	/**
	 * 存入单个值
	 * 
	 * @param key
	 * @param values
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :void
	 */
	public void putCache(String key, String values) {
		final byte[] bkey = (prefixname + key).getBytes();
		final byte[] bvalue = values.getBytes();
		redisTemplate.execute(new RedisCallback<Boolean>() {
			@Override
			public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
				connection.set(bkey, bvalue);
				return true;
			}
		});
	}

	/**
	 * 存入单个值并设定有效时间
	 * 
	 * @param key
	 * @param values
	 * @param expireTime
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :void
	 */
	public void putCacheWithExpireTime2(String key, String values, final long expireTime) {
		final byte[] bkey = (prefixname + key).getBytes();
		final byte[] bvalue = values.getBytes();
		redisTemplate.execute(new RedisCallback<Boolean>() {
			@Override
			public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
				connection.setEx(bkey, expireTime, bvalue);
				return true;
			}
		});
	}

	/**
	 * 存入一个集合
	 * 
	 * @param key
	 * @param objList
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :boolean
	 */
	public <T> boolean putListCache(String key, List<T> objList) {
		final byte[] bkey = (prefixname + key).getBytes();
		final byte[] bvalue = ProtoStuffSerializerUtil.serializeList(objList);
		boolean result = redisTemplate.execute(new RedisCallback<Boolean>() {
			@Override
			public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.setNX(bkey, bvalue);
			}
		});
		return result;
	}

	/**
	 * 存入一个集合并设定 有效时间
	 * 
	 * @param key
	 * @param objList
	 * @param expireTime
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :boolean
	 */
	public <T> boolean putListCacheWithExpireTime(String key, List<T> objList, final long expireTime) {
		final byte[] bkey = (prefixname + key).getBytes();
		final byte[] bvalue = ProtoStuffSerializerUtil.serializeList(objList);
		boolean result = redisTemplate.execute(new RedisCallback<Boolean>() {
			@Override
			public Boolean doInRedis(RedisConnection connection) throws DataAccessException {
				connection.setEx(bkey, expireTime, bvalue);
				return true;
			}
		});
		return result;
	}

	/**
	 * 获取单个对象
	 * 
	 * @param key
	 * @param targetClass
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :T
	 */
	public <T> T getCache(final String key, Class<T> targetClass) {
		byte[] result = redisTemplate.execute(new RedisCallback<byte[]>() {
			@Override
			public byte[] doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.get((prefixname + key).getBytes());
			}
		});
		if (result == null) {
			return null;
		}
		return ProtoStuffSerializerUtil.deserialize(result, targetClass);
	}

	/**
	 * 获取单个对象 不带默认前缀
	 * 
	 * @param key
	 * @param targetClass
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :T
	 */
	public <T> T getCacheNotPrefix(final String key, Class<T> targetClass) {
		byte[] result = redisTemplate.execute(new RedisCallback<byte[]>() {
			@Override
			public byte[] doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.get(key.getBytes());
			}
		});
		if (result == null) {
			return null;
		}
		return ProtoStuffSerializerUtil.deserialize(result, targetClass);
	}

	/**
	 * 获取单个值
	 * 
	 * 
	 * @param key
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :String
	 */
	public String getCache(final String key) {
		byte[] result = redisTemplate.execute(new RedisCallback<byte[]>() {
			@Override
			public byte[] doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.get((prefixname + key).getBytes());
			}
		});
		if (result == null) {
			return null;
		}
		return new String(result);
	}

	/**
	 * 获取单个值 没有默认前缀
	 * 
	 * @param key
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :String
	 */
	public String getCacheNotPrefix(final String key) {
		byte[] result = redisTemplate.execute(new RedisCallback<byte[]>() {
			@Override
			public byte[] doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.get(key.getBytes());
			}
		});
		if (result == null) {
			return null;
		}
		return new String(result);
	}

	/**
	 * 获取一个集合
	 * 
	 * @param key
	 * @param targetClass
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :List<T>
	 */
	public <T> List<T> getListCache(final String key, Class<T> targetClass) {
		byte[] result = redisTemplate.execute(new RedisCallback<byte[]>() {
			@Override
			public byte[] doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.get((prefixname + key).getBytes());
			}
		});
		if (result == null) {
			return null;
		}
		return ProtoStuffSerializerUtil.deserializeList(result, targetClass);
	}

	/**
	 * 精确删除key
	 * 
	 * @param key
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :void
	 */
	public void deleteCache(String key) {
		redisTemplate.delete((prefixname + key));
		// Long result = redisTemplate.execute(new RedisCallback<Long>() {
		// @Override
		// public Long doInRedis(RedisConnection connection) throws
		// DataAccessException {
		// return connection.del(key.getBytes());
		// }
		// });
		// return result;
	}

	/**
	 * 精确删除key 没有默认前缀
	 * 
	 * @param key
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :void
	 */
	public void delCacheNotPrefix(String key) {
		redisTemplate.delete(key);
	}

	/**
	 * 模糊删除key
	 * 
	 * @param pattern
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :void
	 */
	public void deleteCacheWithPattern(String pattern) {
		Set<String> keys = redisTemplate.keys(pattern);
		redisTemplate.delete(keys);
	}

	/**
	 * 清空所有缓存
	 * 
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :void
	 */
	public void clearCache() {
		deleteCacheWithPattern(prefixname + "|*");
	}

	/**
	 * List-新增一个元素
	 * 
	 * @param key
	 * @param values
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :Long
	 */
	public Long lPush(String key, String values) {
		final byte[] bkey = (prefixname + key).getBytes();
		final byte[] bvalue = values.getBytes();
		Long result = redisTemplate.execute(new RedisCallback<Long>() {
			@Override
			public Long doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.lPush(bkey, bvalue);
			}
		});
		return result;
	}

	/**
	 * List-索引首位置插入一个元素
	 * 
	 * @param key
	 * @param values
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :Long
	 */
	public Long lPushX(String key, String values) {
		final byte[] bkey = (prefixname + key).getBytes();
		final byte[] bvalue = values.getBytes();
		Long result = redisTemplate.execute(new RedisCallback<Long>() {
			@Override
			public Long doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.lPushX(bkey, bvalue);
			}
		});
		return result;
	}

	/**
	 * List-索引尾位置插入一个元素
	 * 
	 * @param key
	 * @param values
	 * @return List中元素的个数
	 * @author : houshangkun
	 * @since : 2017年3月24日
	 */
	public Long rPushX(String key, String values) {
		final byte[] bkey = (prefixname + key).getBytes();
		final byte[] bvalue = values.getBytes();
		Long result = redisTemplate.execute(new RedisCallback<Long>() {
			@Override
			public Long doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.rPushX(bkey, bvalue);
			}
		});
		return result;
	}

	/**
	 * List-查询索引尾位置的元素
	 * 
	 * @param key
	 * @param index
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :String
	 */
	public String lIndex(String key, long index) {
		final byte[] bkey = (prefixname + key).getBytes();
		byte[] result = redisTemplate.execute(new RedisCallback<byte[]>() {
			@Override
			public byte[] doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.lIndex(bkey, index);
			}
		});
		return new String(result);
	}

	/**
	 * List-查询元素的个数
	 * 
	 * @param key
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :Long
	 */
	public Long lLen(String key) {
		final byte[] bkey = (prefixname + key).getBytes();
		Long result = redisTemplate.execute(new RedisCallback<Long>() {
			@Override
			public Long doInRedis(RedisConnection connection) throws DataAccessException {
				return connection.lLen(bkey);
			}
		});
		if (result == null) {
			result = 0L;
		}
		return result;
	}

	/**
	 * List-移除指定位索引位置的元素
	 * 
	 * @param key
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月16日
	 * @return :String
	 */
	public String lPop(String key) {
		final byte[] bkey = (prefixname + key).getBytes();
		String result = redisTemplate.execute(new RedisCallback<String>() {
			@Override
			public String doInRedis(RedisConnection connection) throws DataAccessException {
				return new String(connection.lPop(bkey));
			}
		});
		return result;
	}
}
