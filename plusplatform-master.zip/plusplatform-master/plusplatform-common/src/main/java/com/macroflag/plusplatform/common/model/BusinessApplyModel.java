package com.macroflag.plusplatform.common.model;

import java.io.Serializable;
import java.util.Date;

/**
 * 信审任务model
 * 
 * @author : Fredia
 * @since : 2018年4月27日
 * @version : v1.0.0
 */
public class BusinessApplyModel implements Serializable {

	private static final long serialVersionUID = 1L;
	/**/
	private Long id;

	/* 申请单号 */
	private String applyNo;

	/* 用户唯一标示 */
	private String uniqueNo;

	private String name;

	private String idCard;
	/* 产品编号 */
	private String productName;

	/* 人工审核状态 */
	private String approvalStatus;

	/* 流程id */
	private String flowId;

	/* 审批额度 */
	private String quota;

	/* 进件时间 */
	private Date createTime;
	/**/
	private Date updateTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getApplyNo() {
		return applyNo;
	}

	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(String approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getFlowId() {
		return flowId;
	}

	public void setFlowId(String flowId) {
		this.flowId = flowId;
	}

	public String getQuota() {
		return quota;
	}

	public void setQuota(String quota) {
		this.quota = quota;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
