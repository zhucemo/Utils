package com.macroflag.plusplatform.common.mapper.nongeneric;

import com.macroflag.plusplatform.common.entity.ProductSceneDomain;
import com.macroflag.plusplatform.common.mapper.Mapper;

/**
 * 产品场景表的mapper
 * @author : fredia
 * @since : 2018年05月08日
 * @version : v0.0.1
 */
public interface ProductSceneMapper extends Mapper<ProductSceneDomain> {
	
}
