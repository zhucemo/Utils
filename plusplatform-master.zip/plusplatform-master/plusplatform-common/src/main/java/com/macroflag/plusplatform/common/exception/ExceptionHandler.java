package com.macroflag.plusplatform.common.exception;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

/**
 * 异常处理 托管给spring
 * 
 * @author : fredia
 * @email : trumpey@163.com
 * @since : 2017年11月15日
 * @version : v0.0.1
 */
public class ExceptionHandler implements HandlerExceptionResolver {

	private static final Logger logger = LoggerFactory.getLogger(ExceptionHandler.class);

	public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
			Exception ex) {
		// TODO Auto-generated method stub
		logger.error("自定义异常：" + ex.getMessage(), ex);
		return null;
	}

}
