package com.macroflag.plusplatform.common.mapper;

import com.macroflag.plusplatform.common.base.Query;

import java.util.List;


/**
 * Mapper基类
 * 
 * @author : fredia
 * @email : trumpey@163.com
 * @since : 2017年11月16日
 * @version : v0.0.1
 */
public interface Mapper<T> {

	/**
	 * 根据主键查询
	 * 
	 * @param primaryKey
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :T
	 */
	public T getByPrimaryKey(Object primaryKey);

	/**
	 * 条件查询一条数据，如果有多条取第一条
	 * 
	 * @param query
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :T
	 */
	public T getOne(Query query);

	/**
	 * 查询返回一个集合
	 * 
	 * @param query
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :List<T>
	 */
	public List<T> getList(Query query);

	/**
	 * 查询总数
	 * 
	 * @param query
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :Integer
	 */
	public Integer getListCount(Query query);

	/**
	 * 插入新数据，返回受影响行数
	 * 
	 * @param model
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :int
	 */
	public int insert(T model);

	/**
	 * 批量插入多条数据,返回受影响行数
	 * 
	 * @param list
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :int
	 */
	public int insertBatch(List<T> list);

	/**
	 * 根据主键更新,更新不为null数据,返回受影响行数
	 * 
	 * @param model
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :int
	 */
	public int updateByPrimaryKey(T model);

	/**
	 * 根据主键更新,更新所有数据,返回受影响行数
	 * 
	 * @param model
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :int
	 */
	public int updateByPrimaryKeyAll(T model);

	/**
	 * 根据主键删除,返回受影响行数
	 * 
	 * @param primaryKey
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :int
	 */
	public int deleteByPrimaryKey(Object primaryKey);

}
