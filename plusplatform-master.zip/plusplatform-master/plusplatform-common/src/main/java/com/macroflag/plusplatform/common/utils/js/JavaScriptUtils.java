package com.macroflag.plusplatform.common.utils.js;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * javaScriptEngineManager 工具类
 * 
 * @author : fredia
 * @since : 2017年10月18日
 * @version : v0.0.1
 */
public class JavaScriptUtils {
	private static Logger logger = LoggerFactory.getLogger(JavaScriptUtils.class);

	/**
	 * 执行函数，返回true OR false
	 * 
	 * @param js
	 * @return
	 * @author : fredia
	 * @since : 2017年10月18日
	 * @return :Object
	 */
	public static Object compare(String js) {
		ScriptEngineManager mgr = new ScriptEngineManager();
		ScriptEngine engine = mgr.getEngineByName("JavaScript");
		try {
			Object obj = engine.eval(js);
			return obj;
		} catch (ScriptException e) {
			e.printStackTrace();
			logger.error("js脚本执行出错");
		}
		return null;

	}
}
