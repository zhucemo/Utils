package com.macroflag.plusplatform.common.datasources;

/**
 * 数据源的切换与选择器
 * 
 * @author : fredia
 * @since : 2017年10月23日
 * @version : v0.0.1
 */
public class DatabaseContextHolder {

	private static final ThreadLocal<String> contextHolder = new ThreadLocal<String>();

	public static void setCustomerType(String customerType) {
		contextHolder.set(customerType);
	}

	public static String getCustomerType() {
		return contextHolder.get();
	}

	public static void clearCustomerType() {
		contextHolder.remove();
	}
}