package com.macroflag.plusplatform.common.web.util.model;

import java.io.Serializable;

/**
 * 创蓝短信通道配置model
 * 
 * @author : fredia
 * @since : 2017年11月13日
 * @version : v0.0.1
 */
public class ChuanglanSmsModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/* 应用地址 */
	private String url;
	/* 用户名 */
	private String username;
	/* 密码 */
	private String password;
	/* 签名 */
	private String sign;
	/* 是否需要状态报告，需要1，不需要0 */
	private String reportStatus;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getReportStatus() {
		return reportStatus;
	}

	public void setReportStatus(String reportStatus) {
		this.reportStatus = reportStatus;
	}

}
