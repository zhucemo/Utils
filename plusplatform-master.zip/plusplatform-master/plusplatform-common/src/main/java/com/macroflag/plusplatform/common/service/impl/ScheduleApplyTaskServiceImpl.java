package com.macroflag.plusplatform.common.service.impl;

import java.util.List;

import com.macroflag.plusplatform.common.core.service.impl.BaseServiceImpl;
import com.macroflag.plusplatform.common.entity.ScheduleApplyTaskDomain;
import com.macroflag.plusplatform.common.mapper.nongeneric.ScheduleApplyTaskMapper;
import com.macroflag.plusplatform.common.query.ScheduleApplyTaskQuery;
import com.macroflag.plusplatform.common.service.IScheduleApplyTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



/**
 * 申请记录任务表的业务实现类
 * 
 * @author : Fredia
 * @since : 2018年05月08日
 * @version : v0.0.1
 */
@Service("scheduleApplyTaskService")
public class ScheduleApplyTaskServiceImpl extends BaseServiceImpl<ScheduleApplyTaskDomain>
		implements IScheduleApplyTaskService {

	@Autowired
	private ScheduleApplyTaskMapper scheduleApplyTaskMapper;

	@Override
	public List<ScheduleApplyTaskDomain> getUpcomingList(ScheduleApplyTaskQuery query) {
		return	scheduleApplyTaskMapper.getUpcomingList(query);
	}


}
