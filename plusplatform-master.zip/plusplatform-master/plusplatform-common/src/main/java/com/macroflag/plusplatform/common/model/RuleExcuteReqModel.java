package com.macroflag.plusplatform.common.model;


import java.util.Map;

import com.macroflag.plusplatform.common.model.base.DataModelReqBase;


/**
 * 请求规则系统 json request对象
 * 
 * @author : Fredia
 * @since : 2018年3月6日
 * @version : v1.0.0
 */
public class RuleExcuteReqModel extends DataModelReqBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/* 业务参数集 */
	private Map<Object, Object> ruleParamMap;

	public Map<Object, Object> getRuleParamMap() {
		return ruleParamMap;
	}

	public void setRuleParamMap(Map<Object, Object> ruleParamMap) {
		this.ruleParamMap = ruleParamMap;
	}

}
