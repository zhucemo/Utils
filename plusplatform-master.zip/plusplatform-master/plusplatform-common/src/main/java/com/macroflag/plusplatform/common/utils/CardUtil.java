package com.macroflag.plusplatform.common.utils;

import java.util.Calendar;

/**
 * 身份证信息算法类
 *
 * @author : sugar
 * @version : v1.0.0
 * @since : 2018年5月18日
 */
public class CardUtil {

    /**
     * 18位性别判断
     *
     * @param card
     * @return :String
     * @author : Fredia
     * @since : 2018年5月18日
     */
    public static String getSex(String CardCode) {
        String sex;
        if (Integer.parseInt(CardCode.substring(16).substring(0, 1)) % 2 == 0) {// 判断性别
            sex = "女";
        } else {
            sex = "男";
        }
        return sex;
    }

    /**
     * 15位性别判断
     *
     * @param card
     * @return :String
     * @author : Fredia
     * @since : 2018年5月18日
     */
    public static String getSex15W(String card) {
        String usex = card.substring(14, 15);// 用户的性别
        String sex;
        if (Integer.parseInt(usex) % 2 == 0) {
            sex = "女";
        } else {
            sex = "男";
        }
        return sex;
    }

    public static String getAge(String card) {
        int ageYear = Integer.parseInt(card.substring(6, 10));
        int ageMonth = Integer.parseInt(card.substring(10, 12));
        Calendar calendar = Calendar.getInstance();
        int nowYear = calendar.get(Calendar.YEAR);
        int nowMonth = calendar.get(Calendar.MONTH);
        int age = nowYear - ageYear;
        if (nowMonth < ageMonth) {
            --age;
        }
        return String.valueOf(age);
    }
}
