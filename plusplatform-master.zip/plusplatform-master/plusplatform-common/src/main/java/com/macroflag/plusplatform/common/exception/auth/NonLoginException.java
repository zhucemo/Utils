
package com.macroflag.plusplatform.common.exception.auth;

import com.macroflag.plusplatform.common.constant.RestCodeConstants;
import com.macroflag.plusplatform.jwt.exception.BaseException;

/**
 * 用户token异常
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
public class NonLoginException extends BaseException {
	public NonLoginException(String message) {
		super(message, RestCodeConstants.EX_USER_INVALID_CODE);
	}
}
