package com.macroflag.plusplatform.common.core.json.model;

import java.io.Serializable;

/**
 * jsonp对象
 * @author : fredia
 * @email : trumpey@163.com
 * @since : 2017年11月15日
 * @version : v0.0.1
 */
public class JsonpModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * jsonp函数
	 */
	private String jsonpFunctionName;

	/**
	 * 返回结果
	 */
	private Object result;

	public JsonpModel(String jsonpFunctionName, Object result) {
		this.jsonpFunctionName = jsonpFunctionName;
		this.result = result;
	}

	public String getJsonpFunctionName() {
		return jsonpFunctionName;
	}

	public void setJsonpFunctionName(String jsonpFunctionName) {
		this.jsonpFunctionName = jsonpFunctionName;
	}

	public Object getResult() {
		return result;
	}

	public void setResult(Object result) {
		this.result = result;
	}

}
