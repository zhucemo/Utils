package com.macroflag.plusplatform.common.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 枚举服务的domain
 * @author : fredia
 * @since : 2018年04月24日
 * @version : v0.0.1
 */
public class CommonEnumsDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*id*/
	private Long id;
	
	/*编号*/
	private String code;
	
	/*名称*/
	private String name;
	
	/*中文描述*/
	private String description;
	
	/*0-顶级*/
	private Long parentId;
	
	/*是否启用*/
	private Integer isActive;
	
	/**/
	private Date createTime;
	
	/**/
	private Long createUser;
	
	/**/
	private Date updateTime;
	
	/**/
	private Long updateUser;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getCode(){
		return code;
	}
	
	public void setCode(String code){
		this.code = code;
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getDescription(){
		return description;
	}
	
	public void setDescription(String description){
		this.description = description;
	}
	
	public Long getParentId(){
		return parentId;
	}
	
	public void setParentId(Long parentId){
		this.parentId = parentId;
	}
	
	public Integer getIsActive(){
		return isActive;
	}
	
	public void setIsActive(Integer isActive){
		this.isActive = isActive;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	
}
