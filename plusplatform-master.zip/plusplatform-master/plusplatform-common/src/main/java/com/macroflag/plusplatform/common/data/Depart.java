
package com.macroflag.plusplatform.common.data;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 部门标示
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(value = { ElementType.METHOD, ElementType.TYPE })
public @interface Depart {
	String departField() default "depart_id";

	String userField() default "crt_user_id";
}
