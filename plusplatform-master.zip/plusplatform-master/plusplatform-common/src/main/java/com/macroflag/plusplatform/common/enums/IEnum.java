package com.macroflag.plusplatform.common.enums;

/**
 * 枚举访问定义
 * 
 * @author : Fredia
 * @since : 2018年4月19日
 * @version : v1.0.0
 */
public interface IEnum {
	int getValue();

	String getDescription();
}
