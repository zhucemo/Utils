
package com.macroflag.plusplatform.common.entity;

import java.util.Date;

import lombok.Data;

/**
 * 
 * 业务基类对象
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
@Data
public class BusinessEntity extends BaseEntity {
	private String crtUserId;
	private String crtUserName;
	private Date crtTime;

	private String updUserId;
	private String updUserName;
	private Date updTime;
}
