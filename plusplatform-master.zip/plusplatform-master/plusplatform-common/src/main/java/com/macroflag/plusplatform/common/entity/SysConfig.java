package com.macroflag.plusplatform.common.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.*;


/**
 * 
 * 
 * @author : Fredia
 * @email trumpey@163.com
 * @since : 2018-06-26 16:25:23
 * @version : v1.0.0
 */
@Table(name = "sys_config")
public class SysConfig implements Serializable {
	private static final long serialVersionUID = 1L;
	
	    //自增长主键
    @Id
    private Long id;
	
	    //系统参数key
    @Column(name = "config_key")
    private String configKey;
	
	    //系统参数value
    @Column(name = "config_value")
    private String configValue;
	

	/**
	 * 设置：自增长主键
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 获取：自增长主键
	 */
	public Long getId() {
		return id;
	}
	/**
	 * 设置：系统参数key
	 */
	public void setConfigKey(String configKey) {
		this.configKey = configKey;
	}
	/**
	 * 获取：系统参数key
	 */
	public String getConfigKey() {
		return configKey;
	}
	/**
	 * 设置：系统参数value
	 */
	public void setConfigValue(String configValue) {
		this.configValue = configValue;
	}
	/**
	 * 获取：系统参数value
	 */
	public String getConfigValue() {
		return configValue;
	}
}
