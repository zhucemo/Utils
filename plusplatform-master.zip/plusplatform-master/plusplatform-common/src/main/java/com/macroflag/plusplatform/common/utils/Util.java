package com.macroflag.plusplatform.common.utils;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


/**
 * @classname	Util
 * @description	(简要描述该文件作用)

 * @date		2013-9-23
 *
 */
public class Util {
	private static final ThreadLocal<DateFormat> DATE_FORMATTER1 = new ThreadLocal<DateFormat>() {
		@Override
		protected DateFormat initialValue() {
			return new SimpleDateFormat("yyyy-MM-dd");
		}
	};
	private static final ThreadLocal<DateFormat> DATE_FORMATTER2 = new ThreadLocal<DateFormat>() {
		@Override
		protected DateFormat initialValue() {
			return new SimpleDateFormat("yyyy/MM/dd");
		}
	};
	private static final ThreadLocal<DateFormat> DATE_FORMATTER3 = new ThreadLocal<DateFormat>() {
		@Override
		protected DateFormat initialValue() {
			return new SimpleDateFormat("yyyyMMdd");
		}
	};
	private static final ThreadLocal<DateFormat> DATETIME_FORMATTER1 = new ThreadLocal<DateFormat>() {
		@Override
		protected DateFormat initialValue() {
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		}
	};
	private static final ThreadLocal<DateFormat> DATETIME_FORMATTER2 = new ThreadLocal<DateFormat>() {
		@Override
		protected DateFormat initialValue() {
			return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		}
	};
	private static final ThreadLocal<DateFormat> DATETIME_FORMATTER3 = new ThreadLocal<DateFormat>() {
		@Override
		protected DateFormat initialValue() {
			return new SimpleDateFormat("yyyyMMddHHmmss");
		}
	};

	/**
	 * 
	 * @description	(获得date的年份)
	 * @param date
	 * @return
	 */
	public static int getYear(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.YEAR);
	}

	/**
	 * 
	 * @description	(获得date是星期几)
	 * @param date
	 * @return
	 * @throws Throwable
	 */
	public static int getWeek(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.DAY_OF_WEEK);
	}

	/**  
	* 计算两个日期之间相差的天数  
	* @param smdate 较小的时间 
	* @param bdate  较大的时间 
	* @return 相差天数 
	* @throws ParseException  
	*/
	public static int daysBetween(Date smdate, Date bdate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(smdate);
		long time1 = cal.getTimeInMillis();
		cal.setTime(bdate);
		long time2 = cal.getTimeInMillis();
		long between_days = (time2 - time1) / (1000 * 3600 * 24);
		return Integer.parseInt(String.valueOf(between_days));
	}

	/**
	 * 
	 * @description	(获得系统日期)
	 * @return
	 */
	public static Date getDate() {
		Calendar calendar = Calendar.getInstance();
		return calendar.getTime();
	}
	
	public static Date addDate(int field, Date date, int num) {
		if (date == null) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(field, num);
		return calendar.getTime();
	}

	public static Date addDate(Date date, int days) {
		return addDate(Calendar.DATE, date, days);
	}

	public static Date addMonth(Date date, int months) {
		return addDate(Calendar.MONTH, date, months);
	}

	public static Date addDate(Date date, BigDecimal days) {
		return addDate(date, days.intValue());
	}

	public static Date addMonth(Date date, BigDecimal months) {
		return addMonth(date, months.intValue());
	}

	public static String parseDateTimeToString(Date datetime) {
		if (datetime == null) {
			return null;
		}

		if (datetime.getTime() % 60 % 60 % 24 == 0) {
			return parseDateToString(datetime);
		} else {
			return parseTimeToString(datetime);
		}
	}

	public static String parseDateToString(Date date) {
		if (date == null) {
			return null;
		}

		try {
			return DATE_FORMATTER1.get().format(date);
		} catch (Exception e) {
			try {
				return DATE_FORMATTER2.get().format(date);
			} catch (Exception ex) {
				return DATE_FORMATTER3.get().format(date);
			}
		}
	}

	// 左补“0”
	public static String leftPad(int num, final int maxLen, char filledChar) {

		StringBuffer sb = new StringBuffer();
		String str = String.valueOf(num);

		for (int i = str.length(); i < maxLen; i++) {
			sb.append(filledChar);
		}

		return sb.append(str).toString();
	}

	public static String parseTimeToString(Date time) {
		if (time == null) {
			return null;
		}

		try {
			return DATETIME_FORMATTER1.get().format(time);
		} catch (Exception e) {
			try {
				return DATETIME_FORMATTER2.get().format(time);
			} catch (Exception ex) {
				return DATETIME_FORMATTER3.get().format(time);
			}
		}
	}

	public static Date parseStringToDate(String date) {
		if (date == null) {
			return null;
		}

		try {
			return DATE_FORMATTER1.get().parse(date);
		} catch (Exception e) {
			try {
				return DATE_FORMATTER2.get().parse(date);
			} catch (Exception ex) {
				try {
					return DATE_FORMATTER3.get().parse(date);
				} catch (ParseException pe) {
					throw new RuntimeException(pe);
				}
			}
		}
	}

	public static Date parseStringToDateTime(String date) {
		if (date == null) {
			return null;
		}

		try {
			return DATETIME_FORMATTER1.get().parse(date);
		} catch (Exception e) {
			try {
				return DATETIME_FORMATTER2.get().parse(date);
			} catch (Exception ex) {
				try {
					return DATETIME_FORMATTER3.get().parse(date);
				} catch (ParseException pe) {
					throw new RuntimeException(pe);
				}
			}
		}
	}

	public static Boolean parseYNToBoolean(Object yn) {
		return yn == null ? null : "Y".equalsIgnoreCase(yn.toString());
	}

	/**
	 * 把 true和false变成Y和N
	 * @param bool
	 * @return
	 */
	public static String parseBoolToYN(String bool) {
		return bool == null ? null : Boolean.parseBoolean(bool) ? "Y" :"N";
	}

	public static BigDecimal parseBigDecimal(Object value) {
		if (value instanceof BigDecimal) {
			try {
				return (BigDecimal) value;
			} catch (Exception e) {
				return null;
			}
		} else {
			if (value == null || "".equals(value.toString())) {
				return null;
			}
			try {
				return new BigDecimal(value.toString());
			} catch (Exception e) {
				return null;
			}
		}

	}

	public static Integer parseInteger(Object value) {
		if (value instanceof Integer) {
			try {
				return (Integer) value;
			} catch (Exception e) {
				return null;
			}
		} else {
			if (value == null || "".equals(value.toString())) {
				return null;
			}
			try {
				return new Integer(value.toString());
			} catch (Exception e) {
				return null;
			}
		}

	}

	/**
	 * 
	 * @description	(Object对象转换为String对象)
	 * @param object
	 * @return
	 */
	public static String parseObjectToString(Object object) {
		if (object == null) {
			return null;
		}

		if (object instanceof Date) {
			return parseDateTimeToString((Date) object);
		} else {
			return object.toString();
		}
	}

	/**
	 * 
	 * @description	(验证对象是否为空)
	 * @param obj
	 * @return
	 */
	public static boolean isObjectEmpty(Object obj) {
		return null == obj;
	}

	/**
	 * 
	 * @description	(验证字符串是否为空)
	 * @param str
	 * @return
	 */
	public static boolean isStringEmpty(String str) {
		return null == str || str.trim().length() == 0 || str.trim().equals("");
	}


	/**
	 * @description (验证两个变量是否相等)
	 * @param value
	 */
	public static boolean isEquals(Object aftValue, Object betValue) {
		if (aftValue == null && betValue == null) {
			return true;
		}
		if ((aftValue == null && betValue != null) || (aftValue != null && betValue == null)) {
			return false;
		}
		if (aftValue instanceof BigDecimal) {
			if (((BigDecimal) aftValue).compareTo((BigDecimal) betValue) == 0) {
				return true;
			}
		} else if (aftValue.equals(betValue)) {
			return true;
		}
		return false;
	}

	/**
	 * 
	 * @description	(数组元素拼接起来)
	 * @param args
	 * @return
	 */
	public static String buildString(Object... args) {
		if (args == null) {
			return null;
		}

		StringBuffer buffer = new StringBuffer();

		for (Object object : args) {
			if (object != null) {
				buffer.append(object);
			}
		}

		return buffer.toString();
	}

	/**
	 * 
	 * @description	(两个对象拼接起来)
	 * @param value1
	 * @param value2
	 * @return
	 */
	public static String contactString(Object value1, Object value2) {
		StringBuffer buffer = new StringBuffer();

		if (!isObjectEmpty(value1)) {
			buffer.append(value1);
		}
		if (!isObjectEmpty(value2)) {
			buffer.append(value2);
		}

		return buffer.toString();
	}

	/**
	 * 在字符串的大写字母前加“_”并把修改后的字符串转换成大写
	 * @param ss
	 * @return
	 */
	public static String cutLower(String ss) {
		StringBuffer sb = new StringBuffer();
		char[] a = ss.toCharArray();
		for (char c : a) {
			if (Character.isUpperCase(c)) {
				sb.append("_");
			}
			sb.append(Character.toUpperCase(c));
		}

		return sb.toString();
	}
}