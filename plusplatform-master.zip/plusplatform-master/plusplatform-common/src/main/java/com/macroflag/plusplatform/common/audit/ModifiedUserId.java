
package com.macroflag.plusplatform.common.audit;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 更改者ID
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(value = { ElementType.METHOD, ElementType.TYPE, ElementType.FIELD })
public @interface ModifiedUserId {
}
