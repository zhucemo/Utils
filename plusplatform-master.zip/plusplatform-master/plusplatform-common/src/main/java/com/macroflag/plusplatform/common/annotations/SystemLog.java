package com.macroflag.plusplatform.common.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 系统日志
 * 
 * @author : Fredia
 * @since : 2018年4月26日
 * @version : v1.0.0
 */
@Target({ ElementType.PARAMETER, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SystemLog {
	/**
	 * 模块名
	 * 
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月26日
	 * @return :String
	 */
	String module() default "";

	/**
	 * 执行方法名
	 * 
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月26日
	 * @return :String
	 */
	String methods() default "";

	/**
	 * 请求方式
	 * 
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月26日
	 * @return :RequestMethod
	 */
	RequestMethod requestMethod() default RequestMethod.GET;

	/**
	 * 是否为内部请求
	 * 
	 * @return
	 * @author : Fredia
	 * @since : 2018年4月26日
	 * @return :boolean
	 */
	boolean isInternal() default true;
}