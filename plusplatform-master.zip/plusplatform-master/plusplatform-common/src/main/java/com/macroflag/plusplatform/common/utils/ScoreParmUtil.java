package com.macroflag.plusplatform.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

public class ScoreParmUtil {

	public ScoreParmUtil() {

	}

	public static int scoreParamInit(Map<String, Object> parms) {
		Integer age = 0;
		try {
			age = AgeCalculate(parms.get("certificateCode").toString());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return age;
	}

	/**
	 * 年龄计算
	 * 
	 * @param identityCard
	 * @throws ParseException
	 */
	public static Integer AgeCalculate(String identityCard) throws ParseException {
		String year = null;
		String month = null;
		String day = null;
		String s_birthDay = null;
		year = identityCard.substring(6, identityCard.length() - 8);
		month = identityCard.substring(10, identityCard.length() - 6);
		day = identityCard.substring(12, identityCard.length() - 4);
		s_birthDay = year + "-" + month + "-" + day;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date birthDay = sdf.parse(s_birthDay);
		// 获取当前系统时间
		Calendar cal = Calendar.getInstance();
		// 如果出生日期大于当前时间，则抛出异常
		if (cal.before(birthDay)) {
			throw new IllegalArgumentException("The birthDay is before Now.It's unbelievable!");
		}
		// 取出系统当前时间的年、月、日部分
		int yearNow = cal.get(Calendar.YEAR);
		int monthNow = cal.get(Calendar.MONTH);
		int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);

		// 将日期设置为出生日期
		cal.setTime(birthDay);
		// 取出出生日期的年、月、日部分
		int yearBirth = cal.get(Calendar.YEAR);
		int monthBirth = cal.get(Calendar.MONTH);
		int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);
		// 当前年份与出生年份相减，初步计算年龄
		int age = yearNow - yearBirth;
		// 当前月份与出生日期的月份相比，如果月份小于出生月份，则年龄上减1，表示不满多少周岁
		if (monthNow <= monthBirth) {
			// 如果月份相等，在比较日期，如果当前日，小于出生日，也减1，表示不满多少周岁
			if (monthNow == monthBirth) {
				if (dayOfMonthNow < dayOfMonthBirth) {
					age--;
				}
			} else {
				age--;
			}
		}
		return age;
	}

	/**
	 * 年龄有效期计算
	 * 
	 * @param identityCard
	 * @return
	 * @throws ParseException
	 */
	public static Integer AgeValidity(String validity_date_begin, String identityCard) throws ParseException {
		String year = null;
		String month = null;
		String day = null;
		String s_birthDay = null;
		year = identityCard.substring(6, identityCard.length() - 8);
		month = identityCard.substring(10, identityCard.length() - 6);
		day = identityCard.substring(12, identityCard.length() - 4);
		s_birthDay = year + "-" + month + "-" + day;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date birthDay = sdf.parse(s_birthDay);
		// 获取当前系统时间
		Calendar cal = Calendar.getInstance();
		// 如果出生日期大于当前时间，则抛出异常
		if (cal.before(birthDay)) {
			throw new IllegalArgumentException("The birthDay is before Now.It's unbelievable!");
		}
		// 取出身份证有效期的年、月、日部分
		int yearNow = Integer.parseInt(validity_date_begin.split("\\.")[0]);
		int monthNow = Integer.parseInt(validity_date_begin.split("\\.")[1]);
		int dayOfMonthNow = Integer.parseInt(validity_date_begin.split("\\.")[2]);

		// 将日期设置为出生日期
		cal.setTime(birthDay);
		// 取出出生日期的年、月、日部分
		int yearBirth = cal.get(Calendar.YEAR);
		int monthBirth = cal.get(Calendar.MONTH) + 1;
		int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);
		// 当前年份与出生年份相减，初步计算年龄
		int age = yearNow - yearBirth;
		// 当前月份与出生日期的月份相比，如果月份小于出生月份，则年龄上减1，表示不满多少周岁
		if (monthNow <= monthBirth) {
			// 如果月份相等，在比较日期，如果当前日，小于出生日，也减1，表示不满多少周岁
			if (monthNow == monthBirth) {
				if (dayOfMonthNow < dayOfMonthBirth) {
					age--;
				}
			} else {
				age--;
			}
		}
		return age;
	}

	public static void main(String[] args) {
		try {
			int age = AgeValidity("2008.1.8", "210001199002089911");
			System.out.println(age);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
