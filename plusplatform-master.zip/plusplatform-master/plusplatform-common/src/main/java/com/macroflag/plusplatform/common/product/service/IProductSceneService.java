package com.macroflag.plusplatform.common.product.service;


import com.macroflag.plusplatform.common.core.service.IBaseService;
import com.macroflag.plusplatform.common.entity.ProductSceneDomain;

/**
 * 产品场景表的业务层接口
 * @author : fredia
 * @since : 2018年04月27日
 * @version : v0.0.1
 */
public interface IProductSceneService extends IBaseService<ProductSceneDomain> {

}
