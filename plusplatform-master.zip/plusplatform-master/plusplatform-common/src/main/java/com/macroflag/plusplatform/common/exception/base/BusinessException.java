
package com.macroflag.plusplatform.common.exception.base;

import com.macroflag.plusplatform.common.constant.RestCodeConstants;
import com.macroflag.plusplatform.jwt.exception.BaseException;

/**
 * 业务异常基础类
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
public class BusinessException extends BaseException {
	public BusinessException(String message) {
		super(message, RestCodeConstants.EX_BUSINESS_BASE_CODE);
	}
}
