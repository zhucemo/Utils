package com.macroflag.plusplatform.common.entity;

import java.io.Serializable;
import java.util.Date;

/**
 * 申请记录任务表的domain
 * @author : Fredia
 * @since : 2018年05月08日
 * @version : v0.0.1
 */
public class ScheduleApplyTaskDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/**/
	private Long id;
	
	/*申请单号*/
	private String applyNo;
	
	/*用户唯一标示*/
	private String uniqueNo;
	
	/*产品编号*/
	private String productName;
	
	/*是否异步0-否，1-是*/
	private Integer isAync;
	
	/*该任务状态0-待执行，1-执行中，2-已完成，3-异常*/
	private Integer status;
	
	/*尝试次数*/
	private Long retryTimes;
	
	/**/
	private Long maxTimes;
	
	/*权重*/
	private Long weights;
	
	/**/
	private String spare1;
	
	/**/
	private String spare2;
	
	/**/
	private String spare3;
	
	/**/
	private String spare4;
	
	/*创建时间*/
	private Date createTime;
	
	/**/
	private Long createUser;
	
	/**/
	private Date updateTime;
	
	/**/
	private Long updateUser;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getApplyNo(){
		return applyNo;
	}
	
	public void setApplyNo(String applyNo){
		this.applyNo = applyNo;
	}
	
	public String getUniqueNo(){
		return uniqueNo;
	}
	
	public void setUniqueNo(String uniqueNo){
		this.uniqueNo = uniqueNo;
	}
	
	public String getProductName(){
		return productName;
	}
	
	public void setProductName(String productName){
		this.productName = productName;
	}
	
	public Integer getIsAync(){
		return isAync;
	}
	
	public void setIsAync(Integer isAync){
		this.isAync = isAync;
	}
	
	public Integer getStatus(){
		return status;
	}
	
	public void setStatus(Integer status){
		this.status = status;
	}
	
	public Long getRetryTimes(){
		return retryTimes;
	}
	
	public void setRetryTimes(Long retryTimes){
		this.retryTimes = retryTimes;
	}
	
	public Long getMaxTimes(){
		return maxTimes;
	}
	
	public void setMaxTimes(Long maxTimes){
		this.maxTimes = maxTimes;
	}
	
	public Long getWeights(){
		return weights;
	}
	
	public void setWeights(Long weights){
		this.weights = weights;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public Long getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(Long createUser){
		this.createUser = createUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	public Long getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(Long updateUser){
		this.updateUser = updateUser;
	}
	
	
}
