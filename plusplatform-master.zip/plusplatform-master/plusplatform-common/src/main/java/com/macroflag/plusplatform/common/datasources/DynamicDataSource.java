package com.macroflag.plusplatform.common.datasources;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

/**
 * 配置选择数据源
 * 
 * @author : fredia
 * @since : 2017年10月23日
 * @version : v0.0.1
 */
public class DynamicDataSource extends AbstractRoutingDataSource {

	@Override
	protected Object determineCurrentLookupKey() {
		return DatabaseContextHolder.getCustomerType();
	}

}