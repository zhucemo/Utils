package com.macroflag.plusplatform.common.mapper.nongeneric;

import com.macroflag.plusplatform.common.entity.BankDomain;
import com.macroflag.plusplatform.common.mapper.Mapper;

/**
 * 银行表的mapper
 * @author : Fredia
 * @since : 2018年04月27日
 * @version : v0.0.1
 */
public interface BankMapper extends Mapper<BankDomain> {
	
}
