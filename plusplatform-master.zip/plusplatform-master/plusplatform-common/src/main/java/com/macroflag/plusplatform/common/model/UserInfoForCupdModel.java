package com.macroflag.plusplatform.common.model;

import java.io.Serializable;


/**
 * 查询CQ3所需要的客户信息实体类
 * @author huangf
 *
 */
public class UserInfoForCupdModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String cupdApplyNo;
	
	private String lbsProvince;
	
	private String lbsCity;
	
	private String lbsRelateUserNumLatestAWeek;
	
	private String lbsRelateUserNumLatestAMonth;
	
	private String idNomalCheck;
	
	private String validDateBegin;
	
	private String validDateEnd;
	
	private String authority;
	
	private String censusRegisterAddress;

	private String huotiResult;
	
	private String synFaceConfidence;
	
	private String gongAnIDFaceconfidence;
	
	private String gongAnIDFacethresholdE3;
	
	private String gongAnIDFacethresholdE4;
	
	private String gongAnIDFacethresholdE5;
	
	private String gongAnIDFacethresholdE6;
	
	private String iDAttacked;
	
	private String iDPhotoColor;
	
	private String iDFaceconfidence;
	
	private String iDFacethresholdE3;
	
	private String iDFacethresholdE4;
	
	private String iDFacethresholdE5;
	
	private String iDFacethresholdE6;
	
	private String cardtoaddType;
	
	private String cardtoaddprovname;
	
	private String cardtoaddcityname;
	
	private String cardtoadddistname;
	
	private String cardtoaddressname;
	
	private String dirContactName;
	
	private String dirContactRelations;
	
	private String dirContactPhoneNo;
	
	private String otherContactName;
	
	private String otherContactRelations;
	
	private String otherContactPhoneNo;
	
	private String period;
	
	private String enName;
	
	private String educAtion;
	
	private String maritalStatus;
	
	private String homeSituaTion;

	private String homeAddProvName;
	
	private String homeAddCityName;
	
	private String homeAddDistName;
	
	private String homeAddRessName;
	
	private String company;
	
	private String companyAddProvName;
	
	private String companyAddCityName;
	
	private String companyAddDistName;
	
	private String companyAddRessName;
	
	private String companyType;
	
	private String industryCategory;
	
	private String companyDuty;
	
	private String yearsEmployed;
	
	private String companyArea;
	
	private String companyPhone;
	
	private String companyExt;
	
	private String email;
	
	private Float salary;
	
	public String getCupdApplyNo() {
		return cupdApplyNo;
	}

	public void setCupdApplyNo(String cupdApplyNo) {
		this.cupdApplyNo = cupdApplyNo;
	}

	public String getLbsProvince() {
		return lbsProvince;
	}

	public void setLbsProvince(String lbsProvince) {
		this.lbsProvince = lbsProvince;
	}

	public String getLbsCity() {
		return lbsCity;
	}

	public void setLbsCity(String lbsCity) {
		this.lbsCity = lbsCity;
	}

	public String getLbsRelateUserNumLatestAWeek() {
		return lbsRelateUserNumLatestAWeek;
	}

	public void setLbsRelateUserNumLatestAWeek(String lbsRelateUserNumLatestAWeek) {
		this.lbsRelateUserNumLatestAWeek = lbsRelateUserNumLatestAWeek;
	}

	public String getLbsRelateUserNumLatestAMonth() {
		return lbsRelateUserNumLatestAMonth;
	}

	public void setLbsRelateUserNumLatestAMonth(String lbsRelateUserNumLatestAMonth) {
		this.lbsRelateUserNumLatestAMonth = lbsRelateUserNumLatestAMonth;
	}

	public String getIdNomalCheck() {
		return idNomalCheck;
	}

	public void setIdNomalCheck(String idNomalCheck) {
		this.idNomalCheck = idNomalCheck;
	}

	public String getValidDateBegin() {
		return validDateBegin;
	}

	public void setValidDateBegin(String validDateBegin) {
		this.validDateBegin = validDateBegin;
	}

	public String getValidDateEnd() {
		return validDateEnd;
	}

	public void setValidDateEnd(String validDateEnd) {
		this.validDateEnd = validDateEnd;
	}

	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

	public String getCensusRegisterAddress() {
		return censusRegisterAddress;
	}

	public void setCensusRegisterAddress(String censusRegisterAddress) {
		this.censusRegisterAddress = censusRegisterAddress;
	}

	public String getHuotiResult() {
		return huotiResult;
	}

	public void setHuotiResult(String huotiResult) {
		this.huotiResult = huotiResult;
	}

	public String getSynFaceConfidence() {
		return synFaceConfidence;
	}

	public void setSynFaceConfidence(String synFaceConfidence) {
		this.synFaceConfidence = synFaceConfidence;
	}

	public String getGongAnIDFaceconfidence() {
		return gongAnIDFaceconfidence;
	}

	public void setGongAnIDFaceconfidence(String gongAnIDFaceconfidence) {
		this.gongAnIDFaceconfidence = gongAnIDFaceconfidence;
	}

	public String getGongAnIDFacethresholdE3() {
		return gongAnIDFacethresholdE3;
	}

	public void setGongAnIDFacethresholdE3(String gongAnIDFacethresholdE3) {
		this.gongAnIDFacethresholdE3 = gongAnIDFacethresholdE3;
	}

	public String getGongAnIDFacethresholdE4() {
		return gongAnIDFacethresholdE4;
	}

	public void setGongAnIDFacethresholdE4(String gongAnIDFacethresholdE4) {
		this.gongAnIDFacethresholdE4 = gongAnIDFacethresholdE4;
	}

	public String getGongAnIDFacethresholdE5() {
		return gongAnIDFacethresholdE5;
	}

	public void setGongAnIDFacethresholdE5(String gongAnIDFacethresholdE5) {
		this.gongAnIDFacethresholdE5 = gongAnIDFacethresholdE5;
	}

	public String getGongAnIDFacethresholdE6() {
		return gongAnIDFacethresholdE6;
	}

	public void setGongAnIDFacethresholdE6(String gongAnIDFacethresholdE6) {
		this.gongAnIDFacethresholdE6 = gongAnIDFacethresholdE6;
	}

	public String getiDAttacked() {
		return iDAttacked;
	}

	public void setiDAttacked(String iDAttacked) {
		this.iDAttacked = iDAttacked;
	}

	public String getiDPhotoColor() {
		return iDPhotoColor;
	}

	public void setiDPhotoColor(String iDPhotoColor) {
		this.iDPhotoColor = iDPhotoColor;
	}

	public String getiDFaceconfidence() {
		return iDFaceconfidence;
	}

	public void setiDFaceconfidence(String iDFaceconfidence) {
		this.iDFaceconfidence = iDFaceconfidence;
	}

	public String getiDFacethresholdE3() {
		return iDFacethresholdE3;
	}

	public void setiDFacethresholdE3(String iDFacethresholdE3) {
		this.iDFacethresholdE3 = iDFacethresholdE3;
	}

	public String getiDFacethresholdE4() {
		return iDFacethresholdE4;
	}

	public void setiDFacethresholdE4(String iDFacethresholdE4) {
		this.iDFacethresholdE4 = iDFacethresholdE4;
	}

	public String getiDFacethresholdE5() {
		return iDFacethresholdE5;
	}

	public void setiDFacethresholdE5(String iDFacethresholdE5) {
		this.iDFacethresholdE5 = iDFacethresholdE5;
	}

	public String getiDFacethresholdE6() {
		return iDFacethresholdE6;
	}

	public void setiDFacethresholdE6(String iDFacethresholdE6) {
		this.iDFacethresholdE6 = iDFacethresholdE6;
	}

	public String getCardtoaddType() {
		return cardtoaddType;
	}

	public void setCardtoaddType(String cardtoaddType) {
		this.cardtoaddType = cardtoaddType;
	}

	public String getCardtoaddprovname() {
		return cardtoaddprovname;
	}

	public void setCardtoaddprovname(String cardtoaddprovname) {
		this.cardtoaddprovname = cardtoaddprovname;
	}

	public String getCardtoaddcityname() {
		return cardtoaddcityname;
	}

	public void setCardtoaddcityname(String cardtoaddcityname) {
		this.cardtoaddcityname = cardtoaddcityname;
	}

	public String getCardtoadddistname() {
		return cardtoadddistname;
	}

	public void setCardtoadddistname(String cardtoadddistname) {
		this.cardtoadddistname = cardtoadddistname;
	}

	public String getCardtoaddressname() {
		return cardtoaddressname;
	}

	public void setCardtoaddressname(String cardtoaddressname) {
		this.cardtoaddressname = cardtoaddressname;
	}

	public String getDirContactName() {
		return dirContactName;
	}

	public void setDirContactName(String dirContactName) {
		this.dirContactName = dirContactName;
	}

	public String getDirContactRelations() {
		return dirContactRelations;
	}

	public void setDirContactRelations(String dirContactRelations) {
		this.dirContactRelations = dirContactRelations;
	}

	public String getDirContactPhoneNo() {
		return dirContactPhoneNo;
	}

	public void setDirContactPhoneNo(String dirContactPhoneNo) {
		this.dirContactPhoneNo = dirContactPhoneNo;
	}

	public String getOtherContactName() {
		return otherContactName;
	}

	public void setOtherContactName(String otherContactName) {
		this.otherContactName = otherContactName;
	}

	public String getOtherContactRelations() {
		return otherContactRelations;
	}

	public void setOtherContactRelations(String otherContactRelations) {
		this.otherContactRelations = otherContactRelations;
	}

	public String getOtherContactPhoneNo() {
		return otherContactPhoneNo;
	}

	public void setOtherContactPhoneNo(String otherContactPhoneNo) {
		this.otherContactPhoneNo = otherContactPhoneNo;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getEnName() {
		return enName;
	}

	public void setEnName(String enName) {
		this.enName = enName;
	}

	public String getEducAtion() {
		return educAtion;
	}

	public void setEducAtion(String educAtion) {
		this.educAtion = educAtion;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getHomeSituaTion() {
		return homeSituaTion;
	}

	public void setHomeSituaTion(String homeSituaTion) {
		this.homeSituaTion = homeSituaTion;
	}

	public String getHomeAddProvName() {
		return homeAddProvName;
	}

	public void setHomeAddProvName(String homeAddProvName) {
		this.homeAddProvName = homeAddProvName;
	}

	public String getHomeAddCityName() {
		return homeAddCityName;
	}

	public void setHomeAddCityName(String homeAddCityName) {
		this.homeAddCityName = homeAddCityName;
	}

	public String getHomeAddDistName() {
		return homeAddDistName;
	}

	public void setHomeAddDistName(String homeAddDistName) {
		this.homeAddDistName = homeAddDistName;
	}

	public String getHomeAddRessName() {
		return homeAddRessName;
	}

	public void setHomeAddRessName(String homeAddRessName) {
		this.homeAddRessName = homeAddRessName;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCompanyAddProvName() {
		return companyAddProvName;
	}

	public void setCompanyAddProvName(String companyAddProvName) {
		this.companyAddProvName = companyAddProvName;
	}

	public String getCompanyAddCityName() {
		return companyAddCityName;
	}

	public void setCompanyAddCityName(String companyAddCityName) {
		this.companyAddCityName = companyAddCityName;
	}

	public String getCompanyAddDistName() {
		return companyAddDistName;
	}

	public void setCompanyAddDistName(String companyAddDistName) {
		this.companyAddDistName = companyAddDistName;
	}

	public String getCompanyAddRessName() {
		return companyAddRessName;
	}

	public void setCompanyAddRessName(String companyAddRessName) {
		this.companyAddRessName = companyAddRessName;
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public String getIndustryCategory() {
		return industryCategory;
	}

	public void setIndustryCategory(String industryCategory) {
		this.industryCategory = industryCategory;
	}

	public String getCompanyDuty() {
		return companyDuty;
	}

	public void setCompanyDuty(String companyDuty) {
		this.companyDuty = companyDuty;
	}

	public String getYearsEmployed() {
		return yearsEmployed;
	}

	public void setYearsEmployed(String yearsEmployed) {
		this.yearsEmployed = yearsEmployed;
	}

	public String getCompanyArea() {
		return companyArea;
	}

	public void setCompanyArea(String companyArea) {
		this.companyArea = companyArea;
	}

	public String getCompanyPhone() {
		return companyPhone;
	}

	public void setCompanyPhone(String companyPhone) {
		this.companyPhone = companyPhone;
	}

	public String getCompanyExt() {
		return companyExt;
	}

	public void setCompanyExt(String companyExt) {
		this.companyExt = companyExt;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Float getSalary() {
		return salary;
	}

	public void setSalary(Float salary) {
		this.salary = salary;
	}

}
