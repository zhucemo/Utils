
package com.macroflag.plusplatform.common.entity;

import java.io.Serializable;

import javax.persistence.Id;

import lombok.Data;

/**
 * 基础entity
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
@Data
public class BaseEntity implements Serializable {
	@Id
	private Object id;
	private Boolean deleteFlag;
}
