package com.macroflag.plusplatform.common.web;

import java.io.Serializable;

import com.wordnik.swagger.annotations.ApiModelProperty;

/**
 * 统一返回体 先根据code是否200 再判断showMsg true提示message false 取data
 * 
 * @author : Fredia
 * @since : 2018年4月16日
 * @version : v1.0.0
 */
public class ResultResponse implements Serializable {

	private static final long serialVersionUID = -1440428414934837551L;
	/**
	 * 正常 200
	 */
	@ApiModelProperty("成功代码")
	private int code;

	/**
	 * 返回消息
	 */
	@ApiModelProperty("返回消息")
	private String message;

	/**
	 * 数据
	 */
	@ApiModelProperty("返回数据")
	private Object data;

	/**
	 * 是否提示message true false
	 */
	@ApiModelProperty("是否提示message")
	private Boolean showMsg;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public Boolean isShowMsg() {
		return showMsg;
	}

	public void setShowMsg(Boolean showMsg) {
		this.showMsg = showMsg;
	}

	public ResultResponse() {
	}

	public ResultResponse(int code, String message) {
		this.code = code;
		this.message = message;
	}

	public ResultResponse(int code, String message, Boolean showMsg) {
		this.code = code;
		this.message = message;
		this.showMsg = showMsg;
	}

	public ResultResponse(int code, String message, Object data) {
		this.code = code;
		this.message = message;
		this.data = data;
	}

	public ResultResponse(int code, String message, Object data, boolean showMsg) {
		this.code = code;
		this.message = message;
		this.data = data;
		this.showMsg = showMsg;
	}
}
