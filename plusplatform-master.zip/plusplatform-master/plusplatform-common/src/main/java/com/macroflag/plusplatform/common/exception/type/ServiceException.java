package com.macroflag.plusplatform.common.exception.type;

/**
 * 服务异常
 * 
 * @author : fredia
 * @since : 2017年11月2日
 * @version : v0.0.1
 */
public class ServiceException extends RuntimeException {

	public ServiceException(String message) {
		super(message);
	}
}
