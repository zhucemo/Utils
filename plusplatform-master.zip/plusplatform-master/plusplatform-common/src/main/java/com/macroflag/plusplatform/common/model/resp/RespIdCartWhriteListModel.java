package com.macroflag.plusplatform.common.model.resp;

import com.macroflag.plusplatform.common.model.resp.base.BaseModel;

public class RespIdCartWhriteListModel extends BaseModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
