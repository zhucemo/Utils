package com.macroflag.plusplatform.common.component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.macroflag.plusplatform.common.cache.RedisCache;
import com.macroflag.plusplatform.common.entity.SysConfig;
import com.macroflag.plusplatform.common.mapper.nongeneric.SysConfigMapper;
import com.macroflag.plusplatform.common.utils.GlobalConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class SysConfigCache {

    @Autowired
    private RedisCache redisCache;

    @Autowired
    private SysConfigMapper sysConfigMapper;


    public String getSysConfig(String key) {
        JSONObject result = JSON.parseObject(redisCache.getCache("sysConfig"));
        String value = result.getString(key);
        if (value == null) {
            SysConfig sysConfig = sysConfigMapper.getOneByKey(key);
            if (sysConfig == null) {
                value = GlobalConstant.getString(key);
            } else {
                value = sysConfig.getConfigValue();
            }
        }
        return value;
    }

    public void refreshSysConfig() {
        List<SysConfig> sysList = sysConfigMapper.findAll();
        JSONObject mfSysConfig = new JSONObject();
        sysList.forEach(it ->
                mfSysConfig.put(it.getConfigKey(), it.getConfigValue()));
        redisCache.putCache("sysConfig", JSON.toJSONString(mfSysConfig));
    }
}
