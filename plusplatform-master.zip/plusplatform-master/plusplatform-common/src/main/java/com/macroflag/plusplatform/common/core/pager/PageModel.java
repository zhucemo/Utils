package com.macroflag.plusplatform.common.core.pager;

import java.io.Serializable;
import java.util.List;

/**
 * 分页模型处理
 * 
 * @author : fredia
 * @email : trumpey@163.com
 * @since : 2017年11月15日
 * @version : v0.0.1
 */
@SuppressWarnings("unused")
public class PageModel<T> implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/* 分页大小 */
	private int pageSize = 10;
	/* 当前页索引 */
	private int pageIndex = 1;
	/* 首页索引 */
	private int firstPage = 1;
	/* 尾页索引 */
	private int lastPage;
	/* 上一页索引 */
	private int prevPage;
	/* 下一页索引 */
	private int nextPage;
	/* 当前页开始行索引 */
	private long startRowIndex;
	/* 当前页结束行索引 */
	private long endRowIndex;
	/* 总记录数 */
	private long totalRecord = 0L;
	/* 总页数 */
	private Integer totalPage = 0;
	/* 是否首页 */
	private boolean isFirstPage;
	/* 是否尾页 */
	private boolean isLastPage;
	/* 是否有上一页 */
	private boolean hasPrePage;
	/* 是否有下一页 */
	private boolean hasNextPage;
	/* 本页数据对象列表 */
	private List<T> list;

	public PageModel() {
		super();
	}

	public PageModel(List<T> list, int pageIndex, int pageSize, long totalRecord) {
		this.pageIndex = pageIndex;
		this.pageSize = pageSize;
		this.totalRecord = totalRecord;
		this.list = list;
		this.calculate();
	}

	/**
	 * 属性计算
	 * 
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :void
	 */
	private void calculate() {
		startRowIndex = (long) ((pageIndex - 1) * pageSize + 1);
		endRowIndex = (long) (pageIndex * pageSize + 1);
		totalPage = (int) ((totalRecord % pageSize == 0) ? totalRecord / pageSize : totalRecord / pageSize + 1);
		pageIndex = pageIndex >= totalPage ? totalPage : pageIndex;
		lastPage = totalPage;
		prevPage = (int) (pageIndex <= 1L ? 1L : pageIndex - 1);
		nextPage = pageIndex >= totalPage ? totalPage : pageIndex + 1;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize <= 0 ? 10 : pageSize;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public int getFirstPage() {
		return firstPage;
	}

	public void setFirstPage(int firstPage) {
		this.firstPage = firstPage;
	}

	public int getLastPage() {
		return lastPage;
	}

	public void setLastPage(int lastPage) {
		this.lastPage = lastPage;
	}

	public int getPrevPage() {
		if (isFirstPage()) {
			return pageIndex;
		} else {
			return pageIndex - 1;
		}
	}

	public void setPrevPage(int prevPage) {
		this.prevPage = prevPage;
	}

	public int getNextPage() {
		if (isLastPage()) {
			return pageIndex;
		} else {
			return pageIndex + 1;
		}
	}

	public void setNextPage(int nextPage) {
		this.nextPage = nextPage;
	}

	public long getStartRowIndex() {
		return startRowIndex;
	}

	public void setStartRowIndex(long startRowIndex) {
		this.startRowIndex = startRowIndex;
	}

	public long getEndRowIndex() {
		return endRowIndex;
	}

	public void setEndRowIndex(long endRowIndex) {
		this.endRowIndex = endRowIndex;
	}

	public long getTotalRecord() {
		return totalRecord;
	}

	public void setTotalRecord(long totalRecord) {
		this.totalRecord = totalRecord;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	public boolean isFirstPage() {
		return pageIndex == 1;
	}

	public boolean isLastPage() {
		return pageIndex == totalPage;
	}

	public boolean isHasPrePagee() {
		return pageIndex > 1 && pageIndex <= totalPage;
	}

	public boolean isHasNextPage() {
		return pageIndex >= 1 && pageIndex < totalPage;
	}

	public List<T> getList() {
		return list;
	}

	public void setList(List<T> list) {
		this.list = list;
	}

}
