package com.macroflag.plusplatform.common.model;

import java.io.InputStream;

/**
 * 公共文件返回信息模型处理
 * 
 * @author : Fredia
 * @since : 2018年3月6日
 * @version : v1.0.0
 */
public class CommoneFileModel {

	/* oss 资源id */
	private Long ossId;

	/* 资源域名 */
	private String resourceDomainName;

	/* 资源相对路径 */
	private String url;

	/* aliyun OSS 上传后OSSObject 的唯一标识 */
	private String eTag;

	/* 回调返回的消息体，需要close 默认不处理 */
	private InputStream inputStream;

	public CommoneFileModel() {
		super();
	}

	public CommoneFileModel(Long ossId, String resourceDomainName, String url, String eTag, InputStream inputStream) {
		super();
		this.ossId = ossId;
		this.resourceDomainName = resourceDomainName;
		this.url = url;
		this.eTag = eTag;
		this.inputStream = inputStream;
	}

	public Long getOssId() {
		return ossId;
	}

	public void setOssId(Long ossId) {
		this.ossId = ossId;
	}

	public String getResourceDomainName() {
		return resourceDomainName;
	}

	public void setResourceDomainName(String resourceDomainName) {
		this.resourceDomainName = resourceDomainName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String geteTag() {
		return eTag;
	}

	public void seteTag(String eTag) {
		this.eTag = eTag;
	}

	public InputStream getInputStream() {
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

}
