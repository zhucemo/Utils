package com.macroflag.plusplatform.common.core;

import java.util.List;

import com.google.common.collect.Lists;

/**
 * 验证结果
 * 
 * @author : fredia
 * @email : trumpey@163.com
 * @since : 2017年11月16日
 * @version : v0.0.1
 */
public class ValidateResponse {
	/**
	 * 验证成功
	 */
	private static final Integer OK = 1;
	/**
	 * 验证失败
	 */
	private static final Integer FAIL = 0;

	private List<Object> results = Lists.newArrayList();

	private ValidateResponse() {
	}

	public static ValidateResponse newInstance() {
		return new ValidateResponse();
	}

	/**
	 * 验证成功（使用前台alertTextOk定义的消息）
	 * 
	 * @param fieldId
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :void
	 */
	public void validateFail(String fieldId) {
		validateFail(fieldId, "");
	}

	/**
	 * 验证成功
	 * 
	 * @param fieldId
	 *            验证成功的字段名
	 * @param message
	 *            验证成功时显示的消息
	 * @since : 2016年11月17日
	 * @author : fredia
	 */
	public void validateFail(String fieldId, String message) {
		results.add(new Object[] { fieldId, FAIL, message });
	}

	/**
	 * 验证成功（使用前台alertTextOk定义的消息）
	 * 
	 * @param fieldId
	 *            验证成功的字段名
	 * @since : 2016年11月17日
	 * @author : fredia
	 */
	public void validateSuccess(String fieldId) {
		validateSuccess(fieldId, "");
	}

	/**
	 * 验证成功
	 * 
	 * @param fieldId
	 * @param message
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :void
	 */
	public void validateSuccess(String fieldId, String message) {
		results.add(new Object[] { fieldId, OK, message });
	}

	/**
	 * 返回验证结果
	 * 
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :Object
	 */
	public Object result() {
		if (results.size() == 1) {
			return results.get(0);
		}
		return results;
	}
}
