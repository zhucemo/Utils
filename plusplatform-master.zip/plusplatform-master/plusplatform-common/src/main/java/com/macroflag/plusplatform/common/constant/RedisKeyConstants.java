
package com.macroflag.plusplatform.common.constant;

/**
 * Redis主键枚举类
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
public class RedisKeyConstants {
	public final static String USER_DEPART_PREFIX = "USER:DEPART";
	public final static String ZUUL_ROUTE_KEY = "ZUUL:ROUTE";
	public final static String USER_DISABLE = ":dis:";
	public final static String USER_ABLE = ":able:";
	public final static String PHONE_60S_VERIFY = "PHONE:60s:";
}
