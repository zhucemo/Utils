
package com.macroflag.plusplatform.common.exception.auth;

import com.macroflag.plusplatform.common.constant.RestCodeConstants;
import com.macroflag.plusplatform.jwt.exception.BaseException;

/**
 * Client 认证异常
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
public class ClientInvalidException extends BaseException {
	public ClientInvalidException(String message) {
		super(message, RestCodeConstants.EX_CLIENT_INVALID_CODE);
	}
}
