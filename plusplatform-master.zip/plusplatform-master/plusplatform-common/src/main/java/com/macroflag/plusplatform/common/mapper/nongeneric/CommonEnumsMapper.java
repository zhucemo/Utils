package com.macroflag.plusplatform.common.mapper.nongeneric;

import com.macroflag.plusplatform.common.entity.CommonEnumsDomain;
import com.macroflag.plusplatform.common.mapper.Mapper;

/**
 * 枚举服务的mapper
 * @author : fredia
 * @since : 2018年04月24日
 * @version : v0.0.1
 */
public interface CommonEnumsMapper extends Mapper<CommonEnumsDomain> {
	
}
