package com.macroflag.plusplatform.common.entity;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * 产品场景表的domain
 * @author : fredia
 * @since : 2018年05月08日
 * @version : v0.0.1
 */
public class ProductSceneDomain implements Serializable {

	private static final long serialVersionUID = 1L;
	
	/*id*/
	private Long id;
	
	/*产品编号*/
	private String productNo;
	
	/*场景名称*/
	private String sceneName;
	
	/*场景编号*/
	private String sceneNo;
	
	/*备注*/
	private String remark;
	
	/**/
	private String spare1;
	
	/*备用2*/
	private String spare2;
	
	/*备用3*/
	private String spare3;
	
	/*备用4*/
	private String spare4;
	
	/*当前是否有效,1-有效，0-无效*/
	private Integer isActive;
	
	/**/
	@JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;
	
	/**/
	private String createUser;
	
	/**/
	@JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updateTime;
	
	/**/
	private String updateUser;
	
	public Long getId(){
		return id;
	}
	
	public void setId(Long id){
		this.id = id;
	}
	
	public String getProductNo(){
		return productNo;
	}
	
	public void setProductNo(String productNo){
		this.productNo = productNo;
	}
	
	public String getSceneName(){
		return sceneName;
	}
	
	public void setSceneName(String sceneName){
		this.sceneName = sceneName;
	}
	
	public String getSceneNo(){
		return sceneNo;
	}
	
	public void setSceneNo(String sceneNo){
		this.sceneNo = sceneNo;
	}
	
	public String getRemark(){
		return remark;
	}
	
	public void setRemark(String remark){
		this.remark = remark;
	}
	
	public String getSpare1(){
		return spare1;
	}
	
	public void setSpare1(String spare1){
		this.spare1 = spare1;
	}
	
	public String getSpare2(){
		return spare2;
	}
	
	public void setSpare2(String spare2){
		this.spare2 = spare2;
	}
	
	public String getSpare3(){
		return spare3;
	}
	
	public void setSpare3(String spare3){
		this.spare3 = spare3;
	}
	
	public String getSpare4(){
		return spare4;
	}
	
	public void setSpare4(String spare4){
		this.spare4 = spare4;
	}
	
	public Integer getIsActive(){
		return isActive;
	}
	
	public void setIsActive(Integer isActive){
		this.isActive = isActive;
	}
	
	public Date getCreateTime(){
		return createTime;
	}
	
	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}
	
	public String getCreateUser(){
		return createUser;
	}
	
	public void setCreateUser(String createUser){
		this.createUser = createUser;
	}
	
	public Date getUpdateTime(){
		return updateTime;
	}
	
	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}
	
	public String getUpdateUser(){
		return updateUser;
	}
	
	public void setUpdateUser(String updateUser){
		this.updateUser = updateUser;
	}
	
	
}
