package com.macroflag.plusplatform.common.model.base;

import java.io.Serializable;

/**
 * 规则系统 json-request 基础对象
 * 
 * @author : Fredia
 * @since : 2018年3月6日
 * @version : v1.0.0
 */
public class DataModelReqBase implements Serializable {

	private static final long serialVersionUID = 1L;
	/* 场景编码 */
	private String sceneCode;
	/* 产品编号 */
	private String proCode;
	/* 业务主键 */
	private String businessKey;

	public String getSceneCode() {
		return sceneCode;
	}

	public void setSceneCode(String sceneCode) {
		this.sceneCode = sceneCode;
	}

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public String getProCode() {
		return proCode;
	}

	public void setProCode(String proCode) {
		this.proCode = proCode;
	}

}
