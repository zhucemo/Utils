package com.macroflag.plusplatform.common.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.aliyun.oss.model.PutObjectResult;
import com.macroflag.plusplatform.common.exception.ExceptionUtils;
import com.macroflag.plusplatform.common.model.CommoneFileModel;
import com.macroflag.plusplatform.common.model.FineUploaderParamModel;
import com.macroflag.plusplatform.common.oss.OSSKit;

/**
 * 文件操作工具类 测试使用
 * 
 * @author : Fredia
 * @since : 2018年4月16日
 * @version : v1.0.0
 */
public class FileUtils {

	public static final String DOT = ".";

	/**
	 * OSS 资源上传处理 默认使用此方法进行上传
	 * 
	 * @param request
	 * @param paramModel
	 * @return
	 * @author : Fredia
	 * @since : 2018年3月6日
	 * @return :CommoneFileModel
	 */
	public static CommoneFileModel doFileUploadOSS(HttpServletRequest request, FineUploaderParamModel paramModel) {
		String url = null; // 上传后文件相对路径
		InputStream stream = null; // 上传成功后 oss 返回上传流信息
		String eTag = null;// 阿里云返回 Etag 上传文件唯一标识

		CommoneFileModel fileModel = new CommoneFileModel();
		try {
			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			List<FileItem> items = upload.parseRequest(request);
			Iterator<FileItem> itr = items.iterator();

			while (itr.hasNext()) {
				FileItem item = itr.next();
				if (!item.isFormField()) {
					String tempFileName = item.getName();
					String fileName = MessageFormat.format("{0}/{1}/{2}/{3}{4}",
							paramModel.getModule() == null ? "sources" : paramModel.getModule(),
							new SimpleDateFormat("yyyyMMdd").format(new Date()),
							new SimpleDateFormat("HHmmss").format(new Date()), Math.ceil(Math.random() * 1000),
							tempFileName.substring(tempFileName.lastIndexOf('.')));

					InputStream inputStream = item.getInputStream();
					String path = fileName;
					PutObjectResult objectResult = OSSKit.uploadStream(inputStream, path);
					stream = objectResult.getCallbackResponseBody();
					eTag = objectResult.getETag(); // 阿里云返回 Etag 上传文件唯一标识
					url = path;

					fileModel.seteTag(eTag);
					fileModel.setInputStream(stream);
					fileModel.setUrl(url);
					fileModel.setResourceDomainName(OSSKit.getOSSObject().getOssResourceDomainName());
					// TODO OSS 保存静态资源
				}
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
			ExceptionUtils.throwBaseException("上传信息异常：" + e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			ExceptionUtils.throwBaseException("上传信息异常：" + e.getMessage());
		}
		return fileModel;
	}

	/**
	 * 应用服务器 资源上传处理 上传资源到应用服务器
	 * 
	 * @param request
	 * @param paramModel
	 * @return
	 * @author : Fredia
	 * @since : 2018年3月6日
	 * @return :String
	 */
	@SuppressWarnings("rawtypes")
	public static String doPost(HttpServletRequest request, FineUploaderParamModel paramModel) {

		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(factory);
		try {
			List items = upload.parseRequest(request);
			Iterator itr = items.iterator();
			while (itr.hasNext()) {
				FileItem item = (FileItem) itr.next();
				if (!item.isFormField()) {
					if (item.getName() != null && !item.getName().equals("")) {
						String tempFileName = item.getName();

						String fileName = MessageFormat.format("{0}/{1}/{2}/{3}{4}{5}", "/uploads",
								paramModel.getModule(), new SimpleDateFormat("yyyyMMdd").format(new Date()),
								new SimpleDateFormat("HHmmss").format(new Date()), Math.ceil(Math.random() * 1000),
								tempFileName.substring(tempFileName.lastIndexOf('.')));

						String filePath = request.getServletContext().getRealPath(fileName);

						System.out.println(filePath);
						File file = new File(filePath);
						File dir = new File(file.getParent());

						if (!dir.exists()) {
							dir.mkdirs();
						}

						item.write(file);
						return fileName;
					} else {
						return null;
					}
				}
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String getRandomFileName() {

		SimpleDateFormat simpleDateFormat;

		simpleDateFormat = new SimpleDateFormat("yyyyMMdd");

		Date date = new Date();

		String str = simpleDateFormat.format(date);

		Random random = new Random();

		int rannum = (int) (random.nextDouble() * (99999 - 10000 + 1)) + 10000;// 获取5位随机数

		return rannum + str;// 当前时间
	}

	public static String getExtension(String fileName) {
		if (fileName.indexOf(DOT) != -1) {
			return "";
		}

		String ext = fileName.substring(fileName.lastIndexOf(DOT));

		return ext.trim();
	}

	public static String getDirectoryName(String filePath) {
		filePath = filePath.replace("\\", "/");
		String directoryName = filePath.substring(0, filePath.lastIndexOf("/"));
		return directoryName.trim();
	}

	public static String getFileName(String filePath) {
		filePath = filePath.replace("\\", "/");
		return filePath.substring(filePath.lastIndexOf("/") + 1, filePath.lastIndexOf(DOT));
	}

	public static boolean deleteDirectory(String filePath) {
		File dir = new File(filePath);
		if (dir.exists()) {
			return deleteDirectory(dir);
		} else {
			return false;
		}
	}

	public static boolean deleteDirectory(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDirectory(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}
		// 目录此时为空，可以删除
		return dir.delete();
	}

	/**
	 * 将文件转化为二进制流
	 * 
	 * @param file
	 * @return
	 * @author : Fredia
	 * @since : 2018年3月6日
	 * @return :byte[]
	 */
	public static byte[] getBytes(File file) {
		byte[] buffer = null;
		try {
			FileInputStream fis = new FileInputStream(file);
			ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);
			byte[] b = new byte[1000];
			int n;
			while ((n = fis.read(b)) != -1) {
				bos.write(b, 0, n);
			}
			buffer = bos.toByteArray();
			fis.close();
			bos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return buffer;
	}

	/**
	 * 下载文件
	 * 
	 * @param remoteFilePath
	 * @param localFilePath
	 * @return
	 * @author : Fredia
	 * @since : 2018年3月6日
	 * @return :File
	 */
	public static File downloadFile(String remoteFilePath, String localFilePath) {
		File file = new File(localFilePath);
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		FileOutputStream fileOutputStream  = null;
		try {
			URL urlFile = new URL(remoteFilePath);
			HttpURLConnection httpUrl = (HttpURLConnection) urlFile.openConnection();
			httpUrl.connect();
			bis = new BufferedInputStream(httpUrl.getInputStream());
			fileOutputStream = new FileOutputStream(file);
			bos = new BufferedOutputStream(fileOutputStream);
			int len = 2048;
			byte[] b = new byte[len];
			while ((len = bis.read(b)) != -1) {
				bos.write(b, 0, len);
			}
			bos.flush();
			fileOutputStream.close();
			bis.close();
			httpUrl.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(bis!=null&&bos!=null){
				try {
					bis.close();
					fileOutputStream.close();
					bos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return file;
	}

	/**
	 * 读取文件流 文件名编码
	 * 
	 * @param Path
	 * @return
	 * @author : Fredia
	 * @since : 2018年3月6日
	 * @return :String
	 */
	public static String ReadFile(String Path) {

		BufferedReader reader = null;

		String laststr = "";
		try {
			FileInputStream fileInputStream = new FileInputStream(Path);
			InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream, "utf-8");
			reader = new BufferedReader(inputStreamReader);
			String tempString = null;
			while ((tempString = reader.readLine()) != null) {
				laststr += tempString;
			}
			fileInputStream.close();
			inputStreamReader.close();
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return laststr;
	}

}
