package com.macroflag.plusplatform.common.util;

import com.alibaba.fastjson.JSONObject;

public class LogUtil {
    public static String CodeInfo() {
        String msg;
        try {
            Throwable throwable = new Throwable();
            StackTraceElement[] stackTraceElement = throwable.getStackTrace();
            StackTraceElement stackTraceElement1 = stackTraceElement[1];
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("调用文件", stackTraceElement1.getFileName());
            jsonObject.put("调用类", stackTraceElement1.getClassName());
            jsonObject.put("调用方法", stackTraceElement1.getMethodName());
            jsonObject.put("调用行数", stackTraceElement1.getLineNumber());
            msg = jsonObject.toJSONString();
        } catch (Exception e) {
            msg = "";
        }
        return msg;
    }

    public static String CodeInfo(Exception e) {
        String msg;
        try {
            StackTraceElement[] eStackTrace = e.getStackTrace();
            Throwable throwable = new Throwable();
            StackTraceElement[] stackTraceElements = throwable.getStackTrace();
            StackTraceElement stackElement = stackTraceElements[1];
            StackTraceElement eStackElement = null;
            for (StackTraceElement traceElement : eStackTrace) {
                if (traceElement.getClassName().equals(stackElement.getClassName()) && traceElement.getMethodName().equals(stackElement.getMethodName())) {
                    eStackElement = traceElement;
                    break;
                }
            }
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("异常文件", eStackElement.getFileName());
            jsonObject.put("异常类", eStackElement.getClassName());
            jsonObject.put("异常方法", eStackElement.getMethodName());
            jsonObject.put("异常行数", eStackElement.getLineNumber());
            jsonObject.put("异常信息", e.getMessage());
            msg = jsonObject.toJSONString();
        } catch (Exception e1) {
            msg = "";
        }
        return msg;
    }
}
