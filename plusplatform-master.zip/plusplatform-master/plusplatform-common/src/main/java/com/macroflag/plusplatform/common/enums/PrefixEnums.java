package com.macroflag.plusplatform.common.enums;

import com.macroflag.plusplatform.common.enums.IEnum;

/**
 * 凭安枚举类
 * 
 * @author : fredia
 * @since : 2017年11月2日
 * @version : v0.0.1
 */
public enum PrefixEnums implements IEnum {
	ORDER_APPLY(101, "order"),
	INNERLOGS(102, "inner"),
	APILOGS(103, "api"),
	TRANSCODE(104, "trans"),
	CUSLOGS(105, "cus"),
	JQID(106,"QJ");

	private int value;
	private String description;

	@Override
	public int getValue() {
		return value;
	}

	@Override
	public String getDescription() {
		return description;
	}

	private PrefixEnums(int value, String description) {
		this.value = value;
		this.description = description;
	}

}
