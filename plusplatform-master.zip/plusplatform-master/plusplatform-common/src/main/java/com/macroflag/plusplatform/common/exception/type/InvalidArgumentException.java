package com.macroflag.plusplatform.common.exception.type;

import org.springframework.http.HttpStatus;

import com.macroflag.plusplatform.common.exception.ErrorCode;

/**
 * 参数错误
 * 
 * @author : fredia
 * @since : 2017年11月2日
 * @version : v0.0.1
 */
public class InvalidArgumentException extends RestException {
	public InvalidArgumentException(String message) {
		super(HttpStatus.OK, ErrorCode.INVALID_ARGUMENT, message);
	}
}
