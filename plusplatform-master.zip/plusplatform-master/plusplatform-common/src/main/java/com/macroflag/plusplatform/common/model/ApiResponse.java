package com.macroflag.plusplatform.common.model;

import java.io.Serializable;

/**
 * RESPONSE 
 * 
 * @author : Fredia
 * @since : 2018年4月26日
 * @version : v1.0.0
 */
public class ApiResponse implements Serializable {

	private static final long serialVersionUID = -1440428414934837551L;
	/**
	 * 正常 200
	 */
	private int code;

	/**
	 * 返回消息
	 */
	private String message;

	/**
	 * 数据
	 */
	private Object data;


	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

}
