package com.macroflag.plusplatform.common.service;

import com.macroflag.plusplatform.common.core.service.IBaseService;
import com.macroflag.plusplatform.common.entity.ScheduleApplyTaskDomain;
import com.macroflag.plusplatform.common.query.ScheduleApplyTaskQuery;

import java.util.List;


/**
 * 申请记录任务表的业务层接口
 * @author : Fredia
 * @since : 2018年05月08日
 * @version : v0.0.1
 */
public interface IScheduleApplyTaskService extends IBaseService<ScheduleApplyTaskDomain> {
	List<ScheduleApplyTaskDomain> getUpcomingList(ScheduleApplyTaskQuery query);

}
