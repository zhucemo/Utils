package com.macroflag.plusplatform.common.model;

import java.io.Serializable;
import java.util.Date;

public class BusinessUserContactsModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*id*/
	private Long id;
	
	/*用户唯一标示*/
	private String uniqueNo;
	
	/*直系亲属姓名*/
	private String immediateFamilyName;
	
	/*该直系亲属与本人关系*/
	private String imFamilyRelationship;
	
	/*该直系亲属手机号码*/
	private String immediateFamilyPhone;
	
	/*其他联系人姓名*/
	private String anotherContactsName;
	
	/*该其他联系人与本人关系*/
	private String anotherContactsRelationship;
	
	/*该其他联系人手机号码*/
	private String anotherContactsPhone;
	
	/**/
	private String spare1;
	
	/**/
	private String spare2;
	
	/**/
	private String spare3;
	
	/**/
	private String spare4;
	
	/**/
	private Date createTime;
	
	/**/
	private Long createUser;
	
	/**/
	private Date updateTime;
	
	/**/
	private Long updateUser;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}

	public String getImmediateFamilyName() {
		return immediateFamilyName;
	}

	public void setImmediateFamilyName(String immediateFamilyName) {
		this.immediateFamilyName = immediateFamilyName;
	}

	public String getImFamilyRelationship() {
		return imFamilyRelationship;
	}

	public void setImFamilyRelationship(String imFamilyRelationship) {
		this.imFamilyRelationship = imFamilyRelationship;
	}

	public String getImmediateFamilyPhone() {
		return immediateFamilyPhone;
	}

	public void setImmediateFamilyPhone(String immediateFamilyPhone) {
		this.immediateFamilyPhone = immediateFamilyPhone;
	}

	public String getAnotherContactsName() {
		return anotherContactsName;
	}

	public void setAnotherContactsName(String anotherContactsName) {
		this.anotherContactsName = anotherContactsName;
	}

	public String getAnotherContactsRelationship() {
		return anotherContactsRelationship;
	}

	public void setAnotherContactsRelationship(String anotherContactsRelationship) {
		this.anotherContactsRelationship = anotherContactsRelationship;
	}

	public String getAnotherContactsPhone() {
		return anotherContactsPhone;
	}

	public void setAnotherContactsPhone(String anotherContactsPhone) {
		this.anotherContactsPhone = anotherContactsPhone;
	}

	public String getSpare1() {
		return spare1;
	}

	public void setSpare1(String spare1) {
		this.spare1 = spare1;
	}

	public String getSpare2() {
		return spare2;
	}

	public void setSpare2(String spare2) {
		this.spare2 = spare2;
	}

	public String getSpare3() {
		return spare3;
	}

	public void setSpare3(String spare3) {
		this.spare3 = spare3;
	}

	public String getSpare4() {
		return spare4;
	}

	public void setSpare4(String spare4) {
		this.spare4 = spare4;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Long getCreateUser() {
		return createUser;
	}

	public void setCreateUser(Long createUser) {
		this.createUser = createUser;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Long getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(Long updateUser) {
		this.updateUser = updateUser;
	}
}
