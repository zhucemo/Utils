package com.macroflag.plusplatform.common.sys.service;

import com.macroflag.plusplatform.common.core.service.IBaseService;
import com.macroflag.plusplatform.common.entity.CommonAreaDomain;

/**
 * 用户的业务层接口
 * @author : fredia
 * @since : 2018年05月09日
 * @version : v0.0.1
 */
public interface ICommonAreaService extends IBaseService<CommonAreaDomain> {

}
