package com.macroflag.plusplatform.common.exception;

import java.io.IOException;
import java.io.Serializable;

import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.method.HandlerMethod;

import com.macroflag.plusplatform.common.core.json.JsonUtils;
import com.macroflag.plusplatform.common.core.json.model.ResultModel;

/**
 * 异常工具类
 * 
 * @author : fredia
 * @email : trumpey@163.com
 * @since : 2017年11月16日
 * @version : v0.0.1
 */
public class ExceptionUtils implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 抛出异常消息
	 * 
	 * @param message
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :void
	 */
	public static void throwBaseException(String message) {
		throw new BaseException(HttpStatus.INTERNAL_SERVER_ERROR.value(), message);
	}

	/**
	 * 抛出异常
	 * 
	 * @param code
	 * @param message
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :void
	 */
	public static void throwBaseException(int code, String message) {
		throw new BaseException(code, message);
	}

	/**
	 * 输出到客户端
	 * 
	 * @param response
	 * @param code
	 * @param message
	 * @throws IOException
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :void
	 */
	public static void outputMessage(HttpServletResponse response, int code, String message) throws IOException {
		JsonUtils.outputMessage(response,
				JsonUtils.toJSONString(new ResultModel(HttpStatus.INTERNAL_SERVER_ERROR.value(), message, code)));
	}

	/**
	 * 根据请求类型输出json或跳转到异常页面
	 * 
	 * @param response
	 * @param handler
	 * @param code
	 * @param message
	 * @throws IOException
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :void
	 */
	public static void throwBaseException(HttpServletResponse response, Object handler, int code, String message)
			throws IOException {
		if (handler instanceof HandlerMethod) {
			HandlerMethod handlerMethod = (HandlerMethod) handler;
			ResponseBody annotation = handlerMethod.getMethodAnnotation(ResponseBody.class);
			if (annotation != null) {
				ExceptionUtils.outputMessage(response, code, message);
				return;
			}
		}
		ExceptionUtils.throwBaseException(code, message);
	}

	/**
	 * 将CheckedException转换为UncheckedException
	 * 
	 * @param ex
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :RuntimeException
	 */
	public static RuntimeException unchecked(Throwable ex) {
		if (ex instanceof RuntimeException) {
			return (RuntimeException) ex;
		} else {
			return new RuntimeException(ex);
		}
	}
}
