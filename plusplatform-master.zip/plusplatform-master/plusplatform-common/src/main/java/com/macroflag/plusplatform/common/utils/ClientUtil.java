package com.macroflag.plusplatform.common.utils;

import org.springframework.util.StringUtils;

import com.macroflag.plusplatform.common.enums.LoginClient;

/**
 * 客户端工具类
 * 
 * @author : fredia
 * @since : 2017年11月2日
 * @version : v0.0.1
 */
public class ClientUtil {
	public static LoginClient getLoginClient(String appKey) {
		if (StringUtils.isEmpty(appKey)) {
			return null;
		}
		if ("IOSAppKey".equalsIgnoreCase(appKey)) {
			return LoginClient.IOS;
		}
		if ("AndroidAppKey".equalsIgnoreCase(appKey)) {
			return LoginClient.ANDROID;
		}
		return null;
	}
}
