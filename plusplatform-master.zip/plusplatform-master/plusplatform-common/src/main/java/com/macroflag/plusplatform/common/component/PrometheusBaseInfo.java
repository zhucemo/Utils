package com.macroflag.plusplatform.common.component;

import io.prometheus.client.hotspot.DefaultExports;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class PrometheusBaseInfo implements CommandLineRunner {

    @Override
    public void run(String... strings) {
        DefaultExports.initialize();
    }
}
