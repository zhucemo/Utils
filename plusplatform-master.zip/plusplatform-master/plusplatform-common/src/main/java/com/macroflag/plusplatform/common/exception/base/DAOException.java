
package com.macroflag.plusplatform.common.exception.base;

import com.macroflag.plusplatform.jwt.exception.BaseException;

/**
 * Dao基础异常类
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
public class DAOException extends BaseException {
}
