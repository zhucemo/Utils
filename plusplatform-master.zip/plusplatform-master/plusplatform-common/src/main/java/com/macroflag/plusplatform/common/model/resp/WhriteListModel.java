package com.macroflag.plusplatform.common.model.resp;

import com.macroflag.plusplatform.common.model.resp.base.BaseModel;

public class WhriteListModel extends BaseModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String cupdApplyNo;

	public String getCupdApplyNo() {
		return cupdApplyNo;
	}

	public void setCupdApplyNo(String cupdApplyNo) {
		this.cupdApplyNo = cupdApplyNo;
	}
}
