package com.macroflag.plusplatform.common.model.req;

import java.io.Serializable;

/**
 * 手机服务密码验证请求model
 * @author huangf
 *
 */
public class ReqPwdCerifyModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 业务主键(申请编号)
	 */
	private String businessKey;
	
	/**
	 * 用户唯一编号
	 */
	private String uniqueNo;

	/**
	 * 用户名
	 */
	private String userName;
	
	/**
	 * 身份证
	 */
	private String idCard;
	
	/**
	 * 手机号
	 */
	private String phoneNum;
	
	/**
	 * 服务密码
	 */
	private String serverPwd;
	
	/**
	 * 分期期数
	 */
	private String period;
	
	/**
	 * 账单日
	 */
	private String billdate;
	
	/**
	 * 申请编号
	 */
	private String activeApplyNo;

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getServerPwd() {
		return serverPwd;
	}

	public void setServerPwd(String serverPwd) {
		this.serverPwd = serverPwd;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getBilldate() {
		return billdate;
	}

	public void setBilldate(String billdate) {
		this.billdate = billdate;
	}

	public String getActiveApplyNo() {
		return activeApplyNo;
	}

	public void setActiveApplyNo(String activeApplyNo) {
		this.activeApplyNo = activeApplyNo;
	}
}
