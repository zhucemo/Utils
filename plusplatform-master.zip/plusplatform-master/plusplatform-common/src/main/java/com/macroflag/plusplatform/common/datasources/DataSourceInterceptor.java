package com.macroflag.plusplatform.common.datasources;

import org.aspectj.lang.JoinPoint;

/**
 * 多数据源拦截器
 * 
 * @author : fredia
 * @since : 2017年10月23日
 * @version : v0.0.1
 */
public class DataSourceInterceptor {

	//TODO 自定义数据源名
	public void setcoreDataSource(JoinPoint jp) {
		DatabaseContextHolder.setCustomerType("coreDataSource1");
	}

	public void setcoreDataSource2(JoinPoint jp) {
		DatabaseContextHolder.setCustomerType("coreDataSource2");
	}

}