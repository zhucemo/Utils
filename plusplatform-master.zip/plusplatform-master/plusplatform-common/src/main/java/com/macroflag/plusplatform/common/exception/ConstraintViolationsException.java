package com.macroflag.plusplatform.common.exception;

/**
 * constraintViolations异常处理
 * 
 * @author : fredia
 * @email : trumpey@163.com
 * @since : 2017年11月16日
 * @version : v0.0.1
 */
public class ConstraintViolationsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 业务状态码
	 */
	private int code;

	/**
	 * 业务对象
	 */
	private Object object;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

	public ConstraintViolationsException(int code, Object object) {
		this.object = object;
		this.code = code;
	}

}
