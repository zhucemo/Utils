package com.macroflag.plusplatform.common.core.service;

import java.util.List;

import com.macroflag.plusplatform.common.base.Query;
import com.macroflag.plusplatform.common.core.pager.PageModel;

/**
 * 业务层基类
 * @author :fredia
 * @since : 2017年9月26日
 * @version : v0.0.1
 */
public interface IBaseService<T> {

	/**
	 * 根据主键查询
	 * @param primaryKey
	 * @return
	 * @author :fredia	
	 * @since : 2017年9月26日
	 */
	T getByPrimaryKey(Object primaryKey);
	
	/**
	 * 查询一条数据
	 * @param
	 * @return
	 * @author :fredia	
	 * @since : 2017年9月26日
	 */
	T getOne(Query query);
	
	/**
	 * 查询一个集合
	 * @param
	 * @return
	 * @author :fredia	
	 * @since : 2017年9月26日
	 */
	List<T> getList(Query query);
	
	/**
	 * 查询总数
	 * @param
	 * @return
	 * @author :fredia	
	 * @since : 2017年9月26日
	 */
	Integer getListCount(Query query);
	
	/**
	 * 分页查询
	 * @param
	 * @return
	 * @author :fredia	
	 * @since : 2017年9月29日
	 */
	PageModel<T> getPageList(Query query);
	
	/**
	 * 插入单个对象
	 * @param model
	 * @return
	 * @author :fredia	
	 * @since : 2017年9月26日
	 */
	T insert(T model);
	
	/**
	 * 根据主键删除
	 * @param primaryKey
	 * @author :fredia	
	 * @since : 2017年9月26日
	 */
	void deleteByPrimaryKey(Object primaryKey);
	
	/**
	 * 根据主键更新数据,更新不为null数据
	 * @param model
	 * @author :fredia	
	 * @since : 2017年9月26日
	 */
	void updateByPrimaryKey(T model);
	
	/**
	 * 根据主键更新数据,更新不为null数据
	 * @param model
	 * @author :fredia	
	 * @since : 2017年9月26日
	 */
	void updateByPrimaryKeyAll(T model);
	
}
