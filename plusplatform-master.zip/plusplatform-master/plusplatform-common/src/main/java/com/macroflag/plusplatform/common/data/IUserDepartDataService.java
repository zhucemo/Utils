
package com.macroflag.plusplatform.common.data;

import java.util.List;

/**
 * 用户部门数据服务
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
public interface IUserDepartDataService {
	/**
	 * 根据用户获取用户可访问的数据部门Id
	 * 
	 * @param userId
	 * @return
	 * @author : Fredia
	 * @since : 2018年6月6日
	 * @return :List<String>
	 */
	public List<String> getUserDataDepartIds(String userId);
}
