package com.macroflag.plusplatform.common.product.service.impl;

import com.macroflag.plusplatform.common.core.service.impl.BaseServiceImpl;
import com.macroflag.plusplatform.common.entity.BankDomain;
import com.macroflag.plusplatform.common.mapper.nongeneric.BankMapper;
import com.macroflag.plusplatform.common.product.service.IBankService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;


/**
 * 银行表的业务实现类
 * @author : Fredia
 * @since : 2018年04月27日
 * @version : v0.0.1
 */
@Service("bankService")
public class BankServiceImpl extends BaseServiceImpl<BankDomain> implements IBankService {
	
	@Autowired
	@Lazy
	private BankMapper bankMapper;
	
}
