package com.macroflag.plusplatform.common.model;

import com.macroflag.plusplatform.common.model.base.DataModelReqBase;



/**
 * 轮循件请求数据平台基本信息实体类
 * @author huangf
 *
 */
public class InnerDataBaseModel extends DataModelReqBase{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	//是异步：1	否：0
	private Integer isAync;

	private String phone;
	
	private String name;
	
	private String documentno;

	public Integer getIsAync() {
		return isAync;
	}

	public void setIsAync(Integer isAync) {
		this.isAync = isAync;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDocumentno() {
		return documentno;
	}

	public void setDocumentno(String documentno) {
		this.documentno = documentno;
	}
}
