package com.macroflag.plusplatform.common.mapper.nongeneric;

import com.macroflag.plusplatform.common.entity.ProductDomain;
import com.macroflag.plusplatform.common.mapper.Mapper;

/**
 * 银行产品表的mapper
 * @author : fredia
 * @since : 2018年04月27日
 * @version : v0.0.1
 */
public interface ProductMapper extends Mapper<ProductDomain> {
	
}
