package com.macroflag.plusplatform.common.mapper.nongeneric;

import com.macroflag.plusplatform.common.entity.ScheduleApplyTaskDomain;
import com.macroflag.plusplatform.common.mapper.Mapper;
import com.macroflag.plusplatform.common.query.ScheduleApplyTaskQuery;

import java.util.List;


/**
 * 申请记录任务表的mapper
 * 
 * @author : Fredia
 * @since : 2018年05月08日
 * @version : v0.0.1
 */
public interface ScheduleApplyTaskMapper extends Mapper<ScheduleApplyTaskDomain> {
	List<ScheduleApplyTaskDomain> getUpcomingList(ScheduleApplyTaskQuery query);

}
