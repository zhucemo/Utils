package com.macroflag.plusplatform.common.sys.service;

import com.macroflag.plusplatform.common.core.service.IBaseService;
import com.macroflag.plusplatform.common.entity.CommonEnumsDomain;

/**
 * 枚举服务的业务层接口
 * @author : fredia
 * @since : 2018年04月24日
 * @version : v0.0.1
 */
public interface ICommonEnumsService extends IBaseService<CommonEnumsDomain> {

}
