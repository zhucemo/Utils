package com.macroflag.plusplatform.common.mapper.nongeneric;


import com.macroflag.plusplatform.common.entity.CommonAreaDomain;
import com.macroflag.plusplatform.common.mapper.Mapper;

/**
 * 用户的mapper
 * @author : fredia
 * @since : 2018年05月09日
 * @version : v0.0.1
 */
public interface CommonAreaMapper extends Mapper<CommonAreaDomain> {
	
}
