package com.macroflag.plusplatform.common.model.req;

import java.io.Serializable;

/**
 * 绑定银行卡请求model
 * @author huangf
 *
 */
public class ReqAuthbindCardModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 业务主键(申请编号)
	 */
	private String businessKey;
	
	/**
	 * 用户唯一编号
	 */
	private String uniqueNo;

	/**
	 * 用户名
	 */
	private String userName;
	
	/**
	 * 身份证
	 */
	private String idCard;
	
	/**
	 * 手机号
	 */
	private String phoneNum;
	
	/**
	 * 银行卡号
	 */
	private String cardNo;

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
}
