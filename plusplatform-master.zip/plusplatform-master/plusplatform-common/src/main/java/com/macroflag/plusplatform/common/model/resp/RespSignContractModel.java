package com.macroflag.plusplatform.common.model.resp;

import com.macroflag.plusplatform.common.model.resp.base.BaseModel;

public class RespSignContractModel extends BaseModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 合同编号
	 */
	private String applyNo;
	
	/**
	 * 合同签署哈希值
	 */
	private String hash;
	
	/**
	 * 本地合同存放路径
	 */
	private String filePah;

	public String getApplyNo() {
		return applyNo;
	}

	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getFilePah() {
		return filePah;
	}

	public void setFilePah(String filePah) {
		this.filePah = filePah;
	}
}
