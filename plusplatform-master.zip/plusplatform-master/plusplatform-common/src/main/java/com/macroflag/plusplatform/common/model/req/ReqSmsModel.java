package com.macroflag.plusplatform.common.model.req;

import java.io.Serializable;

/**
 * dubbo 发送短信验证码请求model
 * @author huangf
 *
 */
public class ReqSmsModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	/**
	 * 用户唯一编号
	 */
	private String uniqueNo;
	
	/**
	 * 业务主键(申请编号)
	 */
	private String businessKey;
	
	/**
	 * 手机号
	 */
	private String mobile;
	
	/**
	 * 短信内容
	 */
	private String content;
	
	/**
	 * 产品号
	 */
	private String productNo;

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}
	
}
