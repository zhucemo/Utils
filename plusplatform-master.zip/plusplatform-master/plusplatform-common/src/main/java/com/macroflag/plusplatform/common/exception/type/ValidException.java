package com.macroflag.plusplatform.common.exception.type;

import org.springframework.http.HttpStatus;

import com.macroflag.plusplatform.common.exception.ErrorCode;

/**
 * 数据校验异常，返回给用户
 * @author : fredia
 * @since : 2017年11月2日
 * @version : v0.0.1
 */
public class ValidException extends RestException{
    public ValidException(String message) {
        super(HttpStatus.OK,ErrorCode.INVALID_ARGUMENT,message);
    }
}
