package com.macroflag.plusplatform.common.model;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * 前端to业务系统数据对象
 * 
 * @author : Fredia
 * @since : 2018年5月2日
 * @version : v1.0.0
 */
public class BusinessUserAllDataModel implements Serializable {
	private static final long serialVersionUID = 1L;
	/* 1.基本信息 */
	// 业务主键(申请编号)
	private String applyNo;

	// 姓名
	private String name;
	// 身份证
	private String idCard;

	// 进件标示 JJBS_ZD自动 JJBS_RG 人工 自动
	private String entryType;

	/* 2.联系人信息 */
	/* 直系亲属姓名 */
	private String immediateFamilyName;

	/* 该直系亲属与本人关系 */
	private String imFamilyRelationship;

	/* 该直系亲属手机号码 */
	private String immediateFamilyPhone;

	/* 其他联系人姓名 */
	private String anotherContactsName;

	/* 该其他联系人与本人关系 */
	private String anotherContactsRelationship;

	/* 该其他联系人手机号码 */
	private String anotherContactsPhone;

	/* 3.联系人信息 */
	/*
	 * 身份证类型：证件类型: ZJLX_SFZ 身份证 ZJLX_HKB 户口簿 ZJLX_HZ 护照 ZJLX_JGZ 军官证 -身份证
	 */
	private String certificateType;

	/* 婚姻状况 */
	private String maritalStatus;

	/* 教育程度 */
	private String educationLevel;

	/* 4.家庭地址信息 */
	/* 省级编号 */
	private String householdProvinceCode;

	/* 市级编号 */
	private String householdCityCode;

	/* 县级编号 */
	private String householdCountyCode;

	/* 详细地址 */
	private String householdAddress;

	/* 5.公司信息 */
	/* 公司名称 */
	private String companyName;

	/* 部门 */
	private String department;

	/* 职位 */
	private String job;

	/* 现单位工龄 */
	private String unitAge;

	/* 单位电话 */
	private String companyPhone;

	/*
	 * 行业类型 HYLX_KJJR会计/金融/银行/保险 HYLX_ZFXX政府/学校/非营利组织 HYLX_JSJHLW计算机/互联网/通信/电子
	 * HYLX_MYXF贸易/消费/营运 HYLX_FDCJZ房地产/建筑 HYLX_ZYFWJY专业服务/教育/培训
	 * HYLX_SCJG生产/加工/制造 HYLX_JTYS交通/运输/物流/仓储 HYLX_FWY服务业 HYLX_GGMT广告/媒体
	 * HYLX_NYKC能源/矿产/环保 HYLX_YLZY医疗/制药 HYLX_XS学生 HYLX_QT其他
	 */
	private String industryType;

	/* 单位性质 */
	private String companyType;

	/* 公司单位地址省级编号 */
	private String companyProvinceCode;

	/* 单位地址市级编号 */
	private String companyCityCode;

	/* 单位地址县级（区）编号 */
	private String companyCountyCode;

	/* 单位地址详细地址 */
	private String companyAddress;

	// 新增
	/* 年龄 */
	private String age;

	/* 生肖 */
	private String zodiac;

	/* 身份证归属地(发证机关) */
	private String idIssuingOrgan;

	/* 身份证有效期-起始日期 */
	private String validDateBegin;

	/* 身份证有效期-截至日期 */
	private String validDateEnd;

	/* 身份证和姓名是否匹配 1:yes 0:no 1 */
	private String idAndNameMatch;

	/* 相似度比对是否通过 1:yes 0:no 1 */
	private String similarityPass;

	/* 身份证号是否被冒用 1-是,0-否 */
	private String idFraudulent;

	/* 人脸照与数据源公安照比对结果置信度 */
	private String faceSourceConfidence;

	/* 人脸照与数据源比对置信度阀值 */
	private String faceSourceThresholds;

	/* 人脸照与身份证照比对置信度 */
	private String faceIdCardConfidence;

	/* 人脸照与身份证照比对置信度阀值 */
	private String faceIdCardThresholds;

	/* 假脸攻击判定结果 */
	private String idAttacked;

	/* 活体流程验证结果 */
	private String procedureValidation;

	/* LBS省 */
	private String provinceLBS;

	/* LBS市 */
	private String cityLBS;

	/**
	 * 产品号
	 */
	private String productNo;

	public String getProductNo() {
		return productNo;
	}

	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}

	/**
	 * 扩展参数-使用频率低的参数请存入此map,尽量避免冗余
	 */
	private Map<Object, Object> extendMap;

	public Map<Object, Object> getExtendMap() {
		return extendMap;
	}

	public void setExtendMap(Map<Object, Object> extendMap) {
		this.extendMap = extendMap;
	}

	public void put(Object key, Object obj) {
		if (this.extendMap == null) {
			this.extendMap = new HashMap<Object, Object>();
		}
		this.extendMap.put(key, obj);
	}

	@SuppressWarnings("unchecked")
	public <T> T get(Object key) {
		if (extendMap == null) {
			return null;
		}
		return (T) this.extendMap.get(key);
	}

	public String getApplyNo() {
		return applyNo;
	}

	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIdCard() {
		return idCard;
	}

	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}

	public String getEntryType() {
		return entryType;
	}

	public void setEntryType(String entryType) {
		this.entryType = entryType;
	}

	public String getImmediateFamilyName() {
		return immediateFamilyName;
	}

	public void setImmediateFamilyName(String immediateFamilyName) {
		this.immediateFamilyName = immediateFamilyName;
	}

	public String getImFamilyRelationship() {
		return imFamilyRelationship;
	}

	public void setImFamilyRelationship(String imFamilyRelationship) {
		this.imFamilyRelationship = imFamilyRelationship;
	}

	public String getImmediateFamilyPhone() {
		return immediateFamilyPhone;
	}

	public void setImmediateFamilyPhone(String immediateFamilyPhone) {
		this.immediateFamilyPhone = immediateFamilyPhone;
	}

	public String getAnotherContactsName() {
		return anotherContactsName;
	}

	public void setAnotherContactsName(String anotherContactsName) {
		this.anotherContactsName = anotherContactsName;
	}

	public String getAnotherContactsRelationship() {
		return anotherContactsRelationship;
	}

	public void setAnotherContactsRelationship(String anotherContactsRelationship) {
		this.anotherContactsRelationship = anotherContactsRelationship;
	}

	public String getAnotherContactsPhone() {
		return anotherContactsPhone;
	}

	public void setAnotherContactsPhone(String anotherContactsPhone) {
		this.anotherContactsPhone = anotherContactsPhone;
	}

	public String getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(String certificateType) {
		this.certificateType = certificateType;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getEducationLevel() {
		return educationLevel;
	}

	public void setEducationLevel(String educationLevel) {
		this.educationLevel = educationLevel;
	}

	public String getHouseholdProvinceCode() {
		return householdProvinceCode;
	}

	public void setHouseholdProvinceCode(String householdProvinceCode) {
		this.householdProvinceCode = householdProvinceCode;
	}

	public String getHouseholdCityCode() {
		return householdCityCode;
	}

	public void setHouseholdCityCode(String householdCityCode) {
		this.householdCityCode = householdCityCode;
	}

	public String getHouseholdCountyCode() {
		return householdCountyCode;
	}

	public void setHouseholdCountyCode(String householdCountyCode) {
		this.householdCountyCode = householdCountyCode;
	}

	public String getHouseholdAddress() {
		return householdAddress;
	}

	public void setHouseholdAddress(String householdAddress) {
		this.householdAddress = householdAddress;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getUnitAge() {
		return unitAge;
	}

	public void setUnitAge(String unitAge) {
		this.unitAge = unitAge;
	}

	public String getCompanyPhone() {
		return companyPhone;
	}

	public void setCompanyPhone(String companyPhone) {
		this.companyPhone = companyPhone;
	}

	public String getIndustryType() {
		return industryType;
	}

	public void setIndustryType(String industryType) {
		this.industryType = industryType;
	}

	public String getCompanyType() {
		return companyType;
	}

	public void setCompanyType(String companyType) {
		this.companyType = companyType;
	}

	public String getCompanyProvinceCode() {
		return companyProvinceCode;
	}

	public void setCompanyProvinceCode(String companyProvinceCode) {
		this.companyProvinceCode = companyProvinceCode;
	}

	public String getCompanyCityCode() {
		return companyCityCode;
	}

	public void setCompanyCityCode(String companyCityCode) {
		this.companyCityCode = companyCityCode;
	}

	public String getCompanyCountyCode() {
		return companyCountyCode;
	}

	public void setCompanyCountyCode(String companyCountyCode) {
		this.companyCountyCode = companyCountyCode;
	}

	public String getCompanyAddress() {
		return companyAddress;
	}

	public void setCompanyAddress(String companyAddress) {
		this.companyAddress = companyAddress;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getZodiac() {
		return zodiac;
	}

	public void setZodiac(String zodiac) {
		this.zodiac = zodiac;
	}

	public String getIdIssuingOrgan() {
		return idIssuingOrgan;
	}

	public void setIdIssuingOrgan(String idIssuingOrgan) {
		this.idIssuingOrgan = idIssuingOrgan;
	}

	public String getValidDateBegin() {
		return validDateBegin;
	}

	public void setValidDateBegin(String validDateBegin) {
		this.validDateBegin = validDateBegin;
	}

	public String getValidDateEnd() {
		return validDateEnd;
	}

	public void setValidDateEnd(String validDateEnd) {
		this.validDateEnd = validDateEnd;
	}

	public String getIdAndNameMatch() {
		return idAndNameMatch;
	}

	public void setIdAndNameMatch(String idAndNameMatch) {
		this.idAndNameMatch = idAndNameMatch;
	}

	public String getSimilarityPass() {
		return similarityPass;
	}

	public void setSimilarityPass(String similarityPass) {
		this.similarityPass = similarityPass;
	}

	public String getIdFraudulent() {
		return idFraudulent;
	}

	public void setIdFraudulent(String idFraudulent) {
		this.idFraudulent = idFraudulent;
	}

	public String getFaceSourceConfidence() {
		return faceSourceConfidence;
	}

	public void setFaceSourceConfidence(String faceSourceConfidence) {
		this.faceSourceConfidence = faceSourceConfidence;
	}

	public String getFaceSourceThresholds() {
		return faceSourceThresholds;
	}

	public void setFaceSourceThresholds(String faceSourceThresholds) {
		this.faceSourceThresholds = faceSourceThresholds;
	}

	public String getFaceIdCardConfidence() {
		return faceIdCardConfidence;
	}

	public void setFaceIdCardConfidence(String faceIdCardConfidence) {
		this.faceIdCardConfidence = faceIdCardConfidence;
	}

	public String getFaceIdCardThresholds() {
		return faceIdCardThresholds;
	}

	public void setFaceIdCardThresholds(String faceIdCardThresholds) {
		this.faceIdCardThresholds = faceIdCardThresholds;
	}

	public String getIdAttacked() {
		return idAttacked;
	}

	public void setIdAttacked(String idAttacked) {
		this.idAttacked = idAttacked;
	}

	public String getProcedureValidation() {
		return procedureValidation;
	}

	public void setProcedureValidation(String procedureValidation) {
		this.procedureValidation = procedureValidation;
	}

	public String getProvinceLBS() {
		return provinceLBS;
	}

	public void setProvinceLBS(String provinceLBS) {
		this.provinceLBS = provinceLBS;
	}

	public String getCityLBS() {
		return cityLBS;
	}

	public void setCityLBS(String cityLBS) {
		this.cityLBS = cityLBS;
	}

}
