package com.macroflag.plusplatform.common.utils;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

/**
 * 消息模版工具类
 * @author :fredia
 * @since : 2017年10月23日
 * @version : v0.0.1
 */
public class MessageTemplateUtils {
	

	/**
	 * 消息模版拼装内容
	 * @param content 模版内容
	 * @param placeholder 模版占位符
	 * @param str 占位符对应的值, 注意这里需按顺序传入
	 * @return
	 * @author : fredia	
	 * @since : 2017年2月20日
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static String messageTemplateAssembly(String content, String placeholder, String... str) {
		String resultStr = null;
		Map<String, Object> map = null;

		if (!StringUtils.isEmpty(placeholder) && !StringUtils.isEmpty(content) && str != null
				&& str.length > 0) {
			String[] strings = placeholder.split(",");
			if (strings != null && strings.length > 0) {
				map = new HashMap<String, Object>();
				for (int i = 0; i < strings.length; i++) {
					map.put(strings[i], str[i]);
				}
			}
		}
		if (map != null) {
			Set set = map.entrySet();
			Iterator iterator = set.iterator();
			while (iterator.hasNext()) {
				Entry<String, Object> enter = (Entry<String, Object>) iterator.next();
				content = content.replace(
						enter.getKey().toUpperCase().toString(), enter.getValue().toString());
			}
			resultStr = content;
		}

		return resultStr;
	}

	/**
	 * 消息模版拼装内容
	 * @param content 模版内容
	 * @param placeholder 模版占位符
	 * @param object 占位符对象
	 * @return
	 * @author : fredia	
	 * @since : 2017年2月20日
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static String messageTemplateAssembly(String content, String placeholder, Object object) {
		String resultStr = null;
		Map<String, Object> map = null;

		if (!StringUtils.isEmpty(placeholder) && !StringUtils.isEmpty(content) && object != null) {
			String[] strings = placeholder.split(","); // 获取占位符对象名称数组
			Map<String, Object> objInfos = getFiledsInfo(object);// 获取对象属性名称数组
			if (strings != null && strings.length > 0 && objInfos != null) {
				map = new HashMap<String, Object>();
				for (int i = 0; i < strings.length; i++) {
					map.put(strings[i], objInfos.get(strings[i]) == null ? "" : objInfos.get(strings[i]).toString());
				}
			}
		}
		if (map != null) {
			Set set = map.entrySet();
			Iterator iterator = set.iterator();
			while (iterator.hasNext()) {
				Entry<String, Object> enter = (Entry<String, Object>) iterator.next();
				content = content.replace(
						enter.getKey().toUpperCase().toString(), enter.getValue().toString());
			}
			resultStr = content;
		}

		return resultStr;
	}
	
	/**
	 * 获取对象基本属性信息
	 * @param o
	 * @return
	 * @author : fredia	
	 * @since : 2017年3月19日
	 */
	private static Map<String, Object> getFiledsInfo(Object o) {
		Field[] fields = o.getClass().getDeclaredFields();
		Map<String, Object> infoMap = null;
		if (fields != null && fields.length > 0) {
			infoMap = new HashMap<String, Object>();
			for (int i = 0; i < fields.length; i++) {
				infoMap.put(fields[i].getName().toUpperCase().toString(), getFieldValueByName(fields[i].getName(), o) );
			}
		}
		return infoMap;
	}

	/**
	 * 根据属性名获取属性值 
	 * @param fieldName
	 * @param o
	 * @return
	 * @author : fredia	
	 * @since : 2017年3月19日
	 */
	private static Object getFieldValueByName(String fieldName, Object o) {
		try {
			String firstLetter = fieldName.substring(0, 1).toUpperCase();
			String getter = "get" + firstLetter + fieldName.substring(1);
			Method method = o.getClass().getMethod(getter, new Class[] {});
			Object value = method.invoke(o, new Object[] {});
			return value;
		} catch (Exception e) {
			e.printStackTrace();
			//log.error(e.getMessage(), e);	
		}
		return null;
	}

}
