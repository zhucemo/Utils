package com.macroflag.plusplatform.common.exception.type;

import org.springframework.http.HttpStatus;

import com.macroflag.plusplatform.common.exception.ErrorCode;

/**
 * 请求资源不存在异常
 * 
 * @author : fredia
 * @since : 2017年11月2日
 * @version : v0.0.1
 */
public class NotFoundException extends RestException {
	public NotFoundException(String message) {
		super(HttpStatus.NOT_FOUND, ErrorCode.NOT_FOUND, message);
	}
}
