package com.macroflag.plusplatform.common.core.pager.service;

import java.util.List;

import com.macroflag.plusplatform.common.base.Query;

/**
 * 分页接口
 * 
 * @author : fredia
 * @email : trumpey@163.com
 * @since : 2017年11月16日
 * @version : v0.0.1
 */
public interface IPagerService<T> {

	/**
	 * 查询总数
	 * 
	 * @param query
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :long
	 */
	public long queryCount(Query query);

	/**
	 * 结果集
	 * 
	 * @param query
	 * @return
	 * @author : fredia
	 * @since : 2017年11月16日
	 * @return :List<T>
	 */
	public List<T> queryList(Query query);
}
