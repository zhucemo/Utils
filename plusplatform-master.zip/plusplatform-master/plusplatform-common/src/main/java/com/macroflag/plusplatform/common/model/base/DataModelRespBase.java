package com.macroflag.plusplatform.common.model.base;

import java.io.Serializable;

/**
 * 规则系统 json-response 基础对象
 * 
 * @author : Fredia
 * @since : 2018年3月6日
 * @version : v1.0.0
 */
public class DataModelRespBase implements Serializable {

	private static final long serialVersionUID = 1L;
	/* 场景编码 */
	private String sceneCode;
	/* 业务主键 */
	private String businessKey;
	/* 响应时间 */
	private String rspTime;
	

	public String getSceneCode() {
		return sceneCode;
	}

	public void setSceneCode(String sceneCode) {
		this.sceneCode = sceneCode;
	}

	public String getBusinessKey() {
		return businessKey;
	}

	public String getRspTime() {
		return rspTime;
	}

	public void setRspTime(String rspTime) {
		this.rspTime = rspTime;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}




}
