package com.macroflag.plusplatform.common.model.req;

import java.io.Serializable;

/**
 * 提交登录(或查询详单)短信验证码请求model
 * @author huangf
 *
 */
public class ReqSubmitCaptchaModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * 业务主键(申请编号)
	 */
	private String businessKey;

	/**
	 * 令牌
	 */
	private String token;
	
	/**
	 * 短信验证码
	 */
	private String captcha;
	
	/**
	 * 用户唯一编号
	 */
	private String uniqueNo;

	public String getBusinessKey() {
		return businessKey;
	}

	public void setBusinessKey(String businessKey) {
		this.businessKey = businessKey;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getCaptcha() {
		return captcha;
	}

	public void setCaptcha(String captcha) {
		this.captcha = captcha;
	}

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
}
