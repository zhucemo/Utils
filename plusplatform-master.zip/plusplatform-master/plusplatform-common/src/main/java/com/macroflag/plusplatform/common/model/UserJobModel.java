package com.macroflag.plusplatform.common.model;

import java.io.Serializable;

public class UserJobModel implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/* 公司名称 */
	private String companyName;
	
	/* 单位电话 */
	private String companyPhone;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyPhone() {
		return companyPhone;
	}

	public void setCompanyPhone(String companyPhone) {
		this.companyPhone = companyPhone;
	}
	
	
}
