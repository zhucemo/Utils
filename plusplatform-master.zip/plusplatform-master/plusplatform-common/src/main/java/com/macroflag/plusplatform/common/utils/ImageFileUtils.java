package com.macroflag.plusplatform.common.utils;

import com.macroflag.plusplatform.common.component.SysConfigCache;
import com.macroflag.plusplatform.common.util.BeanUtils;
import org.csource.common.MyException;
import org.csource.common.NameValuePair;
import org.csource.fastdfs.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;

public class ImageFileUtils {
    /**
     * 采用指定宽度、高度或压缩比例 的方式对图片进行压缩
     *
     * @param imgsrc     源图片地址
     * @param imgdist    目标图片地址
     * @param widthdist  压缩后图片宽度（当rate==null时，必传）
     * @param heightdist 压缩后图片高度（当rate==null时，必传）
     * @param rate       压缩比例
     * @throws IOException
     */
    /**
     * created by Sugar 20180720
     */
    private static StorageClient storageClient;

    static {
        try {
            SysConfigCache sysConfigCache = BeanUtils.getBean(SysConfigCache.class);
            ClientGlobal.initByTrackers(sysConfigCache.getSysConfig("tracker_server"));
            // 3、创建一个TrackerClient对象。
            TrackerClient trackerClient = new TrackerClient();
            // 4、创建一个TrackerServer对象。
            TrackerServer trackerServer = trackerClient.getConnection();
            // 5、声明一个StorageServer对象，null。
            StorageServer storageServer = null;
            // 6、获得StorageClient对象。
            storageClient = new StorageClient(trackerServer, storageServer);
        } catch (IOException | MyException e) {
            e.printStackTrace();
        }
    }

    public static void reduceImg(String imgsrc, String imgdist, int widthdist,
                                 int heightdist, Float rate) throws IOException {
        FileOutputStream out = null;
        try {
            File srcfile = new File(imgsrc);
            // 检查文件是否存在
            if (!srcfile.exists()) {
                return;
            }
            // 如果rate不为空说明是按比例压缩
            if (rate != null && rate > 0) {
                // 获取文件高度和宽度
                int[] results = getImgWidth(srcfile);
                if (results == null || results[0] == 0 || results[1] == 0) {
                    return;
                } else {
                    widthdist = (int) (results[0] * rate);
                    heightdist = (int) (results[1] * rate);
                }
            }
            // 开始读取文件并进行压缩
            //由于face++对人脸比对接口上传的身份证图片尺寸要求不大于4096,所以在此处进行等比例压缩处理
            boolean widFlag = widthdist > 4095 ? true : false;
            boolean heiFlag = heightdist > 4095 ? true : false;
            if (widFlag || heiFlag) {
                while (widthdist > 4095) {
                    widthdist = (int) (widthdist * 0.8);
                    heightdist = (int) (heightdist * 0.8);
                }
                while (heightdist > 4095) {
                    widthdist = (int) (widthdist * 0.8);
                    heightdist = (int) (heightdist * 0.8);
                }
            }
            Image src = ImageIO.read(srcfile);
            BufferedImage tag = new BufferedImage((int) widthdist,
                    (int) heightdist, BufferedImage.TYPE_INT_RGB);

            tag.getGraphics().drawImage(
                    src.getScaledInstance(widthdist, heightdist,
                            Image.SCALE_SMOOTH), 0, 0, null);

            String formatName = imgdist.substring(imgdist.lastIndexOf(".") + 1);
            ImageIO.write(tag, formatName, new File(imgdist));
            
            /*out = new FileOutputStream(imgdist);  
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);  
            encoder.encode(tag);  
             out.close();  */


        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (out != null) {
                out.close();
            }
        }
    }

    /**
     * 获取图片宽度
     *
     * @param file 图片文件
     * @return 宽度
     * @throws IOException
     */
    public static int[] getImgWidth(File file) throws IOException {
        InputStream is = null;
        BufferedImage src = null;
        int result[] = {0, 0};
        try {
            is = new FileInputStream(file);
            src = ImageIO.read(is);
            result[0] = src.getWidth(null); //得到源图宽
            result[1] = src.getHeight(null); //得到源图高
            is.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != is) {
                is.close();
            }
        }
        return result;
    }

    /**
     * Created by Sugar 20180719
     */
    public static String uploadImage(File file) throws IOException, MyException {
        InputStream inputStream = new FileInputStream(file);
        String fileName = file.getName();
        String suffix = fileName.substring(fileName.lastIndexOf(".") + 1);
        int fileLength = inputStream.available();//获取文件大小
        NameValuePair[] metaList = new NameValuePair[3];
        metaList[0] = new NameValuePair("fileName", fileName);
        metaList[1] = new NameValuePair("fileExtName", suffix);
        metaList[2] = new NameValuePair("fileLength", String.valueOf(fileLength));
        byte[] bytes1 = new byte[inputStream.available() + 100];
        inputStream.read(bytes1);
        inputStream.close();
        String[] strings = storageClient.upload_file(bytes1, suffix, metaList);
        return strings[0] + "/" + strings[1];
    }

    public static String uploadImage(byte[] fileByte, String suffix) throws IOException, MyException {
        NameValuePair[] metaList = new NameValuePair[3];
        metaList[0] = new NameValuePair("fileName", "sugar_image");
        metaList[1] = new NameValuePair("fileExtName", suffix);
        metaList[2] = new NameValuePair("fileLength", String.valueOf(fileByte.length));
        String[] strings = storageClient.upload_file(fileByte, suffix, metaList);
        return strings[0] + "/" + strings[1];
    }

    public static byte[] downFileByte(String filePath) throws IOException, MyException {
        String groupName = filePath.substring(0, filePath.indexOf("/"));
        String remoteName = filePath.substring(filePath.indexOf("/") + 1);
        return storageClient.download_file(groupName, remoteName);
    }
}
