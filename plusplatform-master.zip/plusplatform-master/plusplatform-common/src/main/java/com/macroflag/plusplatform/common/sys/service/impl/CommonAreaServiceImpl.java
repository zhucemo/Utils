package com.macroflag.plusplatform.common.sys.service.impl;

import com.macroflag.plusplatform.common.core.service.impl.BaseServiceImpl;
import com.macroflag.plusplatform.common.entity.CommonAreaDomain;
import com.macroflag.plusplatform.common.mapper.nongeneric.CommonAreaMapper;
import com.macroflag.plusplatform.common.sys.service.ICommonAreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * 用户的业务实现类
 * @author : fredia
 * @since : 2018年05月09日
 * @version : v0.0.1
 */
@Service("commonAreaService")
public class CommonAreaServiceImpl extends BaseServiceImpl<CommonAreaDomain> implements ICommonAreaService {
	
	@Autowired
	private CommonAreaMapper commonAreaMapper;
	
}
