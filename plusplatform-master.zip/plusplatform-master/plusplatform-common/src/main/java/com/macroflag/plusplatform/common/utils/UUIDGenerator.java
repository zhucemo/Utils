package com.macroflag.plusplatform.common.utils;

import java.util.UUID;

/**

 * 

 */

public class UUIDGenerator {
	public static String get32UUID() {
		return UUID.randomUUID().toString().trim().replaceAll("-", "");
	}
}
