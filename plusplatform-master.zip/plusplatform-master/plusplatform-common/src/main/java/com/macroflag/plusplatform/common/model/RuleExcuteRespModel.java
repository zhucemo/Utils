package com.macroflag.plusplatform.common.model;



import java.util.Map;

import com.macroflag.plusplatform.common.model.base.DataModelRespBase;

/**
 * 请求规则系统 json response对象
 * 
 * @author : Fredia
 * @since : 2018年2月11日
 * @version : v1.0.0
 */
public class RuleExcuteRespModel extends DataModelRespBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/* 执行状况 */
	private String result;
	/* 原因 */
	private String reason;
	/* 最后一步执行结果 */
	private Map<String, Object> preStepMap;
	/* 累计执行结果 */
	private Map<String, Object> rspMap;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Map<String, Object> getPreStepMap() {
		return preStepMap;
	}

	public void setPreStepMap(Map<String, Object> preStepMap) {
		this.preStepMap = preStepMap;
	}

	public Map<String, Object> getRspMap() {
		return rspMap;
	}

	public void setRspMap(Map<String, Object> rspMap) {
		this.rspMap = rspMap;
	}

	
	
}
