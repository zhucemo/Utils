
package com.macroflag.plusplatform.auth.server.module.client.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.macroflag.plusplatform.auth.server.module.client.entity.GatewayRoute;
import com.macroflag.plusplatform.auth.server.module.client.mapper.GatewayRouteMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;
import com.macroflag.plusplatform.common.constant.RedisKeyConstants;

@Service
public class GatewayRouteBiz extends BusinessBiz<GatewayRouteMapper, GatewayRoute> {
	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	@Override
	public void updateSelectiveById(GatewayRoute entity) {
		super.updateSelectiveById(entity);
		updateGatewayRoute();
	}

	@Override
	public void insertSelective(GatewayRoute entity) {
		super.insertSelective(entity);
		updateGatewayRoute();
	}

	@Override
	public void deleteById(Object id) {
		GatewayRoute gatewayRoute = this.selectById(id);
		gatewayRoute.setEnabled(false);
		// super.deleteById(id);
		this.updateSelectiveById(gatewayRoute);
	}

	@Override
	public void updateById(GatewayRoute entity) {
		super.updateById(entity);
		updateGatewayRoute();
	}

	public void updateGatewayRoute() {
		List<GatewayRoute> gatewayRoutes = this.selectListAll();
		redisTemplate.opsForValue().set(RedisKeyConstants.ZUUL_ROUTE_KEY, JSON.toJSONString(gatewayRoutes));
	}

}