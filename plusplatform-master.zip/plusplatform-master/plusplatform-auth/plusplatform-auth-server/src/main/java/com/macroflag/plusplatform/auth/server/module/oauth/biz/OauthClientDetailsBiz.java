package com.macroflag.plusplatform.auth.server.module.oauth.biz;

import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.auth.server.module.oauth.entity.OauthClientDetails;
import com.macroflag.plusplatform.auth.server.module.oauth.mapper.OauthClientDetailsMapper;
import com.macroflag.plusplatform.common.biz.BusinessBiz;

@Service
public class OauthClientDetailsBiz extends BusinessBiz<OauthClientDetailsMapper, OauthClientDetails> {

}