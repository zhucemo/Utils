
package com.macroflag.plusplatform.auth.server.module.client.biz;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.macroflag.plusplatform.auth.server.module.client.entity.Client;
import com.macroflag.plusplatform.auth.server.module.client.entity.ClientService;
import com.macroflag.plusplatform.auth.server.module.client.mapper.ClientMapper;
import com.macroflag.plusplatform.auth.server.module.client.mapper.ClientServiceMapper;
import com.macroflag.plusplatform.common.biz.BaseBiz;

/**
 * Client 服务
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
@Service
public class ClientBiz extends BaseBiz<ClientMapper, Client> {
	@Autowired
	private ClientServiceMapper clientServiceMapper;
	@Autowired
	private ClientServiceBiz clientServiceBiz;

	public List<Client> getClientServices(String id) {
		return mapper.selectAuthorityServiceInfo(id);
	}

	public void modifyClientServices(String id, String clients) {
		clientServiceMapper.deleteByServiceId(id);
		if (!StringUtils.isEmpty(clients)) {
			String[] mem = clients.split(",");
			for (String m : mem) {
				ClientService clientService = new ClientService();
				clientService.setServiceId(m);
				clientService.setClientId(id + "");
				clientServiceBiz.insertSelective(clientService);
			}
		}
	}
}
