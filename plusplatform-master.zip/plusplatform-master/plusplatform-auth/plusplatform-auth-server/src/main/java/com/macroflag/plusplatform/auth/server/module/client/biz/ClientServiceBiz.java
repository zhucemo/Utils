
package com.macroflag.plusplatform.auth.server.module.client.biz;

import org.springframework.stereotype.Service;

import com.macroflag.plusplatform.auth.server.module.client.entity.ClientService;
import com.macroflag.plusplatform.auth.server.module.client.mapper.ClientServiceMapper;
import com.macroflag.plusplatform.common.biz.BaseBiz;

@Service
public class ClientServiceBiz extends BaseBiz<ClientServiceMapper, ClientService> {
}
