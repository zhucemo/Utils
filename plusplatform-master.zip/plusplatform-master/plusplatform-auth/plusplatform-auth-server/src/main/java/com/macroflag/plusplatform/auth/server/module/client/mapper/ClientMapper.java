
package com.macroflag.plusplatform.auth.server.module.client.mapper;

import java.util.List;

import com.macroflag.plusplatform.auth.server.module.client.entity.Client;
import com.macroflag.plusplatform.common.mapper.CommonMapper;

public interface ClientMapper extends CommonMapper<Client> {
	List<String> selectAllowedClient(String serviceId);

	List<Client> selectAuthorityServiceInfo(String clientId);
}
