
package com.macroflag.plusplatform.auth.server.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.macroflag.plusplatform.auth.server.interceptor.ClientTokenInterceptor;

@Configuration
public class FeignConfiguration {
	@Bean
	ClientTokenInterceptor getClientTokenInterceptor() {
		return new ClientTokenInterceptor();
	}
}
