
package com.macroflag.plusplatform.auth.client.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;

import com.macroflag.plusplatform.auth.client.config.ServiceAuthConfig;
import com.macroflag.plusplatform.auth.client.config.UserAuthConfig;
import com.macroflag.plusplatform.auth.client.feign.ServiceAuthFeign;
import com.macroflag.plusplatform.common.msg.BaseResponse;
import com.macroflag.plusplatform.common.msg.ObjectRestResponse;

import lombok.extern.slf4j.Slf4j;

/**
 * 监听完成时触发
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
@Configuration
@Slf4j
public class AuthClientRunner implements CommandLineRunner {

	@Autowired
	private ServiceAuthConfig serviceAuthConfig;
	@Autowired
	private UserAuthConfig userAuthConfig;
	@Autowired
	private ServiceAuthFeign serviceAuthFeign;

	@Override
	public void run(String... args) throws Exception {
		log.info("初始化加载用户pubKey");
		try {
			refreshUserPubKey();
		} catch (Exception e) {
			log.error("初始化加载用户pubKey失败,1分钟后自动重试!", e);
		}
		log.info("初始化加载客户pubKey");
		try {
			refreshServicePubKey();
		} catch (Exception e) {
			log.error("初始化加载客户pubKey失败,1分钟后自动重试!", e);
		}
	}

	@Scheduled(cron = "0 0/1 * * * ?")
	public void refreshUserPubKey() {
		BaseResponse resp = serviceAuthFeign.getUserPublicKey(serviceAuthConfig.getClientId(),
				serviceAuthConfig.getClientSecret());
		if (resp.getStatus() == HttpStatus.OK.value()) {
			ObjectRestResponse<byte[]> userResponse = (ObjectRestResponse<byte[]>) resp;
			this.userAuthConfig.setPubKeyByte(userResponse.getData());
		}
	}

	@Scheduled(cron = "0 0/1 * * * ?")
	public void refreshServicePubKey() {
		BaseResponse resp = serviceAuthFeign.getServicePublicKey(serviceAuthConfig.getClientId(),
				serviceAuthConfig.getClientSecret());
		if (resp.getStatus() == HttpStatus.OK.value()) {
			ObjectRestResponse<byte[]> userResponse = (ObjectRestResponse<byte[]>) resp;
			this.serviceAuthConfig.setPubKeyByte(userResponse.getData());
		}
	}
}
