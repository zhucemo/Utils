
package com.macroflag.plusplatform.auth.client;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.context.annotation.Import;

import com.macroflag.plusplatform.auth.client.configuration.AutoConfiguration;

/**
 * 授权客户端
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Import(AutoConfiguration.class)
@Documented
@Inherited
public @interface EnableFeAuthClient {
}
