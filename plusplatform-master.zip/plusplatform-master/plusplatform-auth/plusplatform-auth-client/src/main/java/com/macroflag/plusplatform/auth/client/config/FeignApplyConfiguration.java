
package com.macroflag.plusplatform.auth.client.config;

import org.springframework.context.annotation.Bean;

import com.macroflag.plusplatform.auth.client.interceptor.ServiceFeignInterceptor;

public class FeignApplyConfiguration {
	@Bean
	ServiceFeignInterceptor getClientTokenInterceptor() {
		return new ServiceFeignInterceptor();
	}
}
