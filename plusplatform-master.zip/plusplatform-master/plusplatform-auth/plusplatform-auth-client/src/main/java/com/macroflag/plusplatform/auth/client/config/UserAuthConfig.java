
package com.macroflag.plusplatform.auth.client.config;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;

/**
 * 用户鉴权属性
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
public class UserAuthConfig {

	@Value("${auth.user.token-header}")
	private String tokenHeader;
	@Value("${auth.user.limit-expire}")
	private Integer tokenLimitExpire;

	private byte[] pubKeyByte;

	public String getTokenHeader() {
		return tokenHeader;
	}

	public void setTokenHeader(String tokenHeader) {
		this.tokenHeader = tokenHeader;
	}

	public String getToken(HttpServletRequest request) {
		return request.getHeader(this.getTokenHeader());
	}

	public byte[] getPubKeyByte() {
		return pubKeyByte;
	}

	public void setPubKeyByte(byte[] pubKeyByte) {
		this.pubKeyByte = pubKeyByte;
	}

	public Integer getTokenLimitExpire() {
		return tokenLimitExpire;
	}

	public void setTokenLimitExpire(Integer tokenLimitExpire) {
		this.tokenLimitExpire = tokenLimitExpire;
	}
}
