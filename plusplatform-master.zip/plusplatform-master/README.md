# PlusPlatform

#### 项目介绍
PlusPlatform

#### 软件架构
详见`doc/架构设计/后管系统架构图v1.0.0.pdf`


#### 安装教程

1. JDK1.8+
2. RabbitMQ一个
3. Redis一个
4. Mysql执行`doc/DB`下面所以sql文件

#### 使用说明
#####一. 必启项
1. 执行`plusplatform-center/CenterBootstrap`,启动**EurekaServer**
2. 执行`plusplatform-auth/plusplatform-auth-server/AuthBootstrap`,启动**鉴权中心**
3. 执行`plusplatform-gate/plusplatform-gate-server/GateBootstrap`,启动**Zuul网关**
4. 执行`plusplatform-modules/plusplatform-admin/AdminBootstrap`,启动**后管服务**
5. 执行`plusplatform-modules/plusplatform-dict/DictBootstrap`,启动**字典服务**

#####二. 可选项
1. 执行`plusplatform-control/plusplatform-monitor/MonitorBootstrap`,启动**服务Admin**
2. 执行`plusplatform-control/plusplatform-trace/TraceBootstrap`,启动**Zipkin日志服务**
3. 执行`plusplatform-generator/GeneratorBootstrap`,启动**代码生成器**
4. 使用`jetty:run`运行`plusplatform-job/xxl-job-admin`,启动**XXL-Job调度服务**

#####三. Demo项
1. `plusplatform-merge-parent/plusplatform-merge-demo`:**服务聚合demo**
2. `plusplatform-transaction/plusplatform-transaction-demo`:**分布式事务解决demo**
3. `plusplatform-job/xxl-job-executor-samples`:**分布式定时任务demo**
4. `plusplatform-cache/com.macroflag.plusplatform.cache`:**SpringCache自定缓存demo**

#####四. 文档
详见`doc/*`目录
