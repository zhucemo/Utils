
package com.macroflag.plusplatform.gate.ratelimit.config.repository.springdata;

import com.macroflag.plusplatform.gate.ratelimit.config.Rate;
import com.macroflag.plusplatform.gate.ratelimit.config.repository.AbstractRateLimiter;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class SpringDataRateLimiter extends AbstractRateLimiter {

	private final IRateLimiterRepository repository;

	@Override
	protected Rate getRate(String key) {
		return this.repository.findOne(key);
	}

	@Override
	protected void saveRate(Rate rate) {
		this.repository.save(rate);
	}

}
