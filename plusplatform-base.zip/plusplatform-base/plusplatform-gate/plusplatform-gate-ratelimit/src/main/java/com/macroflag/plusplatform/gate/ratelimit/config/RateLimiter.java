
package com.macroflag.plusplatform.gate.ratelimit.config;

import com.macroflag.plusplatform.gate.ratelimit.config.properties.RateLimitProperties.Policy;

/**
 * 限流基类
 * 
 * @author : Fredia
 * @since : 2018年6月7日
 * @version : v1.0.0
 */
public interface RateLimiter {

	Rate consume(Policy policy, String key);
}
