
package com.macroflag.plusplatform.gate.ratelimit.config;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Rate {

	@Id
	private String key;
	private Long remaining;
	private Long reset;
	private Date expiration;

}
