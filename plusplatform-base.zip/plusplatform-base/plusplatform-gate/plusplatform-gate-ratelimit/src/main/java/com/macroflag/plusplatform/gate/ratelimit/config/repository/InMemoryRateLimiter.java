
package com.macroflag.plusplatform.gate.ratelimit.config.repository;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.macroflag.plusplatform.gate.ratelimit.config.Rate;

/**
 * 内存模式
 * 
 * @author : Fredia
 * @since : 2018年6月7日
 * @version : v1.0.0
 */
public class InMemoryRateLimiter extends AbstractRateLimiter {

	private Map<String, Rate> repository = new ConcurrentHashMap<>();

	@Override
	protected Rate getRate(String key) {
		return this.repository.get(key);
	}

	@Override
	protected void saveRate(Rate rate) {
		this.repository.put(rate.getKey(), rate);
	}

}
