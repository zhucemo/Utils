
package com.macroflag.plusplatform.gate.ratelimit.config;

import javax.servlet.http.HttpServletRequest;

/**
 * 默认用户领域
 * 
 * @author : Fredia
 * @since : 2018年6月7日
 * @version : v1.0.0
 */
public class DefaultUserPrincipal implements IUserPrincipal {
	@Override
	public String getName(HttpServletRequest request) {
		if (request.getUserPrincipal() == null) {
			return null;
		}
		return request.getUserPrincipal().getName();
	}
}
