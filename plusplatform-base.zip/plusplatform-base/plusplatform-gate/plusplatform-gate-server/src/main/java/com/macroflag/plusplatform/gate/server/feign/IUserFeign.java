
package com.macroflag.plusplatform.gate.server.feign;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.macroflag.plusplatform.api.vo.authority.PermissionInfo;
import com.macroflag.plusplatform.gate.server.config.FeignConfiguration;

@FeignClient(value = "plusplatform-admin", configuration = FeignConfiguration.class)
public interface IUserFeign {
	/**
	 * 获取用户的菜单和按钮权限
	 * 
	 * @return
	 */
	@RequestMapping(value = "/api/user/permissions", method = RequestMethod.GET)
	public List<PermissionInfo> getPermissionByUsername();

	/**
	 * 获取所有菜单和按钮权限
	 * 
	 * @return
	 */
	@RequestMapping(value = "/api/permissions", method = RequestMethod.GET)
	List<PermissionInfo> getAllPermissionInfo();
}
