
package com.macroflag.plusplatform.gate.server.feign;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.macroflag.plusplatform.api.vo.log.LogInfo;

@FeignClient("plusplatform-admin")
public interface ILogFeign {
	@RequestMapping(value = "/api/log/save", method = RequestMethod.POST)
	public void saveLog(LogInfo info);
}
