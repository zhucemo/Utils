
package com.macroflag.plusplatform.gate.server.config;

import org.springframework.context.annotation.Bean;

import com.macroflag.plusplatform.auth.client.interceptor.ServiceFeignInterceptor;

public class FeignConfiguration {
	@Bean
	ServiceFeignInterceptor getClientTokenInterceptor() {
		return new ServiceFeignInterceptor();
	}
}
