
package com.macroflag.plusplatform.auth.client.feign;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.macroflag.plusplatform.common.msg.ObjectRestResponse;

@FeignClient(value = "${auth.serviceId}", configuration = {})
public interface ServiceAuthFeign {
	@RequestMapping(value = "/client/myClient")
	public ObjectRestResponse<List<String>> getAllowedClient(@RequestParam("serviceId") String serviceId,
			@RequestParam("secret") String secret);

	@RequestMapping(value = "/client/token", method = RequestMethod.POST)
	public ObjectRestResponse getAccessToken(@RequestParam("clientId") String clientId,
			@RequestParam("secret") String secret);

	@RequestMapping(value = "/client/servicePubKey", method = RequestMethod.POST)
	public ObjectRestResponse<byte[]> getServicePublicKey(@RequestParam("clientId") String clientId,
			@RequestParam("secret") String secret);

	@RequestMapping(value = "/client/userPubKey", method = RequestMethod.POST)
	public ObjectRestResponse<byte[]> getUserPublicKey(@RequestParam("clientId") String clientId,
			@RequestParam("secret") String secret);

}
