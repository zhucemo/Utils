
package com.macroflag.plusplatform.auth.client.exception;

public class JwtIllegalArgumentException extends Exception {
	public JwtIllegalArgumentException(String s) {
		super(s);
	}
}
