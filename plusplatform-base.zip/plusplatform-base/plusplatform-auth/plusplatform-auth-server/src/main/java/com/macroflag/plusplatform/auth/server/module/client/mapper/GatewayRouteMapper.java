package com.macroflag.plusplatform.auth.server.module.client.mapper;

import com.macroflag.plusplatform.auth.server.module.client.entity.GatewayRoute;
import com.macroflag.plusplatform.common.mapper.CommonMapper;

public interface GatewayRouteMapper extends CommonMapper<GatewayRoute> {

}
