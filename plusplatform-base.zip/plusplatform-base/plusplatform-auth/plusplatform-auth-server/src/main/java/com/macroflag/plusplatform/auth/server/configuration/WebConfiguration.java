
package com.macroflag.plusplatform.auth.server.configuration;

import java.util.ArrayList;
import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.macroflag.plusplatform.auth.server.interceptor.ServiceAuthRestInterceptor;
import com.macroflag.plusplatform.auth.server.interceptor.UserAuthRestInterceptor;
import com.macroflag.plusplatform.common.handler.GlobalExceptionHandler;

@Configuration("admimWebConfig")
@Primary
public class WebConfiguration extends WebMvcConfigurerAdapter {
	@Bean
	GlobalExceptionHandler getGlobalExceptionHandler() {
		return new GlobalExceptionHandler();
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		ArrayList<String> commonPathPatterns = getExcludeCommonPathPatterns();
		registry.addInterceptor(getServiceAuthRestInterceptor()).addPathPatterns("/**")
				.excludePathPatterns(commonPathPatterns.toArray(new String[] {}));
		registry.addInterceptor(getUserAuthRestInterceptor()).addPathPatterns("/**")
				.excludePathPatterns(commonPathPatterns.toArray(new String[] {}));
		super.addInterceptors(registry);
	}

	@Bean
	ServiceAuthRestInterceptor getServiceAuthRestInterceptor() {
		return new ServiceAuthRestInterceptor();
	}

	@Bean
	UserAuthRestInterceptor getUserAuthRestInterceptor() {
		return new UserAuthRestInterceptor();
	}

	private ArrayList<String> getExcludeCommonPathPatterns() {
		ArrayList<String> list = new ArrayList<>();
		String[] urls = { "/v2/api-docs", "/swagger-resources/**", "/client/**", "/jwt/**", "/oauth/**", "/login",
				"/error" };
		Collections.addAll(list, urls);
		return list;
	}

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/login").setViewName("login");
		registry.addViewController("/oauth/confirm_access").setViewName("authorize");
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/static/**").addResourceLocations("classpath:/static/");
	}
}
