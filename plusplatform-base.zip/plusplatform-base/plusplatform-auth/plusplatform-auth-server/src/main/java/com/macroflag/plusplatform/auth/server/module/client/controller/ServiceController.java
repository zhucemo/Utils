
package com.macroflag.plusplatform.auth.server.module.client.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.macroflag.plusplatform.auth.server.module.client.biz.ClientBiz;
import com.macroflag.plusplatform.auth.server.module.client.entity.Client;
import com.macroflag.plusplatform.common.msg.ObjectRestResponse;
import com.macroflag.plusplatform.common.rest.BaseController;

@RestController
@RequestMapping("service")
public class ServiceController extends BaseController<ClientBiz, Client, String> {

	@RequestMapping(value = "/{id}/client", method = RequestMethod.PUT)
	@ResponseBody
	public ObjectRestResponse modifyUsers(@PathVariable String id, String clients) {
		baseBiz.modifyClientServices(id, clients);
		return new ObjectRestResponse();
	}

	@RequestMapping(value = "/{id}/client", method = RequestMethod.GET)
	@ResponseBody
	public ObjectRestResponse<List<Client>> getUsers(@PathVariable String id) {
		ObjectRestResponse<List<Client>> entityObjectRestResponse = new ObjectRestResponse<>();
		Object o = baseBiz.getClientServices(id);
		entityObjectRestResponse.data((List<Client>) o);
		return entityObjectRestResponse;
	}
}
