
package com.macroflag.plusplatform.auth.server.module.client.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.macroflag.plusplatform.auth.server.module.client.biz.GatewayRouteBiz;
import com.macroflag.plusplatform.auth.server.module.client.entity.GatewayRoute;
import com.macroflag.plusplatform.common.rest.BaseController;

@RestController
@RequestMapping("gatewayRoute")
public class GatewayRouteController extends BaseController<GatewayRouteBiz, GatewayRoute, String> {

}