
package com.macroflag.plusplatform.auth.server.feign;

import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.macroflag.plusplatform.auth.server.configuration.FeignConfiguration;
import com.macroflag.plusplatform.common.msg.ObjectRestResponse;

/**
 * Feign用户服务
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
@FeignClient(value = "${jwt.user-service}", configuration = FeignConfiguration.class)
public interface IUserService {
	/**
	 * 通过账户\密码的方式登陆
	 * 
	 * @param username
	 * @param password
	 * @return
	 * @author : Fredia
	 * @since : 2018年6月6日
	 * @return :ObjectRestResponse<Map<String,String>>
	 */
	@RequestMapping(value = "/user/validate", method = RequestMethod.POST)
	public ObjectRestResponse<Map<String, String>> validate(@RequestParam("username") String username,
			@RequestParam("password") String password);

	@RequestMapping(value = "/user/info", method = RequestMethod.POST)
	public ObjectRestResponse<Map<String, String>> getUserInfoByUsername(@RequestParam("username") String username);
}
