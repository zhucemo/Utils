
package com.macroflag.plusplatform.auth.server.module.oauth.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.macroflag.plusplatform.auth.server.module.oauth.biz.OauthClientDetailsBiz;
import com.macroflag.plusplatform.auth.server.module.oauth.entity.OauthClientDetails;
import com.macroflag.plusplatform.common.rest.BaseController;

@RestController
@RequestMapping("oauthClientDetails")
public class OauthClientDetailsController extends BaseController<OauthClientDetailsBiz, OauthClientDetails, String> {

}