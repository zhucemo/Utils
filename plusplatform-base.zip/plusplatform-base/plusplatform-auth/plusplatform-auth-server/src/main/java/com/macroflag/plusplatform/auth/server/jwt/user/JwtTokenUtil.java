
package com.macroflag.plusplatform.auth.server.jwt.user;

import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.macroflag.plusplatform.auth.server.configuration.KeyConfiguration;
import com.macroflag.plusplatform.jwt.util.jwt.IJWTInfo;
import com.macroflag.plusplatform.jwt.util.jwt.JWTHelper;

@Component
public class JwtTokenUtil {

	public int getExpire() {
		return expire;
	}

	@Value("${jwt.expire}")
	private int expire;

	@Autowired
	private KeyConfiguration keyConfiguration;

	@Autowired
	private JWTHelper jwtHelper;

	public String generateToken(IJWTInfo jwtInfo, Map<String, String> otherInfo, Date expireTime) throws Exception {
		return jwtHelper.generateToken(jwtInfo, keyConfiguration.getUserPriKey(), expireTime, otherInfo);
	}

	public IJWTInfo getInfoFromToken(String token) throws Exception {
		IJWTInfo infoFromToken = jwtHelper.getInfoFromToken(token, keyConfiguration.getUserPubKey());
		return infoFromToken;
	}

}
