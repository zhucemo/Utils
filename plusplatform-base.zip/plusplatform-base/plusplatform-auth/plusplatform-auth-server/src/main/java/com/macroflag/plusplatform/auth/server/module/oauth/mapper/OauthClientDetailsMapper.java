package com.macroflag.plusplatform.auth.server.module.oauth.mapper;

import com.macroflag.plusplatform.auth.server.module.oauth.entity.OauthClientDetails;
import com.macroflag.plusplatform.common.mapper.CommonMapper;

public interface OauthClientDetailsMapper extends CommonMapper<OauthClientDetails> {

}
