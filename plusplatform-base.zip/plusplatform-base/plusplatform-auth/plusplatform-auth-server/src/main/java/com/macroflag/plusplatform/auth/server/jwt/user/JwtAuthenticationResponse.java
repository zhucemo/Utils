
package com.macroflag.plusplatform.auth.server.jwt.user;

import java.io.Serializable;

import com.macroflag.plusplatform.common.constant.RequestHeaderConstants;

public class JwtAuthenticationResponse implements Serializable {
	private static final long serialVersionUID = 1250166508152483573L;

	private final String token;

	public JwtAuthenticationResponse(String token) {

		this.token = RequestHeaderConstants.JWT_TOKEN_TYPE + token;
	}

	public String getToken() {
		return this.token;
	}
}
