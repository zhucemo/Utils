
package com.macroflag.plusplatform.auth.server.constant;

public class RedisKeyConstant {
	public static final String REDIS_USER_PRI_KEY = "FE:AUTH:JWT:PRI";
	public static final String REDIS_USER_PUB_KEY = "FE:AUTH:JWT:PUB";
	public static final String REDIS_SERVICE_PRI_KEY = "FE:AUTH:CLIENT:PRI";
	public static final String REDIS_SERVICE_PUB_KEY = "FE:AUTH:CLIENT:PUB";
}
