
package com.macroflag.plusplatform.auth.server.module.client.mapper;

import com.macroflag.plusplatform.auth.server.module.client.entity.ClientService;
import com.macroflag.plusplatform.common.mapper.CommonMapper;

public interface ClientServiceMapper extends CommonMapper<ClientService> {
	void deleteByServiceId(String id);
}
