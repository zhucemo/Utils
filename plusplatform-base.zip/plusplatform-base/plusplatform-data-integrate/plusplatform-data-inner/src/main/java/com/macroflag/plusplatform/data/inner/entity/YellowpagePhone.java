package com.macroflag.plusplatform.data.inner.entity;

import java.util.Date;
import javax.persistence.*;

@Table(name = "inner_yellowpage_phone")
public class YellowpagePhone {
    /**
     * 主键
     */
    @Id
    private Long id;

    /**
     * 号码
     */
    @Column(name = "phone_nbr")
    private String phoneNbr;

    /**
     * 来源
     */
    private Integer source;

    private String institute;

    /**
     * 分类一
     */
    private String category1;

    /**
     * 分类二
     */
    private String category2;

    /**
     * 分类三
     */
    private String category3;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    private Date createTime;

    /**
     * 创建用户
     */
    @Column(name = "create_user")
    private String createUser;

    @Column(name = "update_time")
    private Date updateTime;

    @Column(name = "update_user")
    private Date updateUser;

    /**
     * 获取主键
     *
     * @return id - 主键
     */
    public Long getId() {
        return id;
    }

    /**
     * 设置主键
     *
     * @param id 主键
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * 获取号码
     *
     * @return phone_nbr - 号码
     */
    public String getPhoneNbr() {
        return phoneNbr;
    }

    /**
     * 设置号码
     *
     * @param phoneNbr 号码
     */
    public void setPhoneNbr(String phoneNbr) {
        this.phoneNbr = phoneNbr;
    }

    /**
     * 获取来源
     *
     * @return source - 来源
     */
    public Integer getSource() {
        return source;
    }

    /**
     * 设置来源
     *
     * @param source 来源
     */
    public void setSource(Integer source) {
        this.source = source;
    }

    /**
     * @return institute
     */
    public String getInstitute() {
        return institute;
    }

    /**
     * @param institute
     */
    public void setInstitute(String institute) {
        this.institute = institute;
    }

    /**
     * 获取分类一
     *
     * @return category1 - 分类一
     */
    public String getCategory1() {
        return category1;
    }

    /**
     * 设置分类一
     *
     * @param category1 分类一
     */
    public void setCategory1(String category1) {
        this.category1 = category1;
    }

    /**
     * 获取分类二
     *
     * @return category2 - 分类二
     */
    public String getCategory2() {
        return category2;
    }

    /**
     * 设置分类二
     *
     * @param category2 分类二
     */
    public void setCategory2(String category2) {
        this.category2 = category2;
    }

    /**
     * 获取分类三
     *
     * @return category3 - 分类三
     */
    public String getCategory3() {
        return category3;
    }

    /**
     * 设置分类三
     *
     * @param category3 分类三
     */
    public void setCategory3(String category3) {
        this.category3 = category3;
    }

    /**
     * 获取创建时间
     *
     * @return create_time - 创建时间
     */
    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 设置创建时间
     *
     * @param createTime 创建时间
     */
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    /**
     * 获取创建用户
     *
     * @return create_user - 创建用户
     */
    public String getCreateUser() {
        return createUser;
    }

    /**
     * 设置创建用户
     *
     * @param createUser 创建用户
     */
    public void setCreateUser(String createUser) {
        this.createUser = createUser;
    }

    /**
     * @return update_time
     */
    public Date getUpdateTime() {
        return updateTime;
    }

    /**
     * @param updateTime
     */
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    /**
     * @return update_user
     */
    public Date getUpdateUser() {
        return updateUser;
    }

    /**
     * @param updateUser
     */
    public void setUpdateUser(Date updateUser) {
        this.updateUser = updateUser;
    }
}