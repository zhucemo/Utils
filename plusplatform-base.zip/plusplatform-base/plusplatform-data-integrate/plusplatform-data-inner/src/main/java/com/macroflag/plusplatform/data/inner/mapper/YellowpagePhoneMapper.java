package com.macroflag.plusplatform.data.inner.mapper;

import com.macroflag.plusplatform.data.inner.entity.YellowpagePhone;
import tk.mybatis.mapper.common.Mapper;

public interface YellowpagePhoneMapper extends Mapper<YellowpagePhone> {
}