
package com.macroflag.plusplatform.data.inner;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.macroflag.plusplatform.auth.client.EnableFeAuthClient;
import com.macroflag.plusplatform.cache.EnableFeCache;
import com.macroflag.plusplatform.merge.EnableFeMerge;
import com.spring4all.swagger.EnableSwagger2Doc;

@EnableEurekaClient
@EnableCircuitBreaker
@SpringBootApplication
@EnableFeignClients({ "com.macroflag.plusplatform.auth.client.feign", "com.macroflag.plusplatform.data.inner.feign" })
@EnableScheduling
@EnableFeCache
@EnableTransactionManagement
@MapperScan("com.macroflag.plusplatform.data.inner.mapper")
@EnableFeAuthClient
@EnableSwagger2Doc
@EnableFeMerge
public class DataInnerBootstrap {
	public static void main(String[] args) {
		new SpringApplicationBuilder(DataInnerBootstrap.class).web(true).run(args);
	}
}
