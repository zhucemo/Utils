
package com.macroflag.plusplatform.common.handler;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.macroflag.plusplatform.common.exception.auth.ClientTokenException;
import com.macroflag.plusplatform.common.exception.auth.NonLoginException;
import com.macroflag.plusplatform.common.exception.auth.UserInvalidException;
import com.macroflag.plusplatform.common.exception.base.BusinessException;
import com.macroflag.plusplatform.common.msg.BaseResponse;
import com.macroflag.plusplatform.jwt.exception.BaseException;

/**
 * 全局异常拦截处理器
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
@ControllerAdvice("com.macroflag.plusplatform")
@ResponseBody
public class GlobalExceptionHandler {
	private Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@ExceptionHandler(BaseException.class)
	public BaseResponse baseExceptionHandler(HttpServletResponse response, BaseException ex) {
		logger.error(ex.getMessage(), ex);
		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		return new BaseResponse(ex.getStatus(), ex.getMessage());
	}

	@ExceptionHandler(Exception.class)
	public BaseResponse otherExceptionHandler(HttpServletResponse response, Exception ex) {
		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		logger.error(ex.getMessage(), ex);
		return new BaseResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), ex.getMessage());
	}

	@ExceptionHandler(ClientTokenException.class)
	public BaseResponse clientTokenExceptionHandler(HttpServletResponse response, ClientTokenException ex) {
		response.setStatus(HttpStatus.FORBIDDEN.value());
		logger.error(ex.getMessage(), ex);
		return new BaseResponse(ex.getStatus(), ex.getMessage());
	}

	@ExceptionHandler(NonLoginException.class)
	public BaseResponse userTokenExceptionHandler(HttpServletResponse response, NonLoginException ex) {
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
		logger.error(ex.getMessage(), ex);
		return new BaseResponse(ex.getStatus(), ex.getMessage());
	}

	@ExceptionHandler(UserInvalidException.class)
	public BaseResponse userInvalidExceptionHandler(HttpServletResponse response, UserInvalidException ex) {
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
		logger.error(ex.getMessage(), ex);
		return new BaseResponse(ex.getStatus(), ex.getMessage());
	}

	@ExceptionHandler(BusinessException.class)
	public BaseResponse businessExceptionHandler(HttpServletResponse response, BusinessException ex) {
		response.setStatus(HttpStatus.METHOD_FAILURE.value());
		logger.info(ex.getMessage(), ex);
		return new BaseResponse(ex.getStatus(), ex.getMessage());
	}
}
