
package com.macroflag.plusplatform.common.exception.auth;

import com.macroflag.plusplatform.common.constant.RestCodeConstants;
import com.macroflag.plusplatform.jwt.exception.BaseException;

/**
 * Client拒绝异常
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
public class ClientForbiddenException extends BaseException {
	public ClientForbiddenException(String message) {
		super(message, RestCodeConstants.EX_CLIENT_FORBIDDEN_CODE);
	}

}
