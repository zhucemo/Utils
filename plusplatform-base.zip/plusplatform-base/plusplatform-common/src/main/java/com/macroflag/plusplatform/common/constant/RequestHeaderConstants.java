
package com.macroflag.plusplatform.common.constant;

/**
 * 请求头枚举类
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
public class RequestHeaderConstants {
	public final static String TENANT = "X-Tenant-Auth";
	public final static String JWT_TOKEN_TYPE = "Bearer ";
}
