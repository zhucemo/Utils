package com.macroflag.plusplatform.common.mapper;

import tk.mybatis.mapper.common.Mapper;
import tk.mybatis.mapper.common.ids.SelectByIdsMapper;

/**
 * 通用MAPPER
 * 
 * @author : Fredia
 * @since : 2018年6月6日
 * @version : v1.0.0
 */
public interface CommonMapper<T> extends SelectByIdsMapper<T>, Mapper<T> {
}
