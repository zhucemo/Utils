
package com.macroflag.plusplatform.common.util;

import java.util.Date;

import com.macroflag.plusplatform.common.constant.RedisKeyConstants;
import com.macroflag.plusplatform.jwt.constants.CommonConstants;

public class RedisKeyUtil {
	/**
	 *
	 * @param userId
	 * @param expire
	 * @return
	 */
	public static String buildUserAbleKey(String userId, Date expire) {
		return CommonConstants.REDIS_USER_TOKEN + RedisKeyConstants.USER_ABLE + userId + ":" + expire.getTime();
	}

	/**
	 * 
	 * @param userId
	 * @param expire
	 * @return
	 */
	public static String buildUserDisableKey(String userId, Date expire) {
		return CommonConstants.REDIS_USER_TOKEN + RedisKeyConstants.USER_DISABLE + userId + ":" + expire.getTime();
	}
}
