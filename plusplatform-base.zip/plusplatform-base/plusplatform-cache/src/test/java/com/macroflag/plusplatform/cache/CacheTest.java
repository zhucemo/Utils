package com.macroflag.plusplatform.cache;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableFeCache
public class CacheTest {
	public static void main(String args[]) {
		SpringApplication app = new SpringApplication(CacheTest.class);
		app.run(args);
	}

}
