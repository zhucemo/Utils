package com.macroflag.plusplatform.cache.parser;

/**
 * 当前用户信息身份标志
 * 
 * @author : Fredia
 * @since : 2018年3月16日
 * @version : v1.0.0
 */
public interface IUserKeyGenerator {
	public String getCurrentUserAccount();
}
