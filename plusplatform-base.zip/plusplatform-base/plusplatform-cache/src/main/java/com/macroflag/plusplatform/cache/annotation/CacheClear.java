package com.macroflag.plusplatform.cache.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.macroflag.plusplatform.cache.parser.IKeyGenerator;
import com.macroflag.plusplatform.cache.parser.impl.DefaultKeyGenerator;

/**
 * 清除缓存
 * 
 * @author : Fredia
 * @since : 2018年3月16日
 * @version : v1.0.0
 */
@Retention(RetentionPolicy.RUNTIME) // 在运行时可以获取
@Target(value = { ElementType.METHOD, ElementType.TYPE }) // 作用到类，方法，接口上等
public @interface CacheClear {
	/**
	 * 缓存key的前缀
	 * 
	 * @return
	 * @author : Fredia
	 * @since : 2018年6月20日
	 * @return :String
	 */
	public String pre() default "";

	/**
	 * 缓存key
	 * 
	 * @return
	 * @author : Fredia
	 * @since : 2018年6月20日
	 * @return :String
	 */
	public String key() default "";

	/**
	 * 缓存keys
	 * 
	 * @return
	 * @author : Fredia
	 * @since : 2018年6月20日
	 * @return :String[]
	 */
	public String[] keys() default "";

	/**
	 * 键值解析类
	 * 
	 * @return
	 * @author : Fredia
	 * @since : 2018年6月20日
	 * @return :Class<? extends IKeyGenerator>
	 */
	public Class<? extends IKeyGenerator> generator() default DefaultKeyGenerator.class;
}
