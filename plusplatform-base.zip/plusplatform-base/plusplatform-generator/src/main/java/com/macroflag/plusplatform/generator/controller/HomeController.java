package com.macroflag.plusplatform.generator.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 首页
 * 
 * @author : Fredia
 * @since : 2018年6月11日
 * @version : v1.0.0
 */
@Controller
@RequestMapping("")
public class HomeController {

	@RequestMapping(value = "index", method = RequestMethod.GET)
	public String index(Map<String, Object> map) {
		return "index";
	}

	@RequestMapping(value = "generator", method = RequestMethod.GET)
	public String user() {
		return "generator/list";
	}
}
