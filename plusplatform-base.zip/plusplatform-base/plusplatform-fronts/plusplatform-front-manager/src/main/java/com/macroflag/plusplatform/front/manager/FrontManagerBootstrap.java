
package com.macroflag.plusplatform.front.manager;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.macroflag.plusplatform.auth.client.EnableFeAuthClient;
import com.macroflag.plusplatform.cache.EnableFeCache;
import com.macroflag.plusplatform.merge.EnableFeMerge;
import com.spring4all.swagger.EnableSwagger2Doc;

@EnableEurekaClient
@EnableCircuitBreaker
@SpringBootApplication
@EnableFeignClients({ "com.macroflag.plusplatform.auth.client.feign", "com.macroflag.plusplatform.front.manager.feign" })
@EnableScheduling
@EnableFeCache
@EnableTransactionManagement
@MapperScan("com.macroflag.plusplatform.front.manager.mapper")
@EnableFeAuthClient
@EnableSwagger2Doc
@EnableFeMerge
public class FrontManagerBootstrap {
	public static void main(String[] args) {
		new SpringApplicationBuilder(FrontManagerBootstrap.class).web(true).run(args);
	}
}
