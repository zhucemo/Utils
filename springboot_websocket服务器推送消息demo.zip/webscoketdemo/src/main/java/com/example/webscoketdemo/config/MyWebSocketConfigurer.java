package com.example.webscoketdemo.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
public class MyWebSocketConfigurer implements WebSocketConfigurer {

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry webSocketHandlerRegistry) {
        //支持websocket 的 connection，指定counterHandler处理路径为/counter 的长连接请求
        webSocketHandlerRegistry.addHandler(liveHandler(), "/counter")
                //添加WebSocket握手请求的拦截器.
                .addInterceptors(new LiveHandler.CountHandshakeInterceptor()).setAllowedOrigins("*");

        //不支持websocket的connenction,采用sockjs
        webSocketHandlerRegistry.addHandler(liveHandler(), "/sockjs/counter")
                //添加WebSocket握手请求的拦截器.
                .addInterceptors(new LiveHandler.CountHandshakeInterceptor()).setAllowedOrigins("*").withSockJS();
    }

    /**
     * 注册WebSocket处理类
     *
     */
    public LiveHandler liveHandler() {
        return new LiveHandler();
    }

}
