package com.example.webscoketdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

import java.util.Date;

@EnableWebSocket
@SpringBootApplication
public class WebscoketdemoApplication {
    public static void main(String[] args) {
        new SpringApplicationBuilder(WebscoketdemoApplication.class).bannerMode(Banner.Mode.OFF).run(args);
    }
}
